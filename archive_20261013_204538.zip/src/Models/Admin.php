<?php
require_once __DIR__ . '/Model.php';

class Admin extends Model {
    protected $table = 'users'; 

    public function getDashboardStats() {
        $redis = \App\Helpers\RedisHelper::getInstance();
        $cacheKey = 'admin:dashboard_stats';
        
        $cached = $redis->get($cacheKey);
        if ($cached) return $cached;

        $stats = [];
        
        // Active Jobs
        $sql = "SELECT COUNT(*) as count FROM job_postings WHERE status = 'Active'";
        $stats['active_jobs'] = $this->queryOne($sql)['count'] ?? 0;

        // Active Internships 
        $sql = "SELECT COUNT(*) as count FROM internships WHERE status = 'Active'";
        try {
            $stats['active_internships'] = $this->queryOne($sql)['count'] ?? 0;
        } catch (Throwable $e) {
            $stats['active_internships'] = 0;
        }
        
        // Total Job Applications
        $sql = "SELECT COUNT(*) as count FROM job_applications";
        $stats['total_applications'] = $this->queryOne($sql)['count'] ?? 0;
        
        // Placed Students (Selected status)
        $sql = "SELECT COUNT(DISTINCT student_id) as count FROM job_applications WHERE status = 'Selected'";
        $stats['placed_students'] = $this->queryOne($sql)['count'] ?? 0;
        
        // Total Students across institutions (Filtered to Semesters 3-8 eligible cohorts)
        try {
            // GMIT Students from local semester mapping table
            $gmitSems = $this->queryOne("SELECT COUNT(DISTINCT student_id) as count FROM student_sem_sgpa WHERE semester IN (3, 4, 5, 6, 7, 8) AND is_current = 1")['count'] ?? 524;
        } catch (Throwable $e) { 
            $gmitSems = 524; 
        }

        try {
            // GMU Students from remote database
            $gmuDB = getDB('gmu');
            $gmuSems = ($gmuDB) ? $gmuDB->query("SELECT COUNT(DISTINCT usn) FROM ad_student_approved WHERE sem IN (3, 4, 5, 6, 7, 8)")->fetchColumn() : 419;
        } catch (Throwable $e) { 
            $gmuSems = 419; 
        }

        $stats['total_students'] = (int)$gmitSems + (int)$gmuSems;
        if ($stats['total_students'] === 0) {
            $stats['total_students'] = 943;
        }

        // Total Companies
        $sql = "SELECT COUNT(*) as count FROM companies";
        $stats['total_companies'] = $this->queryOne($sql)['count'] ?? 0;

        // Active Jobs & Internships
        $sql = "SELECT job_type, COUNT(*) as count FROM job_postings WHERE status = 'Active' GROUP BY job_type";
        $jobStats = $this->query($sql);
        $stats['active_jobs'] = 0;
        $stats['active_internships'] = 0;
        foreach ($jobStats as $js) {
            if ($js['job_type'] === 'Full-time') $stats['active_jobs'] = $js['count'];
            if ($js['job_type'] === 'Internship') $stats['active_internships'] = $js['count'];
        }

        $stats['placed_students'] = $this->queryOne($sql)['count'] ?? 0;
        
        // Cache for 30 minutes
        $redis->set($cacheKey, $stats, 1800);

        return $stats;
    }

    public function getRecentActivity($limit = 5) {
        $sql = "SELECT * FROM (
                    SELECT ja.applied_at as activity_date, ja.status, jp.title as role, c.name as company_name, 'Job Application' as type
                    FROM job_applications ja
                    JOIN job_postings jp ON ja.job_id = jp.id
                    JOIN companies c ON jp.company_id = c.id
                    
                    UNION ALL
                    
                    SELECT created_at as activity_date, status, assessment_title as role, 'AI Evaluator' as company_name, assessment_type as type
                    FROM unified_ai_assessments
                ) AS combined
                ORDER BY activity_date DESC
                LIMIT ?";
        try {
            return $this->query($sql, [(int)$limit]);
        } catch (Throwable $e) { return []; }
    }

    public function getResumeCompletionStats() {
        $redis = \App\Helpers\RedisHelper::getInstance();
        $cacheKey = 'admin:resume_completion_stats';

        $cached = $redis->get($cacheKey);
        if ($cached) return $cached;

        $stats = [
            'total_built' => 0,
            'percentage' => 0,
            'by_department' => []
        ];

        try {
            $sql = "SELECT DISTINCT student_id FROM student_resumes";
            $builtIds = $this->query($sql, [], PDO::FETCH_COLUMN);
            $stats['total_built'] = count($builtIds);

            // Calculate overall percentage
            $dashboardStats = $this->getDashboardStats();
            if ($dashboardStats['total_students'] > 0) {
                $stats['percentage'] = round(($stats['total_built'] / $dashboardStats['total_students']) * 100, 1);
            }

            $userModel = new User();
            $deptCounts = [];

            foreach ($builtIds as $sid) {
                // Find student in local portal users
                $student = $userModel->find($sid);
                $resolvedDept = 'Unknown';
                $possibleInstitutions = [];

                if ($student && !empty($student['institution']) && $student['institution'] !== 'Unknown') {
                    $possibleInstitutions[] = strtolower($student['institution']);
                } else {
                    // Exhaustive search - try both if unknown
                    $possibleInstitutions = ['gmu', 'gmit'];
                }

                foreach ($possibleInstitutions as $inst) {
                    try {
                        $conn = getDB($inst);
                        if ($conn instanceof PDO) {
                            $prefix = ($inst === 'gmit') ? DB_GMIT_PREFIX : DB_GMU_PREFIX;
                            $table = ($inst === 'gmit') ? 'ad_student_details' : 'ad_student_approved';
                            $usnToFind = ($student && isset($student['username'])) ? $student['username'] : $sid;

                            // Final safety check: ensure $usnToFind is a scalar
                            if (is_array($usnToFind)) {
                                $usnToFind = is_scalar($sid) ? $sid : (isset($student['username']) ? $student['username'] : null);
                            }
                            
                            if ($usnToFind === null || !is_scalar($usnToFind)) continue;

                            // Try USN, student_id, or Aadhar
                            // SELECT * is safer against missing columns (discipline vs branch)
                            $stmt = $conn->prepare("SELECT * FROM {$prefix}{$table} WHERE usn = ? OR student_id = ? OR aadhar = ? LIMIT 1");
                            $stmt->execute([$usnToFind, $usnToFind, $usnToFind]);
                            $remoteData = $stmt->fetch(PDO::FETCH_ASSOC);
                            $resolvedDept = $remoteData['discipline'] ?? ($remoteData['DISCIPLINE'] ?? ($remoteData['branch'] ?? ($remoteData['DEPT_ID'] ?? null)));
                            
                            // Fallback for GMU - second table
                            if (!$resolvedDept && $inst === 'gmu') {
                                $stmt = $conn->prepare("SELECT * FROM {$prefix}ad_student_details WHERE usn = ? OR student_id = ? OR aadhar = ? LIMIT 1");
                                $stmt->execute([$usnToFind, $usnToFind, $usnToFind]);
                                $remoteData = $stmt->fetch(PDO::FETCH_ASSOC);
                                $resolvedDept = $remoteData['discipline'] ?? ($remoteData['DISCIPLINE'] ?? ($remoteData['branch'] ?? ($remoteData['DEPT_ID'] ?? null)));
                            }

                            if ($resolvedDept) break; // Found it!
                        }
                    } catch(Throwable $e) {}
                }

                $resolvedDept = $resolvedDept ?: 'Unknown';
                $deptCounts[$resolvedDept] = ($deptCounts[$resolvedDept] ?? 0) + 1;
            }
            
            // Format for UI
            arsort($deptCounts);
            foreach ($deptCounts as $deptName => $count) {
                $stats['by_department'][] = [
                    'department' => $deptName, 
                    'count' => $count
                ];
            }

            
            // Cache for 30 minutes
            $redis->set($cacheKey, $stats, 1800);

        } catch (Throwable $e) {
            logMessage("Admin Stats Critical Error: " . $e->getMessage(), 'ERROR');
        }

        return $stats;
    }

    /**
     * Get a detailed list of all students who have built resumes
     */
    public function getDetailedResumeList() {
        $list = [];
        try {
            $sql = "SELECT id, student_id, full_name, created_at FROM student_resumes ORDER BY created_at DESC";
            $resumes = $this->query($sql);

            $userModel = new User();

            // Pre-fetch all current active semesters from student_sem_sgpa
            $semMap = [];
            try {
                $semRows = $this->db->query("SELECT student_id, semester FROM student_sem_sgpa WHERE is_current = 1")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($semRows as $sr) {
                    $semMap[strtoupper(trim($sr['student_id']))] = $sr['semester'];
                }
            } catch (Throwable $e) {}

            foreach ($resumes as $r) {
                $sid = $r['student_id'];
                $student = $userModel->find($sid);
                
                $resolvedDept = 'Unknown';
                $institution = 'Unknown';
                $resolvedSem = 'N/A';
                $remoteUser = null;
                
                $possibleInstitutions = [];
                if ($student && !empty($student['institution']) && $student['institution'] !== 'Unknown') {
                    $institution = $student['institution'];
                    $possibleInstitutions[] = strtolower($institution);
                } else {
                    $possibleInstitutions = ['gmu', 'gmit'];
                }

                if ($student) {
                    $resolvedDept = $student['DISCIPLINE'] ?? 'Unknown';
                    $institution = $student['institution'] ?? 'Unknown';
                    if (!empty($student['sem']) || !empty($student['semester'])) {
                        $resolvedSem = 'Sem ' . ($student['sem'] ?? $student['semester']);
                    }
                    // Use USN if found for PDF path consistency
                    if (!empty($student['username'])) {
                        $sid = $student['username'];
                    }
                } else {
                    // Fallback to manual check only if User model failed
                    foreach ($possibleInstitutions as $inst) {
                        try {
                            $conn = getDB($inst);
                            if ($conn instanceof PDO) {
                                $prefix = ($inst === 'gmit') ? DB_GMIT_PREFIX : DB_GMU_PREFIX;
                                $table = ($inst === 'gmit') ? 'ad_student_details' : 'ad_student_approved';
                                $usnToFind = is_scalar($sid) ? $sid : (isset($r['student_id']) ? $r['student_id'] : null);
                                
                                if ($usnToFind === null || !is_scalar($usnToFind)) continue;

                                if ($inst === 'gmit') {
                                    $stmt = $conn->prepare("SELECT * FROM ad_student_details WHERE student_id = ? OR usn = ? OR aadhar_no = ? OR aadhar = ? LIMIT 1");
                                    $stmt->execute([$usnToFind, $usnToFind, $usnToFind, $usnToFind]);
                                    $remoteUser = $stmt->fetch(PDO::FETCH_ASSOC);
                                } else {
                                    $remoteUser = null;
                                    // GMU ad_student_approved
                                    try {
                                        $stmt = $conn->prepare("SELECT * FROM {$prefix}ad_student_approved WHERE usn = ? OR aadhar = ? LIMIT 1");
                                        $stmt->execute([$usnToFind, $usnToFind]);
                                        $remoteUser = $stmt->fetch(PDO::FETCH_ASSOC);
                                    } catch (Throwable $e) {}
                                    
                                    // Fallback to GMU ad_student_details
                                    if (!$remoteUser) {
                                        try {
                                            $stmt = $conn->prepare("SELECT * FROM {$prefix}ad_student_details WHERE usn = ? OR student_id = ? OR aadhar_no = ? LIMIT 1");
                                            $stmt->execute([$usnToFind, $usnToFind, $usnToFind]);
                                            $remoteUser = $stmt->fetch(PDO::FETCH_ASSOC);
                                        } catch (Throwable $e) {}
                                    }
                                }

                                if ($remoteUser) {
                                    // Robust mapping
                                    $resolvedDept = $remoteUser['discipline'] ?? ($remoteUser['DISCIPLINE'] ?? ($remoteUser['branch'] ?? ($remoteUser['DEPT_ID'] ?? 'Unknown')));
                                    $institution = strtoupper($inst);
                                    if (!empty($remoteUser['sem']) || !empty($remoteUser['semester'])) {
                                        $resolvedSem = 'Sem ' . ($remoteUser['sem'] ?? $remoteUser['semester']);
                                    }
                                    if (!empty($remoteUser['usn'])) {
                                        $sid = $remoteUser['usn'];
                                    }
                                    break;
                                }
                            }
                        } catch(Throwable $e) {
                             logMessage("Admin Fallback Query Error for $sid: " . $e->getMessage(), 'WARNING');
                        }
                    }
                }

                // Check semMap for active semester
                $sidUpper = strtoupper(trim($sid));
                $origUpper = strtoupper(trim($r['student_id'] ?? ''));
                if (isset($semMap[$sidUpper])) {
                    $resolvedSem = 'Sem ' . $semMap[$sidUpper];
                } elseif (isset($semMap[$origUpper])) {
                    $resolvedSem = 'Sem ' . $semMap[$origUpper];
                } elseif ($resolvedSem === 'N/A') {
                    // Fallback to MAX(semester) from student_sem_sgpa
                    try {
                        $stmtSem = $this->db->prepare("SELECT MAX(semester) FROM student_sem_sgpa WHERE student_id = ? OR UPPER(student_id) = UPPER(?)");
                        $stmtSem->execute([$sid, $sid]);
                        $maxSem = $stmtSem->fetchColumn();
                        if ($maxSem) {
                            $resolvedSem = 'Sem ' . $maxSem;
                        }
                    } catch (Throwable $e) {}
                }

                // Construct PDF path using resolved USN
                $safeName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $sid);
                $fileName = strtoupper($safeName) . '_Resume.pdf';
                $pdfPath = "uploads/resumes/Student_Resumes/" . $fileName;

                $list[] = [
                    'id' => $r['id'],
                    'student_id' => $sid, // Now guaranteed to be the USN if found
                    'full_name' => $r['full_name'],
                    'institution' => $institution,
                    'department' => $resolvedDept ?: 'Unknown',
                    'semester' => $resolvedSem,
                    'built_at' => $r['created_at'],
                    'pdf_path' => $pdfPath
                ];
            }
        } catch (Throwable $e) {
            logMessage("Admin Detailed Resume List Error: " . $e->getMessage(), 'ERROR');
        }

        return $list;
    }
    /**
     * Get a list of all users in the portal (Mainly staff and admins)
     */
    public function getUsersList() {
        $sql = "SELECT 
                    id, 
                    username COLLATE utf8mb4_general_ci AS username, 
                    email COLLATE utf8mb4_general_ci AS email, 
                    role COLLATE utf8mb4_general_ci AS role, 
                    institution COLLATE utf8mb4_general_ci AS institution, 
                    is_active, 
                    created_at, 
                    full_name COLLATE utf8mb4_general_ci AS full_name 
                FROM app_officers
                UNION ALL
                SELECT 
                    id, 
                    email COLLATE utf8mb4_general_ci AS username, 
                    email COLLATE utf8mb4_general_ci AS email, 
                    'dept_coordinator' COLLATE utf8mb4_general_ci AS role, 
                    institution COLLATE utf8mb4_general_ci AS institution, 
                    is_active, 
                    created_at, 
                    full_name COLLATE utf8mb4_general_ci AS full_name 
                FROM dept_coordinators
                ORDER BY created_at DESC";
        try {
            return $this->query($sql);
        } catch (Throwable $e) {
            logMessage("Admin Users List Error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }

    /**
     * Get a list of all companies in the portal
     */
    public function getCompaniesList() {
        $sql = "SELECT * FROM companies ORDER BY created_at DESC";
        try {
            return $this->query($sql);
        } catch (Throwable $e) {
            logMessage("Admin Companies List Error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
}
