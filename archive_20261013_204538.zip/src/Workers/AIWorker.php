<?php
/**
 * AI Worker
 * Run this from CLI: php src/Workers/AIWorker.php
 */

require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../../src/Services/QueueService.php';
require_once __DIR__ . '/../../src/Services/AIService.php';
require_once __DIR__ . '/../../src/Services/CareerAdvisorAI.php';

use App\Services\QueueService;

function workerLog($message)
{
    echo "[" . date('Y-m-d H:i:s') . "] " . $message . "\n";
}

workerLog("--- AI Worker Started ---");
workerLog("Waiting for jobs...");

$services = [
    new AIService(),
    new CareerAdvisorAI(),
];

// Identify worker index and identity
$workerIndex = isset($argv[1]) ? max(1, intval($argv[1])) : 1;
$workerId = gethostname() . "_W" . $workerIndex . "_" . getmypid();
workerLog("Worker Identity: $workerId (Worker #$workerIndex)");

function updatePulse($id, $jobCount = 0)
{
    global $redisHelper;
    if ($redisHelper && $redisHelper->isConnected()) {
        $redisHelper->getClient()->hset('ai_workers_pulse', $id, time());
        $redisHelper->getClient()->hset('ai_workers_memory', $id, round(memory_get_usage() / 1024 / 1024, 2) . 'MB');
        $redisHelper->getClient()->hset('ai_workers_jobs', $id, $jobCount);
    }
}

// Graceful shutdown function to clean up Redis pulse immediately when process stops
register_shutdown_function(function() use ($workerId) {
    global $redisHelper;
    workerLog("Worker $workerId shutting down. Cleaning pulse...");
    try {
        if ($redisHelper && $redisHelper->isConnected()) {
            $redisHelper->getClient()->hdel('ai_workers_pulse', $workerId);
            $redisHelper->getClient()->hdel('ai_workers_memory', $workerId);
            $redisHelper->getClient()->hdel('ai_workers_jobs', $workerId);
        }
    } catch (Throwable $e) {}
});

$jobCount = 0;
updatePulse($workerId, $jobCount);

$startTime = time();
// Stagger max runtime by 60 seconds per worker index to prevent simultaneous worker expirations
$maxRuntime = (86400 * 30) + (($workerIndex - 1) * 60); // 30 days + staggered offset
$maxMemory = 256 * 1024 * 1024; // 256MB limit
$maxJobs = 100000 + (($workerIndex - 1) * 500); // Staggered job limit

while (true) {
    // 0. Health & Memory Checks
    if (time() - $startTime > $maxRuntime) {
        workerLog("Max runtime reached. Restarting...");
        exit(0);
    }
    if (memory_get_usage() > $maxMemory) {
        workerLog("Memory limit (256MB) reached. Current: " . round(memory_get_usage() / 1024 / 1024, 2) . "MB. Restarting...");
        exit(0);
    }
    if ($jobCount >= $maxJobs) {
        workerLog("Max jobs ($maxJobs) reached. Restarting...");
        exit(0);
    }
    // Graceful restart: scripts/run_5_workers_hourly.bat sets this key and starts
    // fresh workers; older workers exit here, between jobs, instead of being
    // force-killed mid-job (which left jobs stuck in 'processing' forever).
    try {
        $restartAt = (int) ($redisHelper && $redisHelper->isConnected() ? $redisHelper->getClient()->get('ai_workers_restart_at') : 0);
        if ($restartAt > $startTime) {
            workerLog("Graceful restart requested. Exiting between jobs...");
            exit(0);
        }
    } catch (Throwable $e) {}

    // 1. Pop Job ID
    $jobId = QueueService::popJob(30); // Block for 30s

    if (!$jobId) {
        // No job, pulse and loop again
        updatePulse($workerId, $jobCount);
        continue;
    }

    workerLog("Processing Job: $jobId");

    // 2. Load Job Data
    $job = QueueService::getJobStatus($jobId);
    if (!$job) {
        workerLog("Error: Job $jobId not found in Redis.");
        continue;
    }

    // 3. Update status to processing
    $jobCount++;
    // Pulse BEFORE processing: long AI calls (up to minutes) must not make the
    // worker look dead to QueueService::isQueueAvailable().
    updatePulse($workerId, $jobCount);
    $currentUserId = $job['user_id'] ?? 0;
    $GLOBALS['AI_WORKER_USER_ID'] = $currentUserId;

    QueueService::updateJob($jobId, [
        'status' => 'processing',
        'started_at' => time(),
        'worker_id' => $workerId
    ]);

    try {
        $method = $job['method'];
        $args = $job['args'];

        // 4. Find service that has the method and dispatch
        $dispatched = false;
        foreach ($services as $svc) {
            if (method_exists($svc, $method)) {
                $result = call_user_func_array([$svc, $method], $args);

                // A service-level failure (e.g. OpenAI error) must surface as a
                // FAILED job, not a "completed" job whose payload is an error
                // object — pollers only ever looked at 'completed'/'failed'.
                if (is_array($result) && isset($result['success']) && $result['success'] === false) {
                    QueueService::updateJob($jobId, [
                        'status' => 'failed',
                        'error' => $result['message'] ?? 'AI service returned a failure',
                        'completed_at' => time()
                    ]);
                    workerLog("Failed: Job $jobId — AI error: " . ($result['message'] ?? 'unknown'));
                    $dispatched = true;
                    break;
                }

                $finalResult = isset($result['result']) ? $result['result'] : $result;

                QueueService::updateJob($jobId, [
                    'status' => 'completed',
                    'result' => json_encode($finalResult),
                    'completed_at' => time()
                ]);
                workerLog("Success: Job $jobId finished (" . get_class($svc) . "::$method).");
                $dispatched = true;
                break;
            }
        }
        if (!$dispatched) {
            throw new Exception("Method $method not found in any registered service");
        }
    } catch (Throwable $e) {
        // Throwable, not Exception: a PHP Error (TypeError etc.) used to kill the
        // worker and leave the job 'processing' with the student polling forever.
        workerLog("Error: Job $jobId failed - " . $e->getMessage());
        QueueService::updateJob($jobId, [
            'status' => 'failed',
            'error' => $e->getMessage(),
            'completed_at' => time()
        ]);
    }
    updatePulse($workerId, $jobCount);
}