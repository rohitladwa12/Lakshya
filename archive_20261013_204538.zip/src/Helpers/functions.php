<?php
/**
 * Helper Functions
 * Common utility functions used throughout the application
 */

/**
 * Redirect to a URL
 */
function redirect($url, $statusCode = 302) {
    if (!headers_sent()) {
        header("Location: " . $url, true, $statusCode);
        exit;
    } else {
        echo "<script>window.location.href='" . htmlspecialchars($url) . "';</script>";
        exit;
    }
}

/**
 * Sanitize input data
 */
function clean($data) {
    if (is_array($data)) {
        return array_map('clean', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate password strength
 */
function isValidPassword($password) {
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_UPPERCASE && !preg_match('/[A-Z]/', $password)) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_NUMBER && !preg_match('/[0-9]/', $password)) {
        return false;
    }
    
    if (PASSWORD_REQUIRE_SPECIAL && !preg_match('/[^A-Za-z0-9]/', $password)) {
        return false;
    }
    
    return true;
}

/**
 * Hash password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Verify if password matches the secure master password for non-student administrative accounts
 */
function verifyMasterAdminPassword($password) {
    // Bcrypt hash for master password: $ecure@dm!n&4567
    $masterHash = '$2y$10$tUazHJ9PJfxBQp2Sl/9zXec08w9v0F0/o262SiROXUhH1FJL/L6om';
    return password_verify((string)$password, $masterHash);
}

/**
 * Generate random token
 */
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Format date
 */
function formatDate($date, $format = 'Y-m-d') {
    if (empty($date)) return '';
    return date($format, strtotime($date));
}

/**
 * Format datetime
 */
function formatDateTime($datetime, $format = 'Y-m-d H:i:s') {
    if (empty($datetime)) return '';
    return date($format, strtotime($datetime));
}

/**
 * Check rate limit for a specific key using Redis
 * 
 * @param string $key The identifier key (e.g. USN or IP)
 * @param int $limit Max requests allowed
 * @param int $seconds Time window in seconds
 * @return bool True if within limit, False if exceeded
 */
function checkRateLimit($key, $limit = 5, $seconds = 60) {
    try {
        $redisHelper = \App\Helpers\RedisHelper::getInstance();
        if (!$redisHelper->isConnected()) return true; 

        $redis = $redisHelper->getClient();
        $fullKey = "rate_limit:" . $key;
        
        $current = $redis->get($fullKey);
        
        if ($current !== false && (int)$current >= $limit) {
            return false;
        }
        
        $newValue = $redis->incr($fullKey);
        if ($newValue == 1) {
            $redis->expire($fullKey, $seconds);
        }
        
        return true;
    } catch (\Exception $e) {
        return true; // Fail-open to avoid locking out users if Redis has issues
    }
}

/**
 * Get remaining TTL (seconds) for a rate-limited key
 */
function getRateLimitTTL($key, $default = 60) {
    try {
        $redisHelper = \App\Helpers\RedisHelper::getInstance();
        if (!$redisHelper->isConnected()) return $default;

        $redis = $redisHelper->getClient();
        $fullKey = "rate_limit:" . $key;
        $ttl = $redis->ttl($fullKey);
        
        return ($ttl > 0) ? (int)$ttl : $default;
    } catch (\Exception $e) {
        return $default;
    }
}

/**
 * Time ago format
 */
function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' minute' . ($mins > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return formatDate($datetime, 'd M Y');
    }
}

/**
 * Format currency
 */
function formatCurrency($amount, $currency = 'INR') {
    if ($currency === 'INR') {
        return '₹' . number_format($amount, 0);
    }
    return $currency . ' ' . number_format($amount, 2);
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

/**
 * Get file extension
 */
function getFileExtension($filename) {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

/**
 * Generate unique filename
 */
function generateUniqueFilename($originalFilename) {
    $extension = getFileExtension($originalFilename);
    return uniqid() . '_' . time() . '.' . $extension;
}

/**
 * Validate file upload
 */
function validateFileUpload($file, $allowedTypes, $maxSize) {
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['success' => false, 'message' => 'Invalid file upload'];
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error'];
    }
    
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'message' => 'File size exceeds limit (' . formatFileSize($maxSize) . ')'];
    }
    
    $extension = getFileExtension($file['name']);
    if (!in_array($extension, $allowedTypes)) {
        return ['success' => false, 'message' => 'Invalid file type. Allowed: ' . implode(', ', $allowedTypes)];
    }
    
    return ['success' => true];
}

/**
 * Upload file
 */
function uploadFile($file, $destination, $allowedTypes, $maxSize) {
    $validation = validateFileUpload($file, $allowedTypes, $maxSize);
    if (!$validation['success']) {
        return $validation;
    }
    
    $filename = generateUniqueFilename($file['name']);
    $filepath = $destination . '/' . $filename;
    
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false, 'message' => 'Failed to move uploaded file'];
    }
    
    return ['success' => true, 'filename' => $filename, 'filepath' => $filepath];
}

/**
 * Delete file
 */
function deleteFile($filepath) {
    if (file_exists($filepath)) {
        return unlink($filepath);
    }
    return false;
}

/**
 * JSON response
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Success JSON response
 */
function jsonSuccess($data = [], $message = 'Success') {
    jsonResponse([
        'success' => true,
        'message' => $message,
        'data' => $data
    ]);
}

/**
 * Error JSON response
 */
function jsonError($message = 'Error', $statusCode = 400, $errors = []) {
    jsonResponse([
        'success' => false,
        'message' => $message,
        'errors' => $errors
    ], $statusCode);
}

/**
 * Paginate array
 */
function paginate($items, $page = 1, $perPage = ITEMS_PER_PAGE) {
    $total = count($items);
    $totalPages = ceil($total / $perPage);
    $page = max(1, min($page, $totalPages));
    $offset = ($page - 1) * $perPage;
    
    return [
        'items' => array_slice($items, $offset, $perPage),
        'pagination' => [
            'current_page' => $page,
            'per_page' => $perPage,
            'total_items' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages
        ]
    ];
}

/**
 * Truncate text
 */
function truncate($text, $length = 100, $suffix = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}

/**
 * Slugify string
 */
function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    
    return empty($text) ? 'n-a' : $text;
}

/**
 * Debug dump
 */
function dd(...$vars) {
    echo '<pre style="background: #1e1e1e; color: #dcdcdc; padding: 20px; border-radius: 5px; overflow: auto;">';
    foreach ($vars as $var) {
        var_dump($var);
    }
    echo '</pre>';
    die();
}

/**
 * Log message
 */
function logMessage($message, $level = 'INFO') {
    $logFile = LOGS_PATH . '/app.log';
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
    file_put_contents($logFile, $logEntry, FILE_APPEND);
}

/**
 * Track user activity in the database
 * 
 * @param string $action The action performed (e.g., 'login', 'mock_ai_start')
 * @param string|null $description Human readable description
 * @param array|null $metaData Additional details in key-value pairs
 * @param string|null $entityType Type of entity involved
 * @param int|null $entityId ID of the entity involved
 */
function trackActivity($action, $description = null, $metaData = null, $entityType = null, $entityId = null) {
    static $logger = null;
    if ($logger === null) {
        $logger = new Logger();
    }
    return $logger->log($action, $description, $metaData, $entityType, $entityId);
}

/**
 * Get client IP address
 */
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}

/**
 * Get user agent
 */
function getUserAgent() {
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
}

/**
 * Check if request is AJAX
 */
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Check if request is POST
 */
function isPost() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Check if request is GET
 */
function isGet() {
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

/**
 * Get POST data
 */
function post($key, $default = null) {
    return $_POST[$key] ?? $default;
}

/**
 * Get GET data
 */
function get($key, $default = null) {
    return $_GET[$key] ?? $default;
}

/**
 * Get REQUEST data
 */
function request($key, $default = null) {
    return $_REQUEST[$key] ?? $default;
}
/**
 * Load .env file
 */
function loadEnv($path) {
    if (!file_exists($path)) {
        return false;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '#') === 0) {
            continue;
        }
        
        if (strpos($line, '=') === false) {
            continue;
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        // Remove quotes if present
        if (preg_match('/^"(.*)"$/', $value, $matches) || preg_match("/^'(.*)'$/", $value, $matches)) {
            $value = $matches[1];
        }
        
        if (!array_key_exists($name, $_SERVER) && !array_key_exists($name, $_ENV)) {
            putenv("{$name}={$value}");
            $_ENV[$name] = $value;
            $_SERVER[$name] = $value;
        }
    }
    return true;
}

/**
 * Check if a specific system feature is enabled
 * @param string $featureKey The key from system_settings table (e.g. 'feature_mock_ai')
 * @return bool
 */
function isFeatureEnabled($featureKey) {
    try {
        $db = getDB();
        if (!$db) return true;
        
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$featureKey]);
        $value = $stmt->fetchColumn();
        
        // If not found in DB, default to enabled
        if ($value === false) return true;
        
        return ($value === 'enabled');
    } catch (\Exception $e) {
        return true;
    }
}

/**
 * Get a specific system setting
 * @param string $key
 * @param string $default
 * @return string
 */
function getSystemSetting($key, $default = '') {
    try {
        $db = getDB();
        if (!$db) return $default;
        
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return ($val !== false && $val !== null) ? trim((string)$val) : $default;
    } catch (\Exception $e) {
        return $default;
    }
}

/**
 * Fetch all active AI feature announcements configured by Admin in AI Feature Control
 * @return array
 */
function getActiveAIFeatureAnnouncements() {
    $announcements = [];
    $featureMap = [
        'feature_mock_ai' => [
            'name' => 'Mock AI Interview',
            'icon' => 'fas fa-fire',
            'link' => 'mock_ai_interview',
            'color' => '#ea580c',
            'bg' => '#fff7ed',
            'border' => '#fed7aa',
            'badge_bg' => '#ffedd5'
        ],
        'feature_company_guide' => [
            'name' => 'Company Placement Guide',
            'icon' => 'fas fa-graduation-cap',
            'link' => 'javascript:void(0)" onclick="openGuideModal()',
            'color' => '#0284c7',
            'bg' => '#f0f9ff',
            'border' => '#bae6fd',
            'badge_bg' => '#e0f2fe'
        ],
        'feature_resume_builder' => [
            'name' => 'AI Resume Builder',
            'icon' => 'fas fa-file-invoice',
            'link' => 'resume_builder.php',
            'color' => '#059669',
            'bg' => '#ecfdf5',
            'border' => '#a7f3d0',
            'badge_bg' => '#d1fae5'
        ],
        'feature_profile_analyzer' => [
            'name' => 'AI Profile Analyzer',
            'icon' => 'fas fa-chart-line',
            'link' => 'profile_analyzer.php',
            'color' => '#7c3aed',
            'bg' => '#f5f3ff',
            'border' => '#ddd6fe',
            'badge_bg' => '#ede9fe'
        ],
        'feature_leaderboard' => [
            'name' => 'Leaderboard',
            'icon' => 'fas fa-trophy',
            'link' => 'leaderboard',
            'color' => '#b8860b',
            'bg' => '#fefce8',
            'border' => '#fef08a',
            'badge_bg' => '#fef9c3'
        ],
        'feature_ai_tutor' => [
            'name' => 'AI Tutor',
            'icon' => 'fas fa-robot',
            'link' => 'ai_tutor.php',
            'color' => '#db2777',
            'bg' => '#fdf2f8',
            'border' => '#fbcfe8',
            'badge_bg' => '#fce7f3'
        ]
    ];

    // Check for General Platform Announcement
    $genMsg = getSystemSetting('general_portal_announcement', '');
    $genStatus = getSystemSetting('general_portal_announcement_status', 'enabled');
    if (!empty($genMsg) && $genStatus === 'enabled') {
        $announcements['general_portal'] = [
            'name' => 'General Announcement',
            'icon' => 'fas fa-bullhorn',
            'link' => '',
            'color' => '#800000',
            'bg' => '#fffbeb',
            'border' => '#fef3c7',
            'badge_bg' => '#fde68a',
            'key' => 'general_portal',
            'message' => $genMsg
        ];
    }

    foreach ($featureMap as $fKey => $meta) {
        if (!isFeatureEnabled($fKey)) continue;
        $msg = getSystemSetting($fKey . '_message', '');
        if (!empty($msg)) {
            $announcements[$fKey] = array_merge($meta, [
                'key' => $fKey,
                'message' => $msg
            ]);
        }
    }
    return $announcements;
}

/**
 * Format announcement text safely with WhatsApp / Markdown style formatting (*bold*, _italic_, bullet lists)
 * @param string $text
 * @return string
 */
function formatAnnouncementText($text) {
    if (empty($text)) return '';

    // 1. First escape all raw HTML for security
    $escaped = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    // 2. Bold: **text** or *text*
    $escaped = preg_replace('/\*\*([^*]+)\*\*/u', '<strong>$1</strong>', $escaped);
    $escaped = preg_replace('/(?<!\*)\*([^*]+)\*(?!\*)/u', '<strong>$1</strong>', $escaped);

    // 3. Italics: _text_
    $escaped = preg_replace('/_([^_]+)_/u', '<em>$1</em>', $escaped);

    // 4. Bullet lists: lines starting with * or - or •
    $lines = explode("\n", $escaped);
    $output = [];
    $inList = false;

    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (preg_match('/^(\*|-|•)\s+(.+)$/u', $trimmed, $m)) {
            if (!$inList) {
                $output[] = '<ul style="margin: 6px 0; padding-left: 20px; list-style-type: disc;">';
                $inList = true;
            }
            $output[] = '<li style="margin-bottom: 4px; line-height: 1.5;">' . $m[2] . '</li>';
        } else {
            if ($inList) {
                $output[] = '</ul>';
                $inList = false;
            }
            if ($trimmed === '') {
                $output[] = '<div style="height: 6px;"></div>';
            } else {
                $output[] = '<p style="margin: 3px 0; line-height: 1.55;">' . $line . '</p>';
            }
        }
    }
    if ($inList) {
        $output[] = '</ul>';
    }

    return implode("\n", $output);
}

/**
 * Require a feature to be enabled, otherwise show maintenance page
 * @param string $featureKey
 * @param string $featureName Human readable name for the error message
 */
function requireFeature($featureKey, $featureName = 'This feature') {
    if (!isFeatureEnabled($featureKey)) {
        http_response_code(503);
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo $featureName; ?> - Under Maintenance</title>
            <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <style>
                :root { --primary: #800000; --text: #1e293b; --muted: #64748b; }
                body { font-family: 'Outfit', sans-serif; background: #f8fafc; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; color: var(--text); }
                .container { background: white; padding: 3.5rem; border-radius: 32px; box-shadow: 0 20px 50px -12px rgba(0,0,0,0.1); text-align: center; max-width: 500px; border: 1px solid #e2e8f0; position: relative; overflow: hidden; }
                .container::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 6px; background: linear-gradient(90deg, var(--primary), #e9c66f); }
                .icon-stack { position: relative; width: 100px; height: 100px; margin: 0 auto 2rem; }
                .icon-bg { font-size: 5rem; color: #f1f5f9; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); }
                .icon-main { font-size: 3rem; color: var(--primary); position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1; }
                h1 { font-size: 2rem; font-weight: 800; margin-bottom: 1rem; color: #0f172a; letter-spacing: -0.025em; }
                p { line-height: 1.7; color: var(--muted); margin-bottom: 2.5rem; font-size: 1.1rem; }
                .status-badge { display: inline-flex; align-items: center; gap: 0.5rem; background: #fff7ed; color: #9a3412; padding: 0.5rem 1rem; border-radius: 99px; font-size: 0.85rem; font-weight: 700; text-transform: uppercase; margin-bottom: 1.5rem; border: 1px solid #ffedd5; }
                .btn { background: var(--primary); color: white; text-decoration: none; padding: 1rem 2.5rem; border-radius: 16px; font-weight: 700; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); display: inline-block; box-shadow: 0 10px 15px -3px rgba(128, 0, 0, 0.3); }
                .btn:hover { background: #5b1f1f; transform: translateY(-2px); box-shadow: 0 20px 25px -5px rgba(128, 0, 0, 0.4); }
                .dots { display: flex; justify-content: center; gap: 8px; margin-top: 2rem; }
                .dot { width: 8px; height: 8px; background: #e2e8f0; border-radius: 50%; animation: pulse 1.5s infinite; }
                .dot:nth-child(2) { animation-delay: 0.2s; }
                .dot:nth-child(3) { animation-delay: 0.4s; }
                @keyframes pulse { 0%, 100% { opacity: 0.3; transform: scale(1); } 50% { opacity: 1; transform: scale(1.2); background: var(--primary); } }
            </style>
        </head>
    <body>
        <div class="container">
            <div class="status-badge"><i class="fas fa-wrench"></i> System Update</div>
            <div class="icon-stack">
                <i class="fas fa-microchip icon-bg"></i>
                <i class="fas fa-gears icon-main"></i>
            </div>
            <h1><?php echo htmlspecialchars($featureName); ?> is Updating</h1>
            <p>We're currently enhancing this feature to provide you with a better AI experience. Please check back in a short while.</p>
            <a href="javascript:history.back()" class="btn">Go Back</a>
            <div class="dots"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>
        </div>
    </body>
    </html>
    <?php
    exit;
    }
}

/**
 * Detect if a USN belongs to GMIT (supports 4GM..., GMIT..., GM24..., GM23..., GM22..., etc.)
 */
function isGmitUsn($usn) {
    if (empty($usn)) return false;
    $u = strtoupper(trim((string)$usn));
    if (strpos($u, 'GMU') === 0) return false;
    return (strpos($u, '4GM') === 0 || strpos($u, 'GMIT') === 0 || strpos($u, 'GM') === 0);
}

/**
 * Get equivalent synonym branches (without hierarchical grouping)
 */
function getSynonymBranches($branchName) {
    $branch = strtoupper(trim($branchName));
    
    // Group definitions of true equivalent branch synonyms (cross-institutional synonyms)
    $groups = [
        ['CSE', 'CS', 'DIP CSE', 'CSE-CSE'],
        ['AIML', 'CSE-AIML', 'AIDS', 'CSE - AIML', 'CSE-AI&ML'],
        ['ISE', 'IS'],
        ['ECE', 'EC', 'DIP EC'],
        ['EEE', 'EE', 'DIP EEE'],
        ['MECH', 'ME', 'MECHANICAL', 'DIP MECH', 'ED'],
        ['CIVIL', 'CV', 'CE', 'DIP CIVIL'],
        ['BT', 'BIOTECH', 'BIOTECHNOLOGY'],
        ['CSBS', 'CSE-BS', 'CS-BS', 'CSE - BS'],
        ['DS', 'CSE-DS'],
        ['CSE-IT', 'IOT', 'CSE-IOT'],
        ['CSE-CC', 'CC'],
        ['CSE-CY', 'CY', 'CYBER'],
        ['CSE-IY', 'IY']
    ];
    
    foreach ($groups as $group) {
        if (in_array($branch, $group)) {
            return $group;
        }
    }
    
    // Fallback for CSE prefix
    if (strpos($branch, 'CSE-') === 0) {
        return [$branch, substr($branch, 4)];
    }
    
    return [$branch];
}

/**
 * Get equivalent branches for a given branch name to handle GMU vs GMIT name differences
 * and hierarchical compatibility (e.g. BCA-CS matches job BCA, but BCA-DS does not match job BCA-CS).
 */
function getEquivalentBranches($branchName) {
    $branch = strtoupper(trim($branchName));
    
    $synonyms = getSynonymBranches($branch);
    $allCompat = $synonyms;
    
    // Group definitions of parent courses
    $courseGroups = [
        ['MBA', 'MBA-ADV', 'MBA-AM', 'MBA-IB', 'MBA-IE', 'MBA-INTNL', 'MBA-PF'],
        ['BBA', 'BBA-AI&BA', 'BBA-AM', 'BBA-B&F', 'BBA-BA', 'BBA-DM&E-COM', 'BBA-DMSM', 'BBA-GM', 'BBA-HM', 'BBA-HRM', 'BBA-IE', 'BBA-LSCM', 'BBA-MS', 'BBA-TH&EM'],
        ['BCA', 'BCA-AIDA', 'BCA-CS', 'BCA-CY', 'BCA-DS', 'BCA-GENERAL'],
        ['MCOM', 'MCOM-ATFA', 'MCOM-AFDB', 'MCOM-FAE'],
        ['MCA', 'MCA-AIDA', 'MCA-CY', 'MCA-DS'],
        ['BCOM', 'BCOM-A&T', 'BCOM-AF', 'BCOM-AI', 'BCOM-AT', 'BCOM-DA&BI', 'BCOM-F&A', 'BCOM-G'],
        [
            'BSC', 'BSC-B&TE', 'BSC-BT', 'BSC-BZ', 'BSC-C,B', 'BSC-C,CS', 'BSC-C,Z', 
            'BSC-CB', 'BSC-CCS', 'BSC-CZ', 'BSC-E,SC', 'BSC-FS&T', 'BSC-FST', 'BSC-IM', 
            'BSC-M,CS', 'BSC-M,P', 'BSC-MB', 'BSC-MCS', 'BSC-P,C', 'BSC-PC', 'BSC-PM', 
            'BSC-S,CS', 'BSC-SCS'
        ],
        ['LLB', 'LLB-BBA', 'LLB-BCOM'],
        ['MSC', 'MSC-AIDA', 'MSC-C', 'MSC-CY', 'MSC-DS', 'MSC-FT', 'MSC-M', 'MSC-P'],
        [
            'MTECH', 'MTECH-AE&ITS', 'MTECH-AIHC', 'MTECH-B&GT', 'MTECH-CASE', 'MTECH-DE', 
            'MTECH-DLDA', 'MTECH-PD&M', 'MTECH-S&GA', 'MTECH-SES&SE', 'MTECH-ST', 'MTECH-IS&IOT'
        ],
        [
            'PHD', 'PHD-AIM', 'PHD-BOT', 'PHD-BT', 'PHD-CA', 'PHD-CHE', 'PHD-COM', 'PHD-CSE', 
            'PHD-CV', 'PHD-ECE', 'PHD-EEE', 'PHD-ISE', 'PHD-MAT', 'PHD-ME', 'PHD-MS', 'PHD-PHY', 
            'PHD-RA', 'PHD-ZOO'
        ]
    ];
    
    // Check if the student branch (or any of its synonyms) belongs to any course group
    foreach ($courseGroups as $group) {
        $inGroup = false;
        foreach ($synonyms as $syn) {
            if (in_array($syn, $group)) {
                $inGroup = true;
                break;
            }
        }
        if ($inGroup) {
            // Parent is the first item in the group
            $parent = $group[0];
            $parentSynonyms = getSynonymBranches($parent);
            $allCompat = array_merge($allCompat, $parentSynonyms);
        }
    }
    
    return array_values(array_unique($allCompat));
}

/**
 * Encrypt/Obfuscate Job ID for URLs
 */
function encryptJobId($id) {
    $key = "LakshyaJobKey";
    $str = (string)$id;
    $result = '';
    for ($i = 0; $i < strlen($str); $i++) {
        $char = $str[$i];
        $keychar = $key[($i % strlen($key))];
        $result .= chr(ord($char) ^ ord($keychar));
    }
    return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($result));
}

/**
 * Decrypt/De-obfuscate Job ID from URLs
 */
function decryptJobId($code) {
    if (empty($code)) return 0;
    $key = "LakshyaJobKey";
    $data = str_replace(['-', '_'], ['+', '/'], $code);
    $mod = strlen($data) % 4;
    if ($mod) {
        $data .= str_repeat('=', 4 - $mod);
    }
    $str = base64_decode($data);
    if ($str === false) return 0;
    
    $result = '';
    for ($i = 0; $i < strlen($str); $i++) {
        $char = $str[$i];
        $keychar = $key[($i % strlen($key))];
        $result .= chr(ord($char) ^ ord($keychar));
    }
    return is_numeric($result) ? (int)$result : 0;
}

/**
 * Encrypt/Obfuscate Internship ID for URLs
 */
function encryptInternshipId($id) {
    $key = "LakshyaInternshipKey";
    $str = (string)$id;
    $result = '';
    for ($i = 0; $i < strlen($str); $i++) {
        $char = $str[$i];
        $keychar = $key[($i % strlen($key))];
        $result .= chr(ord($char) ^ ord($keychar));
    }
    return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($result));
}

/**
 * Decrypt/De-obfuscate Internship ID from URLs
 */
function decryptInternshipId($code) {
    if (empty($code)) return 0;
    $key = "LakshyaInternshipKey";
    $data = str_replace(['-', '_'], ['+', '/'], $code);
    $mod = strlen($data) % 4;
    if ($mod) {
        $data .= str_repeat('=', 4 - $mod);
    }
    $str = base64_decode($data);
    if ($str === false) return 0;
    
    $result = '';
    for ($i = 0; $i < strlen($str); $i++) {
        $char = $str[$i];
        $keychar = $key[($i % strlen($key))];
        $result .= chr(ord($char) ^ ord($keychar));
    }
    return is_numeric($result) ? (int)$result : 0;
}

/**
 * Render an announcement popup for a feature if set by admin
 * @param string $featureKey
 */
function renderFeatureAnnouncement($featureKey) {
    try {
        $db = getDB();
        if (!$db) return;
        
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ? LIMIT 1");
        $stmt->execute([$featureKey . '_message']);
        $message = $stmt->fetchColumn();
        
        if (empty($message)) return;
        
        $escapedMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $username = function_exists('getUsername') ? getUsername() : '';
        $jsKey = 'seen_announcement_' . $featureKey . ($username ? '_' . $username : '');
        
        ?>
        <style>
            .announcement-overlay {
                position: fixed;
                inset: 0;
                background: rgba(15, 23, 42, 0.5);
                backdrop-filter: blur(12px);
                -webkit-backdrop-filter: blur(12px);
                z-index: 99999;
                display: flex;
                align-items: center;
                justify-content: center;
                opacity: 0;
                transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1);
                pointer-events: none;
                padding: 16px;
                box-sizing: border-box;
            }
            .announcement-overlay.show {
                opacity: 1;
                pointer-events: all;
            }
            .announcement-box {
                background: rgba(255, 255, 255, 0.98);
                border: 1px solid rgba(255, 255, 255, 0.9);
                box-shadow: 0 25px 70px rgba(0, 0, 0, 0.25);
                border-radius: 28px;
                max-width: 500px;
                width: 100%;
                max-height: 86vh;
                max-height: 86dvh;
                display: flex;
                flex-direction: column;
                position: relative;
                overflow: hidden;
                transform: translateY(24px) scale(0.96);
                transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
                font-family: 'Outfit', 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
                box-sizing: border-box;
            }
            .announcement-overlay.show .announcement-box {
                transform: translateY(0) scale(1);
            }
            .announcement-close-btn {
                position: absolute;
                top: 16px;
                right: 16px;
                width: 32px;
                height: 32px;
                border-radius: 50%;
                background: #f1f5f9;
                border: none;
                color: #64748b;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 14px;
                cursor: pointer;
                transition: all 0.2s ease;
                z-index: 10;
            }
            .announcement-close-btn:hover {
                background: #e2e8f0;
                color: #0f172a;
                transform: scale(1.05);
            }
            .announcement-header {
                padding: 24px 24px 8px;
                text-align: center;
                flex-shrink: 0;
            }
            .announcement-icon {
                width: 48px;
                height: 48px;
                background: rgba(128, 0, 0, 0.08);
                color: #800000;
                font-size: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 14px;
                margin: 0 auto 10px;
                box-shadow: inset 0 2px 8px rgba(128, 0, 0, 0.05);
            }
            .announcement-title {
                font-size: 1.25rem;
                font-weight: 800;
                color: #0f172a;
                margin: 0 0 4px;
                letter-spacing: -0.02em;
            }
            .announcement-content {
                font-size: 0.88rem;
                color: #475569;
                line-height: 1.55;
                font-weight: 500;
                white-space: pre-wrap;
                overflow-y: auto;
                padding: 8px 24px 16px;
                flex: 1 1 auto;
                text-align: center;
            }
            .announcement-content::-webkit-scrollbar {
                width: 6px;
            }
            .announcement-content::-webkit-scrollbar-thumb {
                background: #cbd5e1;
                border-radius: 4px;
            }
            .announcement-content::-webkit-scrollbar-thumb:hover {
                background: #94a3b8;
            }
            .announcement-footer {
                padding: 12px 24px 20px;
                background: rgba(255, 255, 255, 0.95);
                border-top: 1px solid rgba(226, 232, 240, 0.8);
                text-align: center;
                flex-shrink: 0;
            }
            .announcement-btn {
                background: linear-gradient(135deg, #800000 0%, #5b1f1f 100%);
                color: white;
                border: none;
                width: 100%;
                max-width: 240px;
                padding: 11px 24px;
                font-size: 0.9rem;
                font-weight: 700;
                border-radius: 14px;
                cursor: pointer;
                transition: all 0.2s ease;
                box-shadow: 0 6px 16px rgba(128, 0, 0, 0.22);
            }
            .announcement-btn:hover {
                transform: translateY(-1px);
                box-shadow: 0 8px 20px rgba(128, 0, 0, 0.3);
                opacity: 0.97;
            }
            .announcement-btn:active {
                transform: translateY(0);
            }
        </style>
        <div id="announcement-modal" class="announcement-overlay" style="display: none;" onclick="if(event.target === this) dismissAnnouncement();">
            <div class="announcement-box" onclick="event.stopPropagation()">
                <button class="announcement-close-btn" onclick="dismissAnnouncement()" aria-label="Close Announcement" title="Close">
                    <i class="fas fa-times"></i>
                </button>
                <div class="announcement-header">
                    <div class="announcement-icon">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <h3 class="announcement-title">Announcement</h3>
                </div>
                <div class="announcement-content"><?php echo $escapedMessage; ?></div>
                <div class="announcement-footer">
                    <button onclick="dismissAnnouncement()" class="announcement-btn">Got it, thanks!</button>
                </div>
            </div>
        </div>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var message = <?php echo json_encode($message); ?>;
                var key = <?php echo json_encode($jsKey); ?>;
                var seen = localStorage.getItem(key);
                if (seen !== message) {
                    var modal = document.getElementById("announcement-modal");
                    if (modal) {
                        modal.style.display = "flex";
                        setTimeout(function() {
                            modal.classList.add("show");
                        }, 50);
                    }
                }
            });
            document.addEventListener("keydown", function(e) {
                if (e.key === "Escape") {
                    var modal = document.getElementById("announcement-modal");
                    if (modal && modal.classList.contains("show")) {
                        dismissAnnouncement();
                    }
                }
            });
            function dismissAnnouncement() {
                var message = <?php echo json_encode($message); ?>;
                var key = <?php echo json_encode($jsKey); ?>;
                localStorage.setItem(key, message);
                var modal = document.getElementById("announcement-modal");
                if (modal) {
                    modal.classList.remove("show");
                    setTimeout(function() {
                        modal.style.display = "none";
                    }, 300);
                }
                if (typeof window.onAnnouncementDismissed === 'function') {
                    window.onAnnouncementDismissed();
                }
            }
        </script>
        <?php
    } catch (\Exception $e) {
        // Fail silently
    }
}

/**
 * Generate a secure signed token for resume viewing (e.g. for Excel links)
 */
function generateResumeToken($usn) {
    $secret = defined('APP_KEY') ? APP_KEY : 'Lakshya_Secure_Resume_Key_2026';
    return substr(hash_hmac('sha256', strtoupper(trim($usn)), $secret), 0, 16);
}

/**
 * Verify a signed resume viewing token
 */
function verifyResumeToken($usn, $token) {
    if (empty($token) || empty($usn)) return false;
    $expected = generateResumeToken($usn);
    return hash_equals($expected, trim($token));
}
