<?php
/**
 * Get Student Internship History (AJAX)
 */

require_once __DIR__ . '/../../config/bootstrap.php';
requireRole('internship_officer');

$studentId = get('student_id');

if (!$studentId) {
    echo '<div style="text-align: center; padding: 2rem; color: #dc2626;"><p>Invalid Student USN / ID.</p></div>';
    exit;
}

$appModel = new InternshipApplication();
$history = $appModel->getByStudent($studentId);

if (empty($history)) {
    echo '<div style="text-align: center; padding: 2.5rem 1rem; color: #64748b;">
            <i class="far fa-folder-open" style="font-size: 2.5rem; color: #cbd5e1; margin-bottom: 0.75rem; display: block;"></i>
            <p style="font-size: 0.95rem; font-weight: 600;">No other internship applications found for this student.</p>
          </div>';
    exit;
}
?>
<div class="table-responsive" style="overflow-x: auto;">
    <table style="width: 100%; border-collapse: separate; border-spacing: 0 0.5rem; font-size: 0.88rem;">
        <thead>
            <tr style="text-align: left;">
                <th style="padding: 0.75rem 1rem; color: #475569; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid #f1f5f9;">Company</th>
                <th style="padding: 0.75rem 1rem; color: #475569; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid #f1f5f9;">Internship Role</th>
                <th style="padding: 0.75rem 1rem; color: #475569; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid #f1f5f9;">Applied Date</th>
                <th style="padding: 0.75rem 1rem; color: #475569; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; border-bottom: 2px solid #f1f5f9; text-align: center;">Outcome Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($history as $h): 
                $st = $h['status'] ?? 'Applied';
                $badgeStyle = match($st) {
                    'Selected' => 'background:#dcfce7; color:#166534; border:1px solid #bbf7d0;',
                    'Shortlisted', 'Interview' => 'background:#fef3c7; color:#92400e; border:1px solid #fde68a;',
                    'Rejected' => 'background:#fee2e2; color:#991b1b; border:1px solid #fecaca;',
                    default => 'background:#eff6ff; color:#1e40af; border:1px solid #bfdbfe;'
                };
            ?>
                <tr>
                    <td style="padding: 1rem; background: #f8fafc; border-top-left-radius: 10px; border-bottom-left-radius: 10px; font-weight: 700; color: #0f172a;">
                        <?php echo htmlspecialchars($h['company_name']); ?>
                    </td>
                    <td style="padding: 1rem; background: #f8fafc; font-size: 0.88rem; color: #334155;">
                        <?php echo htmlspecialchars($h['internship_title']); ?>
                    </td>
                    <td style="padding: 1rem; background: #f8fafc; font-size: 0.82rem; color: #64748b; font-weight: 600;">
                        <?php echo !empty($h['applied_at']) ? date('d M Y', strtotime($h['applied_at'])) : 'N/A'; ?>
                    </td>
                    <td style="padding: 1rem; background: #f8fafc; border-top-right-radius: 10px; border-bottom-right-radius: 10px; text-align: center;">
                        <span style="display: inline-block; padding: 0.28rem 0.65rem; border-radius: 6px; font-size: 0.75rem; font-weight: 700; <?php echo $badgeStyle; ?>">
                            <?php echo htmlspecialchars($st); ?>
                        </span>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
