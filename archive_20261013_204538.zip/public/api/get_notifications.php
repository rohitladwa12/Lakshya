<?php
/**
 * Lightweight Notification Polling API
 * Non-blocking, fast (<5ms) response to replace persistent SSE connections.
 */

require_once __DIR__ . '/../../config/bootstrap.php';

// 1. Authentication check
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

// 2. Release session lock immediately to prevent blocking other user requests
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

$notifications = [];

try {
    // 3. Try to fetch from Redis recent notifications cache
    $redis = \App\Helpers\RedisHelper::getInstance();
    if ($redis->isConnected()) {
        $rawItems = $redis->getClient()->lrange('campus_notifications_recent', 0, 9);
        if (!empty($rawItems)) {
            foreach ($rawItems as $item) {
                $decoded = json_decode($item, true);
                if ($decoded) {
                    $notifications[] = $decoded;
                }
            }
        }
    }
} catch (\Throwable $e) {
    error_log("Failed to fetch Redis notifications: " . $e->getMessage());
}

// 4. Fallback to recent active jobs if no Redis notifications exist
if (empty($notifications)) {
    try {
        $jobModel = new \App\Models\JobPosting();
        $recentJobs = $jobModel->getActiveJobs(3);
        if (!empty($recentJobs)) {
            foreach ($recentJobs as $job) {
                $notifications[] = [
                    'id' => $job['id'],
                    'type' => 'job_alert',
                    'title' => 'Opportunity: ' . $job['title'],
                    'subtitle' => ($job['company_name'] ?? 'Company') . ' is actively hiring',
                    'company_logo' => $job['company_logo'] ?? null,
                    'link' => 'jobs.php',
                    'time' => $job['created_at'] ?? date('c')
                ];
            }
        }
    } catch (\Throwable $e) {
        error_log("Failed to fetch fallback job notifications: " . $e->getMessage());
    }
}

echo json_encode([
    'success' => true,
    'notifications' => $notifications
]);
