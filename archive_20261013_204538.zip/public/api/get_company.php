<?php
/**
 * Get Company Details API
 */

header('Content-Type: application/json; charset=utf-8');

try {
    require_once __DIR__ . '/../../config/bootstrap.php';

    // Only logged in users
    if (!isLoggedIn()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }

    $companyId = get('id');
    if (!$companyId) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing Company ID']);
        exit;
    }

    $companyModel = new Company();
    $company = $companyModel->find($companyId);

    if (!$company) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Company not found']);
        exit;
    }

    $response = [
        'success' => true,
        'company' => $company,
        'spocs' => []
    ];

    // Only allow non-students (officers, coordinators, admins) to view SPOC details
    if (getUserRole() !== ROLE_STUDENT) {
        $response['spocs'] = $companyModel->getSpocs($companyId) ?: [];
    }

    echo json_encode($response);
    exit;

} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal Server Error: ' . $e->getMessage()
    ]);
    exit;
}
