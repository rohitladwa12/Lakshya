<?php
/**
 * Add Aptitude Questions Page
 * Dedicated page for coordinators to add multiple questions efficiently
 */

require_once __DIR__ . '/../../config/bootstrap.php';

// Auth check
requireRole(ROLE_DEPT_COORDINATOR);

$fullName = getFullName();
$db = getDB();

// Fetch existing companies for autocomplete/suggestions
$stmt = $db->query("SELECT DISTINCT company_name FROM manual_aptitude_questions ORDER BY company_name");
$companies = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aptitude Question Entry - <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-maroon: #800000;
            --primary-gold: #D4AF37;
            --secondary-gold: #f4e4bc;
            --white: #ffffff;
            --bg-light: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --shadow-lg: 0 10px 40px -10px rgba(0,0,0,0.1);
            --shadow-sm: 0 4px 6px -1px rgba(0,0,0,0.05);
            --radius-lg: 24px;
            --radius-md: 16px;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body { 
            font-family: 'Outfit', sans-serif; 
            background: var(--bg-light); 
            color: var(--text-main); 
            line-height: 1.6;
        }

        .navbar-spacer { height: 70px; }

        .container { 
            max-width: 1280px; 
            margin: 40px auto; 
            padding: 0 20px; 
            display: grid; 
            grid-template-columns: 1fr 400px; 
            gap: 40px; 
        }
        
        /* Header Section */
        .page-header { 
            margin-bottom: 30px; 
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }
        .page-header h2 { 
            font-size: 36px; 
            color: var(--primary-maroon); 
            font-weight: 800; 
            letter-spacing: -1px;
            margin-bottom: 5px;
        }
        .page-header p { 
            color: var(--text-muted); 
            font-size: 16px; 
        }

        .header-actions {
            display: flex; 
            gap: 12px;
        }

        .btn-action {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--primary-maroon);
            color: var(--primary-maroon);
        }
        .btn-outline:hover { background: #fff5f5; transform: translateY(-2px); }

        .btn-solid {
            background: var(--primary-maroon);
            color: white;
            border: 2px solid var(--primary-maroon);
        }
        .btn-solid:hover { background: #600000; border-color: #600000; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(128,0,0,0.2); }

        /* Form Card */
        .entry-card { 
            background: var(--white); 
            border-radius: var(--radius-lg); 
            padding: 40px; 
            box-shadow: var(--shadow-lg); 
            border: 1px solid rgba(0,0,0,0.02); 
            position: relative;
            overflow: hidden;
        }
        .entry-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 6px;
            background: linear-gradient(90deg, var(--primary-maroon), var(--primary-gold));
        }

        .form-section-title { 
            font-size: 14px; 
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700; 
            color: var(--text-muted); 
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            gap: 10px; 
        }
        .form-section-title::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e2e8f0;
        }

        .form-group { margin-bottom: 25px; position: relative; }
        .form-label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: 600; 
            font-size: 15px; 
            color: #334155; 
        }
        
        .form-control { 
            width: 100%; 
            padding: 14px 18px; 
            border: 2px solid #e2e8f0; 
            border-radius: 12px; 
            font-family: inherit; 
            font-size: 16px; 
            transition: all 0.3s; 
            background: #fdfdfd;
        }
        .form-control:focus { 
            border-color: var(--primary-card); 
            outline: none; 
            background: white;
            box-shadow: 0 0 0 4px rgba(128,0,0,0.05); 
            border-color: var(--primary-maroon);
        }
        
        textarea.form-control { 
            min-height: 120px; 
            resize: vertical; 
            line-height: 1.6;
        }
        
        /* Options Grid */
        .options-container {
            background: #f8fafc;
            padding: 25px;
            border-radius: var(--radius-md);
            border: 1px solid #e2e8f0;
            margin-bottom: 25px;
        }

        .options-grid { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 20px; 
        }
        
        .opt-input-group { position: relative; }
        .opt-badge {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            background: #e2e8f0;
            color: #64748b;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 13px;
            transition: 0.3s;
        }
        .opt-input { padding-left: 55px; }
        .opt-input:focus + .opt-badge, .opt-input:not(:placeholder-shown) + .opt-badge {
            background: var(--primary-maroon);
            color: white;
        } 
        /* Fix for badge not updating - CSS sibling selector requires input first */
        .opt-input-wrapper { position: relative; }
        .opt-input-wrapper input { padding-left: 55px; }
        .opt-input-wrapper .opt-badge { pointer-events: none; }

        /* Actions */
        .actions { display: flex; gap: 15px; margin-top: 40px; padding-top: 20px; border-top: 1px solid #f1f5f9; }
        .btn-submit { 
            background: var(--primary-maroon); 
            color: white; 
            flex: 2; 
            padding: 16px; 
            border-radius: 14px; 
            border: none; 
            font-weight: 700; 
            font-size: 16px; 
            cursor: pointer; 
            transition: 0.3s; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            gap: 10px; 
        }
        .btn-submit:hover { 
            background: #4a0000; 
            transform: translateY(-2px); 
            box-shadow: 0 10px 20px rgba(128,0,0,0.2); 
        }
        
        .btn-reset { 
            background: white; 
            color: #64748b; 
            flex: 1; 
            padding: 16px; 
            border-radius: 14px; 
            border: 2px solid #e2e8f0; 
            font-weight: 600; 
            cursor: pointer; 
            transition: 0.3s; 
        }
        .btn-reset:hover { background: #f8fafc; color: #334155; border-color: #cbd5e1; }

        /* Sidebar */
        .recent-sidebar { position: sticky; top: 100px; }
        .recent-card { 
            background: var(--white); 
            border-radius: var(--radius-lg); 
            padding: 30px; 
            box-shadow: var(--shadow-lg); 
            border: 1px solid rgba(0,0,0,0.02); 
        }
        .recent-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f1f5f9;
        }
        .recent-header h3 { font-size: 18px; font-weight: 700; color: #1e293b; }
        .live-indicator {
            display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: #10b981;
        }
        .live-dot { width: 8px; height: 8px; background: #10b981; border-radius: 50%; box-shadow: 0 0 0 3px rgba(16,185,129,0.2); animation: pulse 2s infinite; }
        
        @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(16,185,129,0.4); } 70% { box-shadow: 0 0 0 6px rgba(16,185,129,0); } 100% { box-shadow: 0 0 0 0 rgba(16,185,129,0); } }

        .recent-list { display: flex; flex-direction: column; gap: 15px; max-height: calc(100vh - 250px); overflow-y: auto; padding-right: 5px; }
        .recent-item { 
            padding: 16px; 
            border-radius: 16px; 
            background: white; 
            border: 1px solid #e2e8f0; 
            transition: all 0.2s; 
            position: relative;
        }
        .recent-item:hover { 
            border-color: var(--primary-gold); 
            box-shadow: 0 4px 12px rgba(212,175,55,0.1); 
            transform: translateX(2px);
        }
        .recent-company {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: #b45309;
            background: #fffbeb;
            padding: 4px 8px;
            border-radius: 6px;
            display: inline-block;
            margin-bottom: 8px;
        }
        .recent-text {
            font-size: 14px;
            font-weight: 600;
            color: #334155;
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .recent-time {
            font-size: 11px;
            color: #94a3b8;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Suggestions Dropdown */
        .company-suggestions { 
            position: absolute; 
            top: 100%;
            left: 0;
            background: white; 
            border: 1px solid #e2e8f0; 
            border-radius: 12px; 
            width: 100%; 
            z-index: 50; 
            margin-top: 8px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
            display: none; 
            max-height: 200px;
            overflow-y: auto;
        }
        .suggestion-item { 
            padding: 12px 18px; 
            cursor: pointer; 
            font-size: 14px; 
            transition: 0.2s;
            border-bottom: 1px solid #f8fafc;
        }
        .suggestion-item:last-child { border-bottom: none; }
        .suggestion-item:hover { background: #f8fafc; color: var(--primary-maroon); padding-left: 24px; }

        /* Toast */
        #toast { 
            position: fixed; 
            bottom: 40px; 
            right: 40px; 
            background: #0f172a; 
            color: white; 
            padding: 16px 30px; 
            border-radius: 16px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.2); 
            display: none; 
            align-items: center; 
            gap: 15px; 
            z-index: 2000; 
            animation: slideUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
            font-weight: 500;
        }
        @keyframes slideUp { from { transform: translateY(100px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        @media (max-width: 1024px) { .container { grid-template-columns: 1fr; } .recent-sidebar { display: none; } }
    </style>
</head>
<body>
    <?php include_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="container">
        <!-- Main Form Column -->
        <div class="main-column">
            <div class="page-header">
                <div>
                    <h2>Aptitude Entry</h2>
                    <p>Build the student assessment library</p>
                </div>
                <div class="header-actions">
                    <a href="manage_aptitude.php" class="btn-action btn-outline">
                        <i class="fas fa-tasks"></i> Manage All
                    </a>
                    <a href="dashboard" class="btn-action btn-solid">
                        <i class="fas fa-arrow-left"></i> Dashboard
                    </a>
                </div>
            </div>

            <div class="entry-card">
                <form id="aptiForm">
                    <div class="form-section-title"><i class="fas fa-building" style="color: var(--primary-gold)"></i> &nbsp; Context</div>
                    <div class="form-group">
                        <label class="form-label">Target Company</label>
                        <input type="text" name="company" id="companyInput" class="form-control" placeholder="Search or type company name..." required autocomplete="off">
                        <div id="companySuggestions" class="company-suggestions">
                            <?php foreach ($companies as $comp): ?>
                                <div class="suggestion-item" onclick="selectCompany('<?php echo addslashes($comp); ?>')">
                                    <i class="fas fa-briefcase" style="color: #cbd5e1; margin-right: 8px;"></i> <?php echo htmlspecialchars($comp); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-section-title"><i class="fas fa-question-circle" style="color: var(--primary-gold)"></i> &nbsp; The Question</div>
                    <div class="form-group">
                        <textarea name="question" id="questionText" class="form-control" placeholder="Type the question content here..." required></textarea>
                    </div>

                    <div class="options-container">
                        <div class="form-section-title" style="margin-bottom: 15px; border: none;"><i class="fas fa-list-ul" style="color: var(--primary-gold)"></i> &nbsp; Choices</div>
                        <div class="options-grid">
                            <div class="opt-input-wrapper">
                                <input type="text" name="option_a" class="form-control opt-input" placeholder="Option A" required>
                                <div class="opt-badge">A</div>
                            </div>
                            <div class="opt-input-wrapper">
                                <input type="text" name="option_b" class="form-control opt-input" placeholder="Option B" required>
                                <div class="opt-badge">B</div>
                            </div>
                            <div class="opt-input-wrapper">
                                <input type="text" name="option_c" class="form-control opt-input" placeholder="Option C" required>
                                <div class="opt-badge">C</div>
                            </div>
                            <div class="opt-input-wrapper">
                                <input type="text" name="option_d" class="form-control opt-input" placeholder="Option D" required>
                                <div class="opt-badge">D</div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Correct Answer</label>
                        <select name="correct_option" class="form-control" required style="cursor: pointer;">
                            <option value="">Select the correct option...</option>
                            <option value="A">Option A</option>
                            <option value="B">Option B</option>
                            <option value="C">Option C</option>
                            <option value="D">Option D</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Logic & Explanation <span style="font-weight: 400; color: #94a3b8; font-size: 13px;">(Optional but recommended)</span></label>
                        <textarea name="explanation" class="form-control" placeholder="Explain how to solve this question..." style="font-family: monospace; font-size: 14px; min-height: 80px;"></textarea>
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn-submit" id="saveBtn">
                            <i class="fas fa-save"></i> Save Question
                        </button>
                        <button type="button" class="btn-reset" onclick="resetForm()">
                            Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="recent-sidebar" id="recentSidebar">
            <div class="recent-card">
                <div class="recent-header">
                    <h3>Recent Activity</h3>
                    <div class="live-indicator"><div class="live-dot"></div> Live</div>
                </div>
                <div id="recentList" class="recent-list">
                    <!-- Loaded via JS -->
                    <div style="text-align: center; color: #cbd5e1; padding: 40px 0;">
                        <i class="fas fa-circle-notch fa-spin fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="toast">
        <div style="width: 24px; height: 24px; background: #22c55e; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
            <i class="fas fa-check" style="font-size: 12px; color: white;"></i>
        </div>
        <span id="toastMsg">Saved successfully!</span>
    </div>

    <script>
        // Company Autocomplete
        const companyInput = document.getElementById('companyInput');
        const suggestions = document.getElementById('companySuggestions');

        companyInput.onfocus = () => suggestions.style.display = 'block';
        
        // Better close handling
        document.addEventListener('click', function(e) {
            if (!companyInput.contains(e.target) && !suggestions.contains(e.target)) {
                suggestions.style.display = 'none';
            }
        });

        function selectCompany(name) {
            companyInput.value = name;
            suggestions.style.display = 'none';
        }

        function showToast(msg) {
            const toast = document.getElementById('toast');
            document.getElementById('toastMsg').innerText = msg;
            toast.style.display = 'flex';
            setTimeout(() => toast.style.display = 'none', 3000);
        }

        function resetForm() {
            document.getElementById('aptiForm').reset();
            companyInput.focus();
        }

        // Form Submission
        document.getElementById('aptiForm').onsubmit = async function(e) {
            e.preventDefault();
            const btn = document.getElementById('saveBtn');
            const originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Saving...';

            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            data.action = 'add_question';

            try {
                // Use extensionless URL as per .htaccess rules
                const res = await fetch('aptitude_handler', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await res.json();
                
                if (result.success) {
                    showToast('Question added to library');
                    // Keep company selection for easier bulk entry
                    const currentCompany = companyInput.value;
                    this.reset();
                    companyInput.value = currentCompany;
                    document.getElementById('questionText').focus();
                    loadRecent();
                } else {
                    alert('Error: ' + result.message);
                }
            } catch (err) {
                alert('Connection error. Check console.');
                console.error(err);
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
        };

        // Load Recent Additions
        async function loadRecent() {
            const list = document.getElementById('recentList');
            try {
                // Use extensionless URL
                const res = await fetch('aptitude_handler', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'get_recent' })
                });
                const result = await res.json();
                
                if (result.success && result.questions.length > 0) {
                    list.innerHTML = result.questions.map(q => `
                        <div class="recent-item">
                            <span class="recent-company">${q.company_name}</span>
                            <div class="recent-text">${q.question_text}</div>
                            <div class="recent-time">
                                <i class="far fa-clock"></i> ${new Date(q.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                        </div>
                    `).join('');
                } else {
                    list.innerHTML = `
                        <div style="text-align: center; color: #94a3b8; padding: 30px 0;">
                            <i class="far fa-folder-open" style="font-size: 24px; margin-bottom: 10px; opacity: 0.5;"></i>
                            <p style="font-size: 13px;">No questions added today</p>
                        </div>`;
                }
            } catch (err) {
                console.error(err);
                list.innerHTML = '<div style="text-align: center; color: #ef4444; font-size: 13px;">Failed to load feed</div>';
            }
        }

        loadRecent();
    </script>
</body>
</html>

