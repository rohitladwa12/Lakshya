<?php
require_once __DIR__ . '/../../config/bootstrap.php';
requireRole(ROLE_DEPT_COORDINATOR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Coding Problem - <?php echo APP_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-maroon: #800000;
            --primary-gold: #D4AF37;
            --secondary-gold: #f4e4bc;
            --bg-light: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --radius-lg: 24px;
            --shadow-lg: 0 10px 40px -10px rgba(0,0,0,0.1);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Outfit', sans-serif; background: var(--bg-light); color: var(--text-main); line-height: 1.6; }

        .container { 
            max-width: 1400px; 
            margin: 40px auto; 
            padding: 0 20px; 
            display: grid; 
            grid-template-columns: 1fr 350px; 
            gap: 40px; 
        }

        .page-header { 
            display: flex; justify-content: space-between; align-items: flex-end; 
            margin-bottom: 30px; border-bottom: 1px solid #e2e8f0; padding-bottom: 20px; 
        }
        .page-header h2 { font-size: 32px; color: var(--primary-maroon); font-weight: 800; }
        
        .entry-card { 
            background: white; border-radius: var(--radius-lg); padding: 40px; 
            box-shadow: var(--shadow-lg); 
            border-top: 6px solid var(--primary-maroon);
        }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-full { grid-column: span 2; }

        .form-group { margin-bottom: 20px; }
        .form-label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px; color: #334155; }
        .form-control { 
            width: 100%; padding: 12px 16px; border: 2px solid #e2e8f0; 
            border-radius: 12px; font-size: 15px; transition: 0.3s; 
        }
        .form-control:focus { border-color: var(--primary-maroon); outline: none; background: #fffdfc; }
        
        textarea.form-control { resize: vertical; min-height: 100px; font-family: 'Consolas', monospace; font-size: 13px; }

        .section-title { 
            grid-column: span 2; font-size: 14px; text-transform: uppercase; 
            letter-spacing: 1px; color: var(--text-muted); font-weight: 700; 
            margin: 30px 0 15px 0; display: flex; align-items: center; gap: 10px; 
        }
        .section-title::after { content: ''; flex: 1; height: 1px; background: #e2e8f0; }

        .btn-submit { 
            background: var(--primary-maroon); color: white; padding: 16px 32px; 
            border-radius: 12px; border: none; font-weight: 700; cursor: pointer; 
            width: 100%; font-size: 16px; transition: 0.3s;
        }
        .btn-submit:hover { background: #600000; transform: translateY(-2px); box-shadow: 0 10px 20px rgba(128,0,0,0.2); }

        /* Sidebar */
        .recent-card { background: white; border-radius: var(--radius-lg); padding: 25px; box-shadow: var(--shadow-lg); height: fit-content; position: sticky; top: 100px; }
        .recent-item { 
            padding: 15px; border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 15px; 
            transition: 0.2s; background: #f8fafc;
        }
        .recent-item:hover { border-color: var(--primary-gold); transform: translateX(5px); background: white; }
        .badge { 
            display: inline-block; padding: 2px 8px; border-radius: 6px; 
            font-size: 11px; font-weight: 700; text-transform: uppercase; 
        }
        .badge-Easy { background: #ecfdf5; color: #059669; }
        .badge-Medium { background: #fffbeb; color: #b45309; }
        .badge-Hard { background: #fef2f2; color: #b91c1c; }

        .btn-manage {
            text-decoration: none; color: white; background: var(--text-main); 
            padding: 10px 20px; border-radius: 10px; font-weight: 600; font-size: 14px;
        }

        #toast { 
            position: fixed; bottom: 30px; right: 30px; background: #0f172a; color: white; 
            padding: 15px 30px; border-radius: 12px; display: none; align-items: center; gap: 10px; 
            animation: slideUp 0.3s ease; 
        }
        @keyframes slideUp { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        @media (max-width: 1024px) { .container { grid-template-columns: 1fr; } .recent-card { display: none; } }
    </style>
</head>
<body>
    <?php include_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="container">
        <div>
            <div class="page-header">
                <div>
                    <h2><i class="fas fa-code"></i> Add Coding Problem</h2>
                    <p style="color: var(--text-muted);">Create new technical challenges for students</p>
                </div>
                <div>
                    <a href="manage_coding.php" class="btn-manage"><i class="fas fa-list"></i> Manage Problems</a>
                    <a href="dashboard" style="color: var(--primary-maroon); font-weight: 700; text-decoration: none; margin-left: 15px;">Dashboard</a>
                </div>
            </div>

            <div class="entry-card">
                <form id="codingForm" class="form-grid">
                    <!-- Basic Info -->
                    <div class="section-title"><i class="fas fa-info-circle"></i> Basic Info</div>
                    
                    <div class="form-group form-full">
                        <label class="form-label">Problem Title</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g., Reverse Linked List" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-control">
                            <option>Arrays</option>
                            <option>Strings</option>
                            <option>Linked Lists</option>
                            <option>Trees</option>
                            <option>DP</option>
                            <option>Sorting</option>
                            <option>Graphs</option>
                            <option>Recursion</option>
                            <option>Bit Manipulation</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Difficulty</label>
                        <select name="difficulty" class="form-control">
                            <option value="Easy">Easy</option>
                            <option value="Medium" selected>Medium</option>
                            <option value="Hard">Hard</option>
                        </select>
                    </div>

                    <!-- Problem Details -->
                    <div class="section-title"><i class="fas fa-align-left"></i> Problem Details</div>

                    <div class="form-group form-full">
                        <label class="form-label">Problem Statement</label>
                        <textarea name="problem_statement" class="form-control" rows="5" required placeholder="Describe the problem clearly..."></textarea>
                    </div>

                    <div class="form-group form-full">
                        <label class="form-label">Constraints</label>
                        <textarea name="constraints" class="form-control" rows="2" placeholder="- 1 <= n <= 10^5&#10;- Integers fit in 32-bit signed integer"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Example Input</label>
                        <textarea name="example_input" class="form-control" placeholder="nums = [2,7,11,15], target = 9"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Example Output</label>
                        <textarea name="example_output" class="form-control" placeholder="[0,1]"></textarea>
                    </div>

                    <!-- Solution Info -->
                    <div class="section-title"><i class="fas fa-lightbulb"></i> Solution & Analysis</div>

                    <div class="form-group form-full">
                        <label class="form-label">Concept Explanation (Hint/Solution)</label>
                        <textarea name="concept_explanation" class="form-control" rows="3" placeholder="Explain the approach (e.g., Use a hash map to store complements...)"></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Time Complexity</label>
                        <input type="text" name="time_complexity" class="form-control" placeholder="e.g., O(n)">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Space Complexity</label>
                        <input type="text" name="space_complexity" class="form-control" placeholder="e.g., O(1)">
                    </div>

                    <div class="form-full" style="margin-top: 20px;">
                        <button type="submit" class="btn-submit" id="saveBtn">
                            <i class="fas fa-plus-circle"></i> Add Problem to Library
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="recent-card">
            <h3 style="font-size: 18px; margin-bottom: 20px; color: #1e293b;">Recent Additions</h3>
            <div id="recentList">
                <div style="text-align: center; padding: 20px; color: #94a3b8;"><i class="fas fa-spinner fa-spin"></i></div>
            </div>
        </div>
    </div>

    <div id="toast"><i class="fas fa-check-circle"></i> Problem Added Successfully!</div>

    <script>
        document.getElementById('codingForm').onsubmit = async function(e) {
            e.preventDefault();
            const btn = document.getElementById('saveBtn');
            btn.disabled = true;
            btn.innerHTML = 'Saving...';

            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            data.action = 'add_problem';

            try {
                const res = await fetch('coding_handler', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await res.json();
                
                if (result.success) {
                    showToast();
                    this.reset();
                    loadRecent();
                    window.scrollTo(0,0);
                } else {
                    alert('Error: ' + result.message);
                }
            } catch (err) {
                alert('Connection failed');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-plus-circle"></i> Add Problem to Library';
            }
        };

        function showToast() {
            const t = document.getElementById('toast');
            t.style.display = 'flex';
            setTimeout(() => t.style.display = 'none', 3000);
        }

        async function loadRecent() {
            try {
                const res = await fetch('coding_handler', {
                    method: 'POST',
                    body: JSON.stringify({ action: 'get_recent' })
                });
                const data = await res.json();
                const list = document.getElementById('recentList');
                
                if (data.success && data.problems.length > 0) {
                    list.innerHTML = data.problems.map(p => `
                        <div class="recent-item">
                            <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                                <span class="badge badge-${p.difficulty}">${p.difficulty}</span>
                                <span style="font-size:11px; color:#94a3b8;">${p.category}</span>
                            </div>
                            <div style="font-weight:600; font-size:14px; color:#334155;">${p.title}</div>
                        </div>
                    `).join('');
                } else {
                    list.innerHTML = '<div style="color:#94a3b8; text-align:center;">No problems yet.</div>';
                }
            } catch (e) { console.error(e); }
        }

        loadRecent();
    </script>
</body>
</html>

