<?php
/**
 * Detailed Resume List - Admin View
 */

require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../../src/Models/Admin.php';

// Require admin role
requireRole(ROLE_ADMIN);

$fullName = getFullName();
$adminModel = new Admin();
// Extract unique departments and semesters for filter (from full list)
$allResumes = $adminModel->getDetailedResumeList();
$departments = array_unique(array_map(function($r) { 
    return $r['department']; 
}, $allResumes));
sort($departments);

$semesters = array_unique(array_filter(array_map(function($r) {
    return $r['semester'];
}, $allResumes), fn($s) => $s !== 'N/A' && !empty($s)));
sort($semesters);

// Filtering logic
$search = trim($_GET['search'] ?? '');
$deptFilter = trim($_GET['dept'] ?? '');
$semFilter = trim($_GET['sem'] ?? '');

$filteredResumes = array_filter($allResumes, function($r) use ($search, $deptFilter, $semFilter) {
    $matchesSearch = empty($search) || 
                     stripos($r['full_name'], $search) !== false || 
                     stripos($r['student_id'], $search) !== false;
    
    $matchesDept = empty($deptFilter) || $r['department'] === $deptFilter;
    $matchesSem = empty($semFilter) || $r['semester'] === $semFilter;
    
    return $matchesSearch && $matchesDept && $matchesSem;
});

// Pagination
$currentPage = (int)($_GET['page'] ?? 1);
$perPage = 20;
$paginationData = paginate($filteredResumes, $currentPage, $perPage);
$resumes = $paginationData['items'];
$pagination = $paginationData['pagination'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Central Resumes - Detailed List - <?php echo APP_NAME; ?></title>
    <!-- Use Outfit font from Google Fonts like student views -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-maroon: #800000;
            --primary-dark: #5b1f1f;
            --primary-gold: #e9c66f;
            --bg-color: #f4f7fe;
            --white: #ffffff;
            --text-dark: #2b3674;
            --text-muted: #a3aed1;
            --shadow: 0 10px 20px rgba(0,0,0,0.02);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Outfit', sans-serif;
            background: var(--bg-color);
            display: flex;
            min-height: 100vh;
        }

        /* Main Content Container */
        .main-content {
            flex: 1;
            padding: 40px;
            width: 100%;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            background: var(--white);
            padding: 20px 30px;
            border-radius: 20px;
            box-shadow: var(--shadow);
        }

        .header-title h1 {
            font-size: 24px;
            color: var(--text-dark);
            font-weight: 700;
        }

        .header-title p {
            color: var(--text-muted);
            font-size: 14px;
            margin-top: 5px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-profile .avatar {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, var(--primary-maroon) 0%, var(--primary-dark) 100%);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 18px;
            box-shadow: 0 4px 10px rgba(128, 0, 0, 0.2);
        }

        /* Table Area */
        .panel {
            background: var(--white);
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--shadow);
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .panel-title {
            color: var(--text-dark);
            font-size: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            text-align: left;
            padding: 15px 10px;
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 500;
            border-bottom: 1px solid #eef2f8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .data-table td {
            padding: 15px 10px;
            color: var(--text-dark);
            font-size: 14px;
            font-weight: 500;
            border-bottom: 1px solid #eef2f8;
        }

        .inst-badge {
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }
        .inst-gmu { background: #e3efff; color: #3965ff; }
        .inst-gmit { background: #e8fbed; color: #05cd99; }

        .btn-view {
            color: var(--primary-maroon);
            text-decoration: none;
            font-weight: 600;
            font-size: 13px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .btn-view:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        .back-link {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 20px;
            display: inline-block;
            transition: var(--transition);
        }

        .back-link:hover {
            color: var(--primary-maroon);
        }

        /* Filter Row Styling */
        .filter-row {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .filter-select {
            padding: 8px 15px;
            border-radius: 12px;
            border: 1px solid #eef2f8;
            color: var(--text-dark);
            font-family: inherit;
            font-size: 14px;
            outline: none;
            cursor: pointer;
            min-width: 200px;
        }

        .filter-select:focus {
            border-color: var(--primary-maroon);
        }

        .search-input {
            padding: 8px 15px;
            border-radius: 12px;
            border: 1px solid #eef2f8;
            font-family: inherit;
            font-size: 14px;
            min-width: 250px;
            outline: none;
        }

        .search-input:focus {
            border-color: var(--primary-maroon);
        }

        /* Pagination Styling */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
        }

        .pagination-btn {
            padding: 8px 16px;
            border-radius: 10px;
            background: var(--white);
            border: 1px solid #eef2f8;
            color: var(--text-dark);
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: var(--transition);
        }

        .pagination-btn:hover:not(.disabled) {
            background: var(--primary-maroon);
            color: var(--white);
            border-color: var(--primary-maroon);
        }

        .pagination-btn.active {
            background: var(--primary-maroon);
            color: var(--white);
            border-color: var(--primary-maroon);
        }

        .pagination-btn.disabled {
            color: var(--text-muted);
            cursor: not-allowed;
            opacity: 0.6;
        }

        .pagination-info {
            color: var(--text-muted);
            font-size: 14px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <?php include_once __DIR__ . '/includes/navbar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        
        <div class="header">
            <div class="header-title">
                <h1>Central Resumes</h1>
                <p>List of all students who have built their resumes on the platform.</p>
            </div>
            <div class="user-profile">
                <span style="font-weight: 600; color: var(--text-dark);"><?php echo htmlspecialchars($fullName); ?></span>
                <div class="avatar"><?php echo strtoupper(substr($fullName, 0, 1)); ?></div>
            </div>
        </div>

        <div class="panel">
            <div class="panel-header">
                <div class="panel-title">
                    <i class="fas fa-file-pdf" style="color: var(--primary-maroon);"></i> Student Resume Database 
                    <span style="font-weight: 400; font-size: 14px; color: var(--text-muted); margin-left: 10px;">
                        (<?php echo count($filteredResumes); ?> Matches out of <?php echo count($allResumes); ?>)
                    </span>
                </div>
                <form method="GET" class="filter-row">
                    <input type="text" name="search" class="search-input" placeholder="Search by name or USN..." value="<?php echo htmlspecialchars($search); ?>">
                    <select name="dept" class="filter-select" onchange="this.form.submit()">
                        <option value="">All Departments</option>
                        <?php foreach($departments as $dept): ?>
                            <option value="<?php echo htmlspecialchars($dept); ?>" <?php echo $deptFilter === $dept ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dept); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="sem" class="filter-select" onchange="this.form.submit()">
                        <option value="">All Semesters</option>
                        <?php foreach($semesters as $sm): ?>
                            <option value="<?php echo htmlspecialchars($sm); ?>" <?php echo $semFilter === $sm ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($sm); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" style="display: none;"></button>
                </form>
            </div>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>USN / ID</th>
                        <th>Institution</th>
                        <th>Department</th>
                        <th>Semester</th>
                        <th>Built Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="resumeTableBody">
                    <?php foreach($resumes as $r): ?>
                        <tr class="resume-row" data-department="<?php echo htmlspecialchars($r['department']); ?>">
                            <td>
                                <div style="font-weight: 700;"><?php echo htmlspecialchars($r['full_name']); ?></div>
                            </td>
                            <td><code style="background: #f0f0f0; padding: 2px 5px; border-radius: 4px; font-size: 12px;"><?php echo htmlspecialchars($r['student_id']); ?></code></td>
                            <td>
                                <span class="inst-badge <?php echo strtolower($r['institution']) === 'gmit' ? 'inst-gmit' : 'inst-gmu'; ?>">
                                    <?php echo htmlspecialchars($r['institution']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($r['department']); ?></td>
                            <td>
                                <span style="background: #f1f5f9; color: #334155; font-weight: 800; font-size: 11px; padding: 4px 8px; border-radius: 6px; display: inline-block;">
                                    <?php echo htmlspecialchars($r['semester'] ?? 'N/A'); ?>
                                </span>
                            </td>
                            <td style="color: var(--text-muted);">
                                <?php echo date('d M Y, h:i A', strtotime($r['built_at'])); ?>
                            </td>
                            <td>
                                <a href="../student/view_resume.php?usn=<?php echo urlencode($r['student_id']); ?>" target="_blank" class="btn-view">
                                    <i class="fas fa-external-link-alt"></i> View PDF
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($resumes)): ?>
                        <tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 50px;">No resumes found in the centralized database.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination UI -->
            <?php if ($pagination['total_pages'] > 1): ?>
                <div class="pagination">
                    <span class="pagination-info">
                        Showing <?php echo ($pagination['current_page'] - 1) * $perPage + 1; ?> to 
                        <?php echo min($pagination['current_page'] * $perPage, $pagination['total_items']); ?> of 
                        <?php echo $pagination['total_items']; ?>
                    </span>
                    
                    <a href="?page=1<?php echo $search ? '&search='.urlencode($search) : ''; ?><?php echo $deptFilter ? '&dept='.urlencode($deptFilter) : ''; ?><?php echo $semFilter ? '&sem='.urlencode($semFilter) : ''; ?>" 
                       class="pagination-btn <?php echo !$pagination['has_prev'] ? 'disabled' : ''; ?>">
                        <i class="fas fa-angle-double-left"></i>
                    </a>
                    
                    <a href="?page=<?php echo $pagination['current_page'] - 1; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?><?php echo $deptFilter ? '&dept='.urlencode($deptFilter) : ''; ?><?php echo $semFilter ? '&sem='.urlencode($semFilter) : ''; ?>" 
                       class="pagination-btn <?php echo !$pagination['has_prev'] ? 'disabled' : ''; ?>">
                        <i class="fas fa-angle-left"></i> Prev
                    </a>

                    <?php 
                    $startPage = max(1, $pagination['current_page'] - 2);
                    $endPage = min($pagination['total_pages'], $startPage + 4);
                    if ($endPage - $startPage < 4) $startPage = max(1, $endPage - 4);
                    
                    for($i = $startPage; $i <= $endPage; $i++): 
                    ?>
                        <a href="?page=<?php echo $i; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?><?php echo $deptFilter ? '&dept='.urlencode($deptFilter) : ''; ?><?php echo $semFilter ? '&sem='.urlencode($semFilter) : ''; ?>" 
                           class="pagination-btn <?php echo $pagination['current_page'] == $i ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>

                    <a href="?page=<?php echo $pagination['current_page'] + 1; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?><?php echo $deptFilter ? '&dept='.urlencode($deptFilter) : ''; ?><?php echo $semFilter ? '&sem='.urlencode($semFilter) : ''; ?>" 
                       class="pagination-btn <?php echo !$pagination['has_next'] ? 'disabled' : ''; ?>">
                        Next <i class="fas fa-angle-right"></i>
                    </a>
                    
                    <a href="?page=<?php echo $pagination['total_pages']; ?><?php echo $search ? '&search='.urlencode($search) : ''; ?><?php echo $deptFilter ? '&dept='.urlencode($deptFilter) : ''; ?><?php echo $semFilter ? '&sem='.urlencode($semFilter) : ''; ?>" 
                       class="pagination-btn <?php echo !$pagination['has_next'] ? 'disabled' : ''; ?>">
                        <i class="fas fa-angle-double-right"></i>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Use a simple timeout to avoid too many requests while typing
        let searchTimeout = null;
        document.querySelector('.search-input').addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.form.submit();
            }, 500);
        });
    </script>
</body>
</html>

