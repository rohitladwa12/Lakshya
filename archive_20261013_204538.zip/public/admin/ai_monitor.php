<?php
require_once __DIR__ . '/../../config/bootstrap.php';
requireLogin();
if (Session::getRole() !== 'admin') {
    die("Access denied. Please log in as an administrator.");
}

function formatNumberIndian($num) {
    $num = (int)$num;
    $isNegative = $num < 0;
    $numStr = (string)abs($num);
    $len = strlen($numStr);
    if ($len <= 3) {
        return ($isNegative ? '-' : '') . $numStr;
    }
    $lastThree = substr($numStr, -3);
    $remaining = substr($numStr, 0, -3);
    $reversedRemaining = strrev($remaining);
    $chunks = str_split($reversedRemaining, 2);
    $formattedRemaining = strrev(implode(',', $chunks));
    return ($isNegative ? '-' : '') . $formattedRemaining . ',' . $lastThree;
}

$db = getDB();

require_once __DIR__ . '/../../src/Helpers/RedisHelper.php';
use App\Helpers\RedisHelper;

$redisHelper = RedisHelper::getInstance();
$cachedStats = $redisHelper->get('ai_monitor:aggregate_stats');

if ($cachedStats && is_array($cachedStats)) {
    $stats = $cachedStats['stats'];
    $totalCostStats = $cachedStats['totalCostStats'];
    $serviceStats = $cachedStats['serviceStats'];
    $aiTrendData = $cachedStats['aiTrendData'] ?? [];
    $serviceHealthStats = $cachedStats['serviceHealthStats'] ?? [];
} else {
    // Overall Stats (Separating Input and Output tokens for precise cost)
    $stats = $db->query("SELECT 
        COUNT(*) as total_requests,
        SUM(prompt_tokens) as total_prompt_tokens,
        SUM(completion_tokens) as total_completion_tokens,
        SUM(total_tokens) as total_tokens,
        AVG(latency_ms) as avg_latency,
        SUM(CASE WHEN status != 'success' THEN 1 ELSE 0 END) as failures
    FROM ai_audit_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)")->fetch(PDO::FETCH_ASSOC);

    // Total Cost Estimation & All-Time Stats
    $totalCostStats = $db->query("SELECT 
        COUNT(*) as total_all_time_requests,
        SUM(prompt_tokens) as total_prompt_tokens,
        SUM(completion_tokens) as total_completion_tokens,
        SUM(total_tokens) as total_tokens
    FROM ai_audit_logs")->fetch(PDO::FETCH_ASSOC);

    // By Service
    $serviceStats = $db->query("SELECT 
        service_method, 
        COUNT(*) as count, 
        SUM(total_tokens) as tokens,
        AVG(latency_ms) as latency
    FROM ai_audit_logs 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY service_method 
    ORDER BY tokens DESC")->fetchAll(PDO::FETCH_ASSOC);

    // 7-Day AI Request & Token Volume Trend
    $aiTrendData = $db->query("
        SELECT 
            DATE(created_at) as log_date,
            COUNT(*) as requests,
            SUM(prompt_tokens) as prompt_tokens,
            SUM(completion_tokens) as completion_tokens,
            SUM(total_tokens) as total_tokens,
            ROUND(AVG(latency_ms), 0) as avg_latency
        FROM ai_audit_logs
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY log_date ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Service Health & Latency Telemetry
    $serviceHealthStats = $db->query("
        SELECT 
            service_method,
            SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success_count,
            SUM(CASE WHEN status != 'success' THEN 1 ELSE 0 END) as fail_count,
            ROUND(AVG(latency_ms), 0) as avg_latency
        FROM ai_audit_logs
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY service_method
        ORDER BY COUNT(*) DESC
        LIMIT 8
    ")->fetchAll(PDO::FETCH_ASSOC);

    $redisHelper->set('ai_monitor:aggregate_stats', [
        'stats' => $stats,
        'totalCostStats' => $totalCostStats,
        'serviceStats' => $serviceStats,
        'aiTrendData' => $aiTrendData,
        'serviceHealthStats' => $serviceHealthStats
    ], 30); // cache for 30 seconds
}

// Cost Estimation (gpt-4o-mini: $0.15 / 1M input tokens, $0.60 / 1M output tokens)
$promptCost = (($stats['total_prompt_tokens'] ?? 0) / 1000) * 0.00015;
$completionCost = (($stats['total_completion_tokens'] ?? 0) / 1000) * 0.00060;
$estimatedCost = $promptCost + $completionCost;

$totalPromptCost = (($totalCostStats['total_prompt_tokens'] ?? 0) / 1000) * 0.00015;
$totalCompletionCost = (($totalCostStats['total_completion_tokens'] ?? 0) / 1000) * 0.00060;
$totalEstimatedCost = $totalPromptCost + $totalCompletionCost;

// Status Filter
$statusFilter = $_GET['status'] ?? 'all';
$statusWhere = "";
if ($statusFilter === 'success') {
    $statusWhere = "WHERE status = 'success'";
} else if ($statusFilter === 'failed') {
    $statusWhere = "WHERE status != 'success'";
}

// Recent Logs with Pagination (20 per page)
$limit = 20;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

$totalRows = $db->query("SELECT COUNT(*) FROM ai_audit_logs $statusWhere")->fetchColumn();
$totalPages = max(1, ceil($totalRows / $limit));

$recentLogs = $db->query("SELECT * FROM ai_audit_logs $statusWhere ORDER BY created_at DESC LIMIT $limit OFFSET $offset")->fetchAll(PDO::FETCH_ASSOC);

// Worker Health (Redis)
$redis = $redisHelper->getClient();
$workerPulses = $redis->hgetall('ai_workers_pulse');
$activeWorkers = [];
$now = time();
foreach ($workerPulses as $id => $time) {
    if ($now - $time < 300) { // Keep in list for 5 mins
        $activeWorkers[$id] = [
            'last_seen' => $time,
            'is_alive' => ($now - $time < 60),
            'memory' => $redis->hget('ai_workers_memory', $id) ?? 'N/A',
            'jobs' => $redis->hget('ai_workers_jobs', $id) ?? 0
        ];
    } else {
        $redis->hdel('ai_workers_pulse', $id);
        $redis->hdel('ai_workers_memory', $id);
        $redis->hdel('ai_workers_jobs', $id);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Performance Monitor - <?php echo APP_NAME; ?></title>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        :root {
            --primary-maroon: #800000;
            --primary-dark: #1a1a1a;
            --accent-blue: #0066cc;
            --white: #ffffff;
            --bg-light: #f5f6f8;
            --text-dark: #2c3e50;
            --text-muted: #7f8c8d;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            --border: #edf2f7;
            --success: #10b981;
            --danger: #ef4444;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: 'Outfit', sans-serif;
            background: var(--bg-light);
            color: var(--text-dark);
            min-height: 100vh;
        }

        .main-content {
            padding: 40px;
            width: 100%;
            max-width: 1600px;
            margin: 0 auto;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            background: white;
            padding: 25px 35px;
            border-radius: 24px;
            box-shadow: var(--shadow);
        }

        .header-title h1 {
            font-size: 26px;
            font-weight: 800;
            color: var(--primary-maroon);
        }
        
        .header-title p {
            font-size: 14px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        /* Metrics Grid */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .metric-card {
            background: var(--white);
            padding: 28px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        .metric-card:hover {
            transform: translateY(-5px);
        }

        .metric-card .label {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 1px;
            margin-bottom: 12px;
        }

        .metric-card .value {
            font-size: 32px;
            font-weight: 800;
            color: var(--primary-dark);
        }

        .metric-card .trend {
            font-size: 13px;
            margin-top: 8px;
            color: var(--text-muted);
        }

        /* Tables */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            gap: 25px;
            margin-bottom: 40px;
        }

        .content-card {
            background: white;
            border-radius: 24px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .card-header {
            padding: 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h2 {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-dark);
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f8fafc;
            padding: 16px 24px;
            text-align: left;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 700;
        }

        .badge-success { background: #dcfce7; color: #166534; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-primary { background: #e0f2fe; color: #0369a1; }

        .usn-font {
            font-family: 'JetBrains Mono', monospace;
            font-weight: 600;
            color: var(--primary-maroon);
        }

        @media (max-width: 1100px) {
            .dashboard-grid { grid-template-columns: 1fr; }
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 20px;
            border-top: 1px solid var(--border);
            background: #fafbfc;
        }

        .pagination-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 36px;
            height: 36px;
            padding: 0 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
            background: var(--white);
            color: var(--text-dark);
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
        }

        .pagination-btn:hover:not(.disabled) {
            border-color: var(--primary-maroon);
            color: var(--primary-maroon);
            background: #fff8f8;
        }

        .pagination-btn.active {
            background: var(--primary-maroon);
            color: var(--white);
            border-color: var(--primary-maroon);
        }

        .pagination-btn.disabled {
            color: var(--text-muted);
            background: var(--bg-light);
            cursor: not-allowed;
            opacity: 0.6;
        }
    </style>
</head>
<body>
    <?php include_once __DIR__ . '/includes/navbar.php'; ?>

    <main class="main-content">
        <div class="header-section">
            <div class="header-title">
                <h1>AI Performance Monitor</h1>
                <p>Telemetry for LAKSHYA's Parallel AI Infrastructure</p>
            </div>
            <div class="badge badge-primary" style="font-size: 13px; padding: 8px 16px;">
                <i class="fas fa-sync-alt fa-spin mr-2"></i> Live Telemetry
            </div>
        </div>

        <!-- Metrics Area -->
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="label">Total Requests (24h)</div>
                <div class="value"><?php echo formatNumberIndian($stats['total_requests'] ?? 0); ?></div>
                <div class="trend">Last 24 hours</div>
            </div>

            <div class="metric-card">
                <div class="label">All-Time Requests</div>
                <div class="value" style="color: var(--accent-blue);"><?php echo formatNumberIndian($totalCostStats['total_all_time_requests'] ?? 0); ?></div>
                <div class="trend">Cumulative AI requests</div>
            </div>
            
            <div class="metric-card">
                <div class="label">Est. Cost (Total)</div>
                <div class="value">$<?php echo number_format($totalEstimatedCost, 4); ?></div>
                <div class="trend">Based on all-time token usage</div>
            </div>

            <div class="metric-card">
                <div class="label">Total Tokens Used</div>
                <div class="value"><?php echo formatNumberIndian($totalCostStats['total_tokens'] ?? (($totalCostStats['total_prompt_tokens'] ?? 0) + ($totalCostStats['total_completion_tokens'] ?? 0))); ?></div>
                <div class="trend">All-time token consumption</div>
            </div>

            <div class="metric-card">
                <div class="label">Parallel Workers</div>
                <div class="value"><?php 
                    echo count(array_filter($activeWorkers, function($w) { return $w['is_alive']; })); 
                ?></div>
                <div class="trend">Active background instances</div>
            </div>

            <div class="metric-card">
                <div class="label">System Failures</div>
                <div class="value" style="color: var(--danger);"><?php echo $stats['failures']; ?></div>
                <div class="trend">Critical errors (24h)</div>
            </div>

            <div class="metric-card rpm-card">
                <div class="label">Requests / Min</div>
                <div class="value" id="rpm-value" style="color: var(--accent-blue);">—</div>
                <div class="trend">
                    <span id="rpm-status" style="display:inline-flex;align-items:center;gap:5px;">
                        <span id="rpm-dot" style="width:8px;height:8px;border-radius:50%;background:#10b981;display:inline-block;animation:rpm-pulse 2s infinite;"></span>
                        Live · updates every 15s
                    </span>
                </div>
            </div>
        </div>

        <!-- AI Infrastructure Telemetry Charts Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(480px, 1fr)); gap: 25px; margin-bottom: 40px;">
            <!-- Chart 1: AI Token & Request Volume Trend (7D) -->
            <div class="content-card" style="padding: 24px; display: flex; flex-direction: column; min-height: 420px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-size: 16px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 8px;">
                        <i class="fas fa-chart-line" style="color: var(--primary-maroon);"></i> AI Token & Request Volume Trend (7D)
                    </h2>
                    <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); background: #f1f5f9; padding: 4px 10px; border-radius: 8px;">7-Day History</span>
                </div>
                <div style="flex: 1; position: relative; min-height: 320px;">
                    <canvas id="aiTrendChart"></canvas>
                </div>
            </div>

            <!-- Chart 2: Input vs Output Token & Cost Share -->
            <div class="content-card" style="padding: 24px; display: flex; flex-direction: column; min-height: 420px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-size: 16px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 8px;">
                        <i class="fas fa-chart-pie" style="color: var(--accent-blue);"></i> Input vs Output Token Breakdown
                    </h2>
                    <span style="font-size: 11px; font-weight: 700; color: var(--success); background: #ecfdf5; padding: 4px 10px; border-radius: 8px;">Cost Model: gpt-4o-mini</span>
                </div>
                <div style="flex: 1; position: relative; display: flex; align-items: center; justify-content: center; min-height: 320px;">
                    <canvas id="tokenDistChart" style="max-height: 300px; max-width: 300px;"></canvas>
                </div>
            </div>

            <!-- Chart 3: AI Service Method Token Share -->
            <div class="content-card" style="padding: 24px; display: flex; flex-direction: column; min-height: 420px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-size: 16px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 8px;">
                        <i class="fas fa-server" style="color: #8b5cf6;"></i> Service Method Token Consumption
                    </h2>
                    <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); background: #f1f5f9; padding: 4px 10px; border-radius: 8px;">Top AI Endpoints</span>
                </div>
                <div style="flex: 1; position: relative; min-height: 320px;">
                    <canvas id="serviceTokenChart"></canvas>
                </div>
            </div>

            <!-- Chart 4: Service Telemetry & Success / Failure Rate -->
            <div class="content-card" style="padding: 24px; display: flex; flex-direction: column; min-height: 420px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-size: 16px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 8px;">
                        <i class="fas fa-microchip" style="color: #f59e0b;"></i> Endpoint Telemetry (Success vs Failure)
                    </h2>
                    <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); background: #f1f5f9; padding: 4px 10px; border-radius: 8px;">Last 7 Days</span>
                </div>
                <div style="flex: 1; position: relative; min-height: 320px;">
                    <canvas id="serviceLatencyChart"></canvas>
                </div>
            </div>
        </div>

        <div class="dashboard-grid">
            <!-- Service Breakdown -->
            <div class="content-card">
                <div class="card-header">
                    <h2>Service Usage (7D)</h2>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Method</th>
                                <th>Calls</th>
                                <th>Tokens</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($serviceStats as $s): ?>
                            <tr>
                                <td><code style="color: var(--accent-blue);"><?php echo $s['service_method']; ?></code></td>
                                <td><strong><?php echo $s['count']; ?></strong></td>
                                <td><?php echo number_format($s['tokens']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Recent Logs -->
            <div class="content-card">
                <div class="card-header">
                    <h2>Live Request Stream</h2>
                    <select id="statusFilter" onchange="window.location.href='?status=' + this.value;" style="padding: 4px 8px; font-size: 13px; border-radius: 8px; border: 1px solid var(--border); outline: none;">
                        <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="success" <?php echo $statusFilter === 'success' ? 'selected' : ''; ?>>Success</option>
                        <option value="failed" <?php echo $statusFilter === 'failed' ? 'selected' : ''; ?>>Failed</option>
                    </select>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Method</th>
                                <th>Tokens</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentLogs as $log): ?>
                            <tr class="stream-row" data-status="<?php echo strtolower($log['status']); ?>">
                                <td style="color: var(--text-muted);"><?php echo date('M d, H:i:s', strtotime($log['created_at'])); ?></td>
                                <td><?php echo $log['service_method']; ?></td>
                                <td><?php echo $log['total_tokens']; ?></td>
                                <td>
                                    <span class="badge <?php echo $log['status'] === 'success' ? 'badge-success' : 'badge-danger'; ?>">
                                        <?php echo ucfirst($log['status']); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($statusFilter); ?>" class="pagination-btn <?php echo $page <= 1 ? 'disabled' : ''; ?>" <?php echo $page <= 1 ? 'onclick="return false;"' : ''; ?>>
                        <i class="fas fa-chevron-left"></i>
                    </a>
                    
                    <?php
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    
                    if ($startPage > 1) {
                        echo '<a href="?page=1&status=' . urlencode($statusFilter) . '" class="pagination-btn">1</a>';
                        if ($startPage > 2) {
                            echo '<span style="color: var(--text-muted); padding: 0 4px;">...</span>';
                        }
                    }
                    
                    for ($i = $startPage; $i <= $endPage; $i++) {
                        $activeClass = $i === $page ? 'active' : '';
                        echo "<a href='?page=$i&status=" . urlencode($statusFilter) . "' class='pagination-btn $activeClass'>$i</a>";
                    }
                    
                    if ($endPage < $totalPages) {
                        if ($endPage < $totalPages - 1) {
                            echo '<span style="color: var(--text-muted); padding: 0 4px;">...</span>';
                        }
                        echo "<a href='?page=$totalPages&status=" . urlencode($statusFilter) . "' class='pagination-btn'>$totalPages</a>";
                    }
                    ?>
                    
                    <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($statusFilter); ?>" class="pagination-btn <?php echo $page >= $totalPages ? 'disabled' : ''; ?>" <?php echo $page >= $totalPages ? 'onclick="return false;"' : ''; ?>>
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Worker Registry -->
        <div class="content-card">
            <div class="card-header">
                <h2>AI Worker Registry</h2>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Worker Identifier</th>
                            <th>Job Load</th>
                            <th>Memory</th>
                            <th>Last Heartbeat</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($activeWorkers)): ?>
                            <tr><td colspan="5" class="text-center" style="padding: 40px; color: var(--text-muted);">No active workers detected.</td></tr>
                        <?php else: ?>
                            <?php foreach ($activeWorkers as $id => $w): ?>
                            <tr>
                                <td><code class="usn-font"><?php echo $id; ?></code></td>
                                <td><strong><?php echo $w['jobs']; ?></strong> jobs</td>
                                <td><span style="color: var(--text-muted);"><?php echo $w['memory']; ?></span></td>
                                <td><?php echo date('H:i:s', $w['last_seen']); ?> <small style="color: var(--text-muted);">(<?php echo time() - $w['last_seen']; ?>s ago)</small></td>
                                <td>
                                    <?php if ($w['is_alive']): ?>
                                        <span class="badge badge-success">Online</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Offline</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Global Maintenance Interceptor -->
    <script src="<?php echo APP_URL; ?>/js/maintenance_interceptor.js"></script>

    <script>
    (function () {
        const el    = document.getElementById('rpm-value');
        const dot   = document.getElementById('rpm-dot');
        const BASE  = '<?php echo APP_URL; ?>/admin/ajax/ai_rpm.php';

        function animateCount(from, to, duration) {
            const start = performance.now();
            function step(now) {
                const t = Math.min((now - start) / duration, 1);
                const ease = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
                const val = from + (to - from) * ease;
                el.textContent = Number.isInteger(to) ? Math.round(val) : val.toFixed(2);
                if (t < 1) requestAnimationFrame(step);
            }
            requestAnimationFrame(step);
        }

        function fetchRPM() {
            dot.style.background = '#f59e0b'; // amber while fetching
            fetch(BASE)
                .then(r => r.json())
                .then(data => {
                    const prev = parseFloat(el.textContent) || 0;
                    const rpm  = data.rpm ?? 0;
                    animateCount(prev, rpm, 600);
                    dot.style.background = '#10b981'; // green on success
                })
                .catch(() => {
                    dot.style.background = '#ef4444'; // red on error
                    el.textContent = 'err';
                });
        }

        // ----------------------------------------------------
        // Chart 1: AI Token & Request Volume Trend (7D)
        // ----------------------------------------------------
        const trendCtx = document.getElementById('aiTrendChart').getContext('2d');
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_map(function($x) { return date('M d', strtotime($x['log_date'])); }, $aiTrendData)); ?>,
                datasets: [
                    {
                        label: 'Total Tokens Consumed',
                        data: <?php echo json_encode(array_column($aiTrendData, 'total_tokens')); ?>,
                        borderColor: '#800000',
                        backgroundColor: 'rgba(128, 0, 0, 0.08)',
                        fill: true,
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'AI Requests Count',
                        data: <?php echo json_encode(array_column($aiTrendData, 'requests')); ?>,
                        borderColor: '#0066cc',
                        backgroundColor: 'rgba(0, 102, 204, 0.08)',
                        fill: true,
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: { display: true, text: 'Tokens' }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        grid: { drawOnChartArea: false },
                        title: { display: true, text: 'Requests' }
                    }
                },
                plugins: {
                    legend: { position: 'top', labels: { font: { family: 'Outfit', weight: '600' } } }
                }
            }
        });

        // ----------------------------------------------------
        // Chart 2: Input vs Output Token Breakdown (Doughnut)
        // ----------------------------------------------------
        const tokenCtx = document.getElementById('tokenDistChart').getContext('2d');
        new Chart(tokenCtx, {
            type: 'doughnut',
            data: {
                labels: ['Prompt Input Tokens', 'Completion Output Tokens'],
                datasets: [{
                    data: [
                        <?php echo (int)($totalCostStats['total_prompt_tokens'] ?? 0); ?>,
                        <?php echo (int)($totalCostStats['total_completion_tokens'] ?? 0); ?>
                    ],
                    backgroundColor: ['#0066cc', '#10b981'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { font: { family: 'Outfit', weight: '600' } } }
                }
            }
        });

        // ----------------------------------------------------
        // Chart 3: AI Service Method Token Share (Horizontal Bar)
        // ----------------------------------------------------
        const serviceTokenCtx = document.getElementById('serviceTokenChart').getContext('2d');
        new Chart(serviceTokenCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($serviceStats, 'service_method')); ?>,
                datasets: [{
                    label: 'Total Tokens',
                    data: <?php echo json_encode(array_column($serviceStats, 'tokens')); ?>,
                    backgroundColor: '#8b5cf6',
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false }
                }
            }
        });

        // ----------------------------------------------------
        // Chart 4: Service Telemetry (Success vs Fail & Latency)
        // ----------------------------------------------------
        const latencyCtx = document.getElementById('serviceLatencyChart').getContext('2d');
        new Chart(latencyCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($serviceHealthStats, 'service_method')); ?>,
                datasets: [
                    {
                        label: 'Success Count',
                        data: <?php echo json_encode(array_column($serviceHealthStats, 'success_count')); ?>,
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    },
                    {
                        label: 'Fail / Retry Count',
                        data: <?php echo json_encode(array_column($serviceHealthStats, 'fail_count')); ?>,
                        backgroundColor: '#ef4444',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', labels: { font: { family: 'Outfit', weight: '600' } } }
                }
            }
        });

        // Initial fetch on page load
        fetchRPM();
        // Refresh every 15 seconds
        setInterval(fetchRPM, 15000);
    })();
    </script>

    <style>
    @keyframes rpm-pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%       { opacity: 0.4; transform: scale(0.7); }
    }
    </style>
</body>
</html>
