<?php
/**
 * Placement Officer - Get SGPA Details (AJAX)
 * Returns SGPA for semesters 1-8 for a given student.
 */

require_once __DIR__ . '/../../config/bootstrap.php';

requireRole(ROLE_PLACEMENT_OFFICER);

header('Content-Type: application/json');

$usn = trim((string)($_POST['usn'] ?? ''));
$institution = trim((string)($_POST['institution'] ?? ''));

if ($usn === '' || !in_array($institution, [INSTITUTION_GMU, INSTITUTION_GMIT], true)) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

try {
    $db = getDB('gmu');
    $localDB = getDB();
    $sgpaData = array_fill(1, 8, '-');

    if ($institution === INSTITUTION_GMIT) {
        $stmt = $localDB->prepare("SELECT semester, sgpa FROM student_sem_sgpa WHERE student_id = ? AND institution = ? ORDER BY semester");
        $stmt->execute([$usn, INSTITUTION_GMIT]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $sem = (int)$row['semester'];
            if ($sem >= 1 && $sem <= 8) {
                $sgpaData[$sem] = $row['sgpa'] ? number_format($row['sgpa'], 2) : '-';
            }
        }
    } else {
        $prefix = DB_GMU_PREFIX;
        $stmt = $db->prepare("SELECT sem, sgpa FROM {$prefix}ad_student_approved WHERE usn = ? ORDER BY sem");
        $stmt->execute([$usn]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $sem = (int)$row['sem'];
            if ($sem >= 1 && $sem <= 8) {
                $sgpaData[$sem] = $row['sgpa'] ? number_format($row['sgpa'], 2) : '-';
            }
        }
    }

    echo json_encode([
        'success' => true,
        'usn' => $usn,
        'institution' => $institution,
        'sgpa' => $sgpaData
    ]);
    exit;
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to load SGPA details.']);
    exit;
}
