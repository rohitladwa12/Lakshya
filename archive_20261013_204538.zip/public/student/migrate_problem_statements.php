<?php
/**
 * Problem Statement Refactor Migration Script
 * Reframes dry LeetCode-style descriptions into realistic interview/system scenarios.
 */

require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../../src/Services/AIService.php';

// Only allow execution via CLI or with a secret key to prevent unauthorized running
if (php_sapi_name() !== 'cli' && (!isset($_GET['run']) || $_GET['run'] !== 'secret123')) {
    die("Access Denied.");
}

header('Content-Type: text/plain');
echo "Starting Problem Statement Migration...\n";

$db = getDB();
$ai = new AIService();

// 1. Fetch all coding problems
$stmt = $db->query("SELECT id, title, problem_statement, example_input, example_output FROM coding_problems ORDER BY id ASC");
$problems = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Loaded " . count($problems) . " problems.\n\n";

// We can run a dry run or full run based on parameters
if (php_sapi_name() === 'cli') {
    $options = getopt('', ['limit:', 'start_id:', 'commit']);
    $limit = isset($options['limit']) ? (int)$options['limit'] : 1;
    $startId = isset($options['start_id']) ? (int)$options['start_id'] : 0;
    $commit = isset($options['commit']);
} else {
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 1; // Default to 1 for verification
    $startId = isset($_GET['start_id']) ? (int)$_GET['start_id'] : 0;
    $commit = isset($_GET['commit']) && $_GET['commit'] == '1';
}

$processedCount = 0;

foreach ($problems as $p) {
    if ($p['id'] < $startId) continue;
    if ($processedCount >= $limit) break;

    echo "--------------------------------------------------\n";
    echo "Processing Problem ID: {$p['id']} | Title: {$p['title']}\n";
    echo "--------------------------------------------------\n";
    echo "OLD Problem Statement:\n{$p['problem_statement']}\n\n";

    // System prompt for reframing
    $systemPrompt = "You are a senior technical interviewer at a top technology company. "
                  . "Your goal is to reframe a classic, dry, academic programming question into a realistic system design, product development, or real-world business scenario that candidates would face in an actual interview. "
                  . "Ensure the question is framed around practical engineering concepts (e.g. system logs, booking calendars, caching, database indexing, undo/redo buffers, sensor data, network routing, etc.).\n\n"
                  . "CRITICAL RULES:\n"
                  . "1. DO NOT change the core algorithm, input structure, output structure, or data types. The code solution must remain exactly the same as before.\n"
                  . "2. Keep the problem explanation clear, professional, and easy to read. Structure it with sections like 'Scenario' and 'Task'.\n"
                  . "3. DO NOT output code, solutions, or explanations of the algorithm.\n"
                  . "4. Output ONLY the new, reframed problem statement text. Do not wrap in markdown quotes or prefix with commentary.";

    $userPrompt = "Title: " . $p['title'] . "\n"
                . "Original Statement: " . $p['problem_statement'] . "\n"
                . "Example Input: " . $p['example_input'] . "\n"
                . "Example Output: " . $p['example_output'] . "\n\n"
                . "Please output the reframed, scenario-based interview question statement:";

    $messages = [
        ['role' => 'system', 'content' => $systemPrompt],
        ['role' => 'user', 'content' => $userPrompt]
    ];

    $response = $ai->callAPI($messages, [
        'temperature' => 0.6,
        'max_tokens' => 1200
    ]);

    if (!$response['success']) {
        echo "AI API Error: " . $response['message'] . "\n";
        continue;
    }

    $newStatement = trim($response['content']);
    echo "NEW Reframed Statement:\n{$newStatement}\n\n";

    if ($commit) {
        $updateStmt = $db->prepare("UPDATE coding_problems SET problem_statement = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $updateStmt->execute([$newStatement, $p['id']]);
        echo "✅ Database updated successfully.\n";
    } else {
        echo "ℹ️ Dry-run mode. Database not updated. (Pass commit=1 to update).\n";
    }

    $processedCount++;
}

echo "\nMigration finished. Processed {$processedCount} problems.\n";
