<?php
ob_start(); // Buffer output to prevent stray PHP warnings from corrupting JSON
// AI calls are synchronous and can take up to ~120s (see AIService::callAPI).
// Without this the default 30s max_execution_time kills the request mid-flight,
// producing truncated/empty responses -> "next question doesn't appear".
set_time_limit(300);
require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../../src/Services/AIService.php';
require_once __DIR__ . '/../../src/Models/StudentProfile.php';

// Discard any output generated during bootstrap (e.g. PHP warnings when display_errors=1)
ob_end_clean();
ob_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method: ' . $_SERVER['REQUEST_METHOD'] . '. Please ensure you are submitting a POST request.'
    ]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$input = array_merge($input, $_POST);

$action = $input['action'] ?? '';

if (!isLoggedIn()) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Session expired. Please log in again.']);
    exit;
}
$userId = getUserId();
$studentIdForDb = getStudentIdForAssessment(); // USN for GMIT, user_id for GMU (avoids 0 for GMIT)

// Rate Limit only the AI-heavy actions. Lightweight/background actions
// (autosave every 20s, check_active, polling, pdf save) must NOT consume the
// AI budget, otherwise a normal session exhausts it and the next question is
// silently blocked with "Too many requests".
$aiHeavyActions = ['chat', 'evaluate_code', 'end_session', 'start'];
if (in_array($action, $aiHeavyActions, true) && !checkRateLimit("mock_ai_api_" . $userId, 30, 60)) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Too many requests. Please wait a minute.']);
    exit;
}

$db = getDB();
$aiService = new AIService();
$studentModel = new StudentProfile();

ensureIntegrityTablesExist($db);

function ensureIntegrityTablesExist(PDO $db) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS assessment_integrity_events (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(100) NOT NULL,
            portfolio_id INT NOT NULL DEFAULT 0,
            assessment_type VARCHAR(50) NOT NULL DEFAULT 'Mock AI Interview',
            event_type VARCHAR(50) NOT NULL,
            duration FLOAT NULL,
            confidence FLOAT NOT NULL DEFAULT 1.0,
            severity VARCHAR(20) NOT NULL DEFAULT 'LOW',
            metadata JSON NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_student_portfolio (student_id, portfolio_id),
            INDEX idx_event_severity (event_type, severity)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $db->exec("CREATE TABLE IF NOT EXISTS assessment_calibrations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(100) NOT NULL,
            portfolio_id INT NOT NULL DEFAULT 0,
            calibration_json JSON NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_student_portfolio (student_id, portfolio_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (\Throwable $e) {
        error_log("Failed to create integrity tables: " . $e->getMessage());
    }
}

try {
    $db->exec("ALTER TABLE mock_ai_interview_sessions ADD COLUMN IF NOT EXISTS difficulty VARCHAR(50) DEFAULT 'Medium'");
} catch (\Exception $e) {
}

function buildOrchestratedStep($type, $questionNum, $totalQs, $message, $aiService)
{
    $phase = strtoupper($type);

    $step = [
        "title" => $type . " Round",
        "phase" => $phase,
        "current_q" => $questionNum,
        "total_questions" => $totalQs,
        "message" => $message,
        "tts" => true,
        "voice" => false
    ];

    if ($phase === 'APTITUDE') {
        $step["ui"] = "chat";
        $step["components"] = ["chat_window", "timer"];
        // If the AI message contains real A)–D) options, activate the dedicated
        // MCQ panel (previously dead code — the orchestrator never emitted it).
        $parsed = parseMCQOptions($message);
        if (count($parsed['options']) >= 2 && trim($parsed['body']) !== '') {
            $step["ui"] = "mcq";
            $step["components"] = ["chat_window", "mcq_viewer", "timer"];
            $step["question"] = [
                "body" => $parsed['body'],
                "options" => $parsed['options']
            ];
        }
    } elseif ($phase === 'TECHNICAL' || $phase === 'TECHNICAL_CODING') {
        $step["ui"] = "editor";
        $step["components"] = ["chat_window", "code_editor", "timer"];
    } else {
        $step["ui"] = "chat";
        $step["components"] = ["chat_window", "voice_engine", "tts_engine"];
        $step["voice"] = true;
    }

    return $step;
}

function parseMCQOptions($text)
{
    $options = [];
    $body = $text;

    $pattern = '/\b([A-D])[\.\)]\s*(.*?)(?=\b[A-D][\.\)]|$)/is';
    if (preg_match_all($pattern, $text, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $options[] = [
                "key" => trim($match[1]),
                "text" => trim($match[2])
            ];
        }
        $body = preg_replace('/(\b([A-D])[\.\)]\s*.*)/is', '', $text);
    }
    // No fabricated placeholder options when parsing fails — an empty array
    // tells the caller this message is not a renderable MCQ.

    return [
        "body" => trim($body),
        "options" => $options
    ];
}

function sanitizeHistory($history)
{
    if (!is_array($history)) {
        return [];
    }
    $sanitized = [];
    foreach ($history as $msg) {
        if (!is_array($msg)) {
            continue;
        }
        $role = (string) ($msg['role'] ?? 'user');
        $content = $msg['content'] ?? '';
        if (!is_string($content)) {
            $content = is_array($content) ? json_encode($content) : (string) $content;
        }
        $sanitized[] = [
            'role' => $role,
            'content' => $content
        ];
    }
    return $sanitized;
}

try {
    switch ($action) {
        case 'save_calibration':
            $sessionId = (int)($input['session_id'] ?? 0);
            $calibrationData = $input['calibration'] ?? [];

            $stmt = $db->prepare("INSERT INTO assessment_calibrations (student_id, portfolio_id, calibration_json, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$studentIdForDb, $sessionId, json_encode($calibrationData)]);

            ob_clean(); echo json_encode([
                'success' => true,
                'message' => 'Calibration baseline stored successfully.'
            ]);
            exit;

        case 'log_proctoring_event':
            $sessionId = (int)($input['session_id'] ?? 0);
            $eventType = trim((string)($input['event_type'] ?? 'GAZE_DEVIATION'));
            $duration = (float)($input['duration'] ?? 0);
            $confidence = (float)($input['confidence'] ?? 1.0);
            $severity = strtoupper(trim((string)($input['severity'] ?? 'LOW')));
            $metadata = $input['metadata'] ?? [];

            if (!in_array($severity, ['LOW', 'MEDIUM', 'HIGH'])) {
                $severity = 'LOW';
            }

            $snapshotInfo = null;
            $snapshotBase64 = $input['snapshot'] ?? $input['snapshot_base64'] ?? null;
            if (!empty($snapshotBase64)) {
                $snapshotInfo = \App\Services\ProctoringService::saveSnapshotToVault($snapshotBase64, $studentIdForDb, $eventType);
            }

            $stmt = $db->prepare("INSERT INTO assessment_integrity_events 
                (student_id, portfolio_id, assessment_type, event_type, duration, confidence, severity, metadata, snapshot_path, file_size, sha256, mime_type, created_at) 
                VALUES (?, ?, 'Mock AI Interview', ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $stmt->execute([
                $studentIdForDb,
                $sessionId,
                $eventType,
                $duration,
                $confidence,
                $severity,
                json_encode($metadata),
                $snapshotInfo['path'] ?? null,
                $snapshotInfo['size'] ?? null,
                $snapshotInfo['sha256'] ?? null,
                $snapshotInfo['mime'] ?? null
            ]);

            ob_clean(); echo json_encode([
                'success' => true,
                'event_logged' => $eventType
            ]);
            exit;

        case 'check_active':
            $institution = getInstitution() ?: 'GMU';
            $sql = "SELECT id, role_name, conversation_history, difficulty FROM mock_ai_interview_sessions 
                WHERE student_id = ? AND status = 'active' AND institution = ? 
                ORDER BY id DESC LIMIT 1";
            $stmt = $db->prepare($sql);
            $stmt->execute([$studentIdForDb, $institution]);
            $session = $stmt->fetch();

            if ($session) {
                $history = sanitizeHistory(json_decode($session['conversation_history'], true));
                $assistantMessages = array_filter($history, fn($m) => $m['role'] === 'assistant');
                $questionNum = max(1, count($assistantMessages));
                $lastMsg = end($history);
                $lastContent = $lastMsg ? $lastMsg['content'] : 'Welcome back';

                $checkpoint = null;
                try {
                    $checkStmt = $db->prepare("SELECT checkpoint FROM mock_ai_interview_sessions WHERE id = ?");
                    $checkStmt->execute([$session['id']]);
                    $cRow = $checkStmt->fetch();
                    if ($cRow && !empty($cRow['checkpoint'])) {
                        $checkpoint = json_decode($cRow['checkpoint'], true);
                    }
                } catch (\Exception $e) {
                }

                $type = 'Technical'; // Default fallback
                for ($i = count($history) - 1; $i >= 0; $i--) {
                    $hMsg = $history[$i];
                    if ($hMsg['role'] === 'assistant') {
                        $hContentLower = strtolower($hMsg['content']);
                        if (preg_match('/\b[A-D][\.\)]\s*/i', $hMsg['content'])) {
                            $type = 'Aptitude';
                            break;
                        }
                        if (stripos($hContentLower, 'starting with the aptitude') !== false || stripos($hContentLower, 'start with aptitude') !== false || stripos($hContentLower, 'welcome to the aptitude') !== false) {
                            $type = 'Aptitude';
                            break;
                        }
                        if (stripos($hContentLower, 'starting with the technical') !== false || stripos($hContentLower, 'start with technical') !== false || stripos($hContentLower, 'welcome to the technical') !== false) {
                            $type = 'Technical';
                            break;
                        }
                        if (stripos($hContentLower, 'starting with the hr') !== false || stripos($hContentLower, 'start with hr') !== false || stripos($hContentLower, 'welcome to the hr') !== false) {
                            $type = 'HR';
                            break;
                        }
                    } elseif ($hMsg['role'] === 'user') {
                        $uContentLower = strtolower(trim($hMsg['content']));
                        if ($uContentLower === 'aptitude' || $uContentLower === 'switch to aptitude' || $uContentLower === 'logical') {
                            $type = 'Aptitude';
                            break;
                        }
                        if ($uContentLower === 'technical' || $uContentLower === 'switch to technical' || $uContentLower === 'coding') {
                            $type = 'Technical';
                            break;
                        }
                        if ($uContentLower === 'hr' || $uContentLower === 'switch to hr' || $uContentLower === 'behavioral') {
                            $type = 'HR';
                            break;
                        }
                    }
                }

                $totalQs = ($type === 'Aptitude') ? 25 : (($type === 'Technical') ? 10 : 8);
                $step = buildOrchestratedStep($type, $questionNum, $totalQs, $lastContent, $aiService);

                ob_clean();
                echo json_encode([
                    'success' => true,
                    'has_active' => true,
                    'session_id' => $session['id'],
                    'role' => $session['role_name'],
                    'difficulty' => $session['difficulty'] ?? 'Medium',
                    'history' => $history,
                    'step' => $step,
                    'checkpoint' => $checkpoint
                ]);
            } else {
                ob_clean();
                echo json_encode(['success' => true, 'has_active' => false]);
            }
            exit;

        case 'start':
            // Strict limit for starting new mock sessions (2 per minute)
            if (!checkRateLimit("mock_ai_start_" . $userId, 2, 60)) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Slow down! You can only start 2 sessions per minute.']);
                exit;
            }
            $role = $input['role'] ?? 'AI Engineer';
            $company = $input['company'] ?? 'General';
            $concept = $input['concept'] ?? '';
            $type = $input['type'] ?? 'Technical';
            $difficulty = $input['difficulty'] ?? 'Medium';
            $institution = getInstitution() ?: 'GMU';

            $sql = "INSERT INTO mock_ai_interview_sessions (student_id, role_name, status, institution, concept, company_name, difficulty) VALUES (?, ?, 'active', ?, ?, ?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->execute([$studentIdForDb, $role, $institution, $concept, $company, $difficulty]);
            $sessionId = $db->lastInsertId();

            // Log session start
            trackActivity('mock_ai_start', "Started Mock AI session for $role", [
                'role' => $role,
                'institution' => $institution,
                'session_id' => $sessionId
            ], 'mock_ai_session', $sessionId);

            // Note: We might want to store company/type in the session history or a temp table if legacy doesn't have it.
            // For now, let's just add it to the first message metadata.

            // Initial Welcome Message
            $welcomeMsg = "Hi, welcome to your Mock AI Interview focusing on **$role** (Difficulty: **$difficulty**). We will start with the **$type** round. Please let me know when you are ready to begin.";
            $aiMsg = ['role' => 'assistant', 'content' => $welcomeMsg];
            $history = [$aiMsg];

            // Update history in DB
            $sqlUpdate = "UPDATE mock_ai_interview_sessions SET conversation_history = ? WHERE id = ?";
            $db->prepare($sqlUpdate)->execute([json_encode($history), $sessionId]);

            $step = buildOrchestratedStep($type, 1, 10, $welcomeMsg, $aiService);

            ob_clean();
            echo json_encode([
                'success' => true,
                'session_id' => $sessionId,
                'message' => $welcomeMsg,
                'step' => $step
            ]);
            break;

        case 'chat':
            $sessionId = $input['session_id'] ?? 0;

            // Fetch session
            $sql = "SELECT * FROM mock_ai_interview_sessions WHERE id = ? AND student_id = ? AND status = 'active'";
            $stmt = $db->prepare($sql);
            $stmt->execute([$sessionId, $studentIdForDb]);
            $session = $stmt->fetch();

            if (!$session) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Session not found or already closed']);
                exit;
            }

            $role = (string) ($session['role_name'] ?? '');
            $concept = (string) ($session['concept'] ?? '');
            $difficulty = (string) ($session['difficulty'] ?? 'Medium');
            $type = (string) ($input['type'] ?? 'Technical');
            $history = sanitizeHistory(json_decode($session['conversation_history'], true));

            // Ensure $userMessage is always a plain string (never an array from json_decode) and capped to prevent buffer bloat
            $userMessage = $input['message'] ?? '';
            if (!is_string($userMessage)) {
                $userMessage = is_array($userMessage) ? json_encode($userMessage) : (string) $userMessage;
            }
            $userMessage = mb_substr(trim($userMessage), 0, 3000);

            $history[] = ['role' => 'user', 'content' => $userMessage];

            // Dynamically detect and update the interview round type (Aptitude, Technical, HR)
            $msgLower = strtolower(trim($userMessage));
            if ($msgLower === 'aptitude' || stripos($msgLower, 'switch to aptitude') !== false || stripos($msgLower, 'start aptitude') !== false || stripos($msgLower, 'select aptitude') !== false || $msgLower === '1' || $msgLower === 'option 1') {
                $type = 'Aptitude';
            } elseif ($msgLower === 'technical' || stripos($msgLower, 'switch to technical') !== false || stripos($msgLower, 'start technical') !== false || stripos($msgLower, 'select technical') !== false || $msgLower === '2' || $msgLower === 'option 2') {
                $type = 'Technical';
            } elseif ($msgLower === 'hr' || stripos($msgLower, 'switch to hr') !== false || stripos($msgLower, 'start hr') !== false || stripos($msgLower, 'select hr') !== false || $msgLower === '3' || $msgLower === 'option 3') {
                $type = 'HR';
            } else {
                // Scan history backwards to find the active round type
                for ($i = count($history) - 2; $i >= 0; $i--) {
                    $hMsg = $history[$i];
                    if ($hMsg['role'] === 'assistant') {
                        $hContentLower = strtolower($hMsg['content']);
                        // If assistant sent a message containing MCQ options, we are in Aptitude mode
                        if (preg_match('/\b[A-D][\.\)]\s*/i', $hMsg['content'])) {
                            $type = 'Aptitude';
                            break;
                        }
                        if (stripos($hContentLower, 'starting with the aptitude') !== false || stripos($hContentLower, 'start with aptitude') !== false || stripos($hContentLower, 'welcome to the aptitude') !== false) {
                            $type = 'Aptitude';
                            break;
                        }
                        if (stripos($hContentLower, 'starting with the technical') !== false || stripos($hContentLower, 'start with technical') !== false || stripos($hContentLower, 'welcome to the technical') !== false) {
                            $type = 'Technical';
                            break;
                        }
                        if (stripos($hContentLower, 'starting with the hr') !== false || stripos($hContentLower, 'start with hr') !== false || stripos($hContentLower, 'welcome to the hr') !== false) {
                            $type = 'HR';
                            break;
                        }
                    } elseif ($hMsg['role'] === 'user') {
                        $uContentLower = strtolower(trim($hMsg['content']));
                        if ($uContentLower === 'aptitude' || $uContentLower === 'switch to aptitude' || $uContentLower === 'logical') {
                            $type = 'Aptitude';
                            break;
                        }
                        if ($uContentLower === 'technical' || $uContentLower === 'switch to technical' || $uContentLower === 'coding') {
                            $type = 'Technical';
                            break;
                        }
                        if ($uContentLower === 'hr' || $uContentLower === 'switch to hr' || $uContentLower === 'behavioral') {
                            $type = 'HR';
                            break;
                        }
                    }
                }
            }

            $profile = $studentModel->getByUserId($userId);

            // Fetch Portfolio Projects for HR context
            require_once __DIR__ . '/../../src/Models/Portfolio.php';
            $portfolioModel = new Portfolio();
            $institution = getInstitution() ?: ($profile['institution'] ?? 'GMU');
            $projects = $portfolioModel->getStudentPortfolio($studentIdForDb, $institution);

            // Aptitude questions are dynamically generated by AI based on candidate's concept
            $aptitudeQuestions = [];

            $company = (string) ($session['company_name'] ?? 'General');

            // --- Sliding Window: trim history to prevent token overflow ---
            // The system prompt is ~3000+ tokens.  Keep the first 2 messages
            // (welcome exchange) for context and the last 20 messages (10 Q&A
            // pairs) so the AI always sees the student's latest answer.
            $trimmedHistory = $history;
            $maxMessages = 22; // 2 anchor + 20 recent
            if (count($trimmedHistory) > $maxMessages) {
                $anchor = array_slice($trimmedHistory, 0, 2);      // first welcome exchange
                $recent = array_slice($trimmedHistory, -20);        // last 20 messages
                $trimmedHistory = array_merge($anchor, [['role' => 'system', 'content' => '[Earlier conversation trimmed for brevity]']], $recent);
            }

            session_write_close();
            $response = $aiService->getTechnicalInterviewResponse($role, $trimmedHistory, $profile, '', $type, $projects, $aptitudeQuestions, $concept, $company, $difficulty);

            if ($response['success']) {
                $aiContent = $response['content'];
                $history[] = ['role' => 'assistant', 'content' => $aiContent];

                $isEnd = (strpos($aiContent, '[END_INTERVIEW]') !== false);
                $status = $isEnd ? 'completed' : 'active';
                $completedAt = $isEnd ? date('Y-m-d H:i:s') : null;
                $reportContent = null;
                $overallScore = null;

                // Engagement Check for Auto-End
                $userMsgs = array_filter($history, fn($m) => $m['role'] === 'user' && !empty(trim($m['content'])));
                $hasEngagement = count($userMsgs) > 0;

                if ($isEnd) {
                    if (!$hasEngagement) {
                        $overallScore = 0;
                        $reportContent = "You did not participate in the interview.";
                        $status = 'completed';
                    } else {
                        session_write_close();
                        $reportRes = $aiService->generateTechnicalInterviewReport($role, $history, $type, $concept);
                        if ($reportRes['success']) {
                            $reportContent = $reportRes['content'];
                            $overallScore = $reportRes['overall_score'] ?? null;
                        }
                    }

                    if ($reportContent !== null || !$hasEngagement) {
                        // SAVE TO UNIFIED TABLE
                        try {
                            $profile = $studentModel->getByUserId($userId);
                            // We need the company name. We can try to infer it from the first prompt or pass it in chat.
                            // Since we don't have it in legacy schema, let's assume 'General' if not found.
                            // Better: The client can pass it in the final chat message or we can store it in a session.
                            $companyNameFromInput = $input['company'] ?? 'General';
                            $assessmentTypeFromInput = $input['type'] ?? 'Technical';
                            // Map to allowed ENUM values: 'Aptitude','Technical','HR','Skill Verification','Project Defense'
                            $enumType = 'Technical';
                            if (stripos($assessmentTypeFromInput, 'HR') !== false)
                                $enumType = 'HR';
                            if (stripos($assessmentTypeFromInput, 'Aptitude') !== false)
                                $enumType = 'Aptitude';

                            $sqlUnified = "INSERT INTO unified_ai_assessments (
                            student_id, institution, student_name, usn, aadhar, 
                            current_sem, branch, assessment_type, 
                            company_name, score, total_marks, 
                            feedback, details, status, completed_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

                            $db->prepare($sqlUnified)->execute([
                                $studentIdForDb,
                                getInstitution(),
                                $profile['name'] ?? getFullName(),
                                $profile['usn'] ?? getUsername(),
                                $profile['aadhar'] ?? null,
                                $profile['semester'] ?? null,
                                $profile['department'] ?? null,
                                $enumType,
                                $companyNameFromInput,
                                $overallScore,
                                100, // Total marks is 100 for interviews
                                "Interview Completed",
                                json_encode([
                                    'transcript' => $history,
                                    'report' => $reportContent,
                                    'role' => $role
                                ]),
                                'completed'
                            ]);

                            // Log completion to database
                            trackActivity('mock_ai_complete', "Completed Mock AI session for $role", [
                                'score' => $overallScore,
                                'role' => $role,
                                'type' => $assessmentTypeFromInput
                            ], 'mock_ai_session', $input['session_id']);

                        } catch (\Exception $e) {
                            error_log("Failed to log unified mock ai assessment: " . $e->getMessage());
                        }
                    }
                }

                // Update DB to include overall_score
                $sqlH = "UPDATE mock_ai_interview_sessions SET conversation_history = ?, status = ?, completed_at = ?, report_content = ?, overall_score = ? WHERE id = ?";
                $db->prepare($sqlH)->execute([json_encode($history), $status, $completedAt, $reportContent, $overallScore, $sessionId]);

                $assistantMessages = array_filter($history, fn($m) => $m['role'] === 'assistant');
                $questionNum = count($assistantMessages);
                $totalQs = ($type === 'Aptitude') ? 25 : (($type === 'Technical') ? 10 : 8);

                $step = buildOrchestratedStep($type, $questionNum, $totalQs, $aiContent, $aiService);

                ob_clean();
                echo json_encode([
                    'success' => true,
                    'message' => $aiContent,
                    'is_end' => $isEnd,
                    'session_id' => $sessionId,
                    'step' => $step
                ]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'AI Response Failed. Please try sending your answer again.']);
            }
            break;

        case 'autosave':
            $sessionId = (int)($input['session_id'] ?? 0);
            $checkpoint = $input['checkpoint'] ?? [];

            $_SESSION["lar_checkpoint_{$sessionId}"] = $checkpoint;

            try {
                // Schema check once per login session, not on every 20s autosave
                if (empty($_SESSION['lar_checkpoint_column_checked'])) {
                    $db->exec("ALTER TABLE mock_ai_interview_sessions ADD COLUMN IF NOT EXISTS checkpoint TEXT NULL");
                    $_SESSION['lar_checkpoint_column_checked'] = true;
                }
                // Scope to the logged-in student so one student cannot overwrite another's checkpoint
                $sql = "UPDATE mock_ai_interview_sessions SET checkpoint = ? WHERE id = ? AND student_id = ?";
                $db->prepare($sql)->execute([json_encode($checkpoint), $sessionId, $studentIdForDb]);
            } catch (\Exception $e) {
                error_log("LAR autosave db write bypassed: " . $e->getMessage());
            }

            ob_clean();
            echo json_encode(['success' => true]);
            exit;

        case 'evaluate_code':
            $sessionId = $input['session_id'] ?? 0;
            $code = $input['code'] ?? '';
            $language = $input['language'] ?? 'python';

            // Fetch session
            $sql = "SELECT * FROM mock_ai_interview_sessions WHERE id = ? AND student_id = ? AND status = 'active'";
            $stmt = $db->prepare($sql);
            $stmt->execute([$sessionId, $studentIdForDb]);
            $session = $stmt->fetch();

            if (!$session) {
                echo json_encode(['success' => false, 'message' => 'Session not found or already closed']);
                exit;
            }

            $history = sanitizeHistory(json_decode($session['conversation_history'], true));
            $role = $session['role_name'];

            // Use AI Service to evaluate code
            session_write_close();
            $evalRes = $aiService->evaluateCode($code, $language, "Technical task for role: $role");

            if ($evalRes['success']) {
                // evaluateCode() returns ['result' => <already-decoded array>]
                $evaluation = $evalRes['result'];

                // Ensure we have a valid evaluation array (fallback if AI returned null)
                if (!is_array($evaluation)) {
                    $evaluation = ['passed' => false, 'score' => 0, 'feedback' => 'Evaluation could not be parsed.'];
                }

                // Log to history
                $history[] = ['role' => 'user', 'content' => "User ran code simulation ({$language}). Result: " . ($evaluation['passed'] ? 'PASSED' : 'FAILED') . " - Score: {$evaluation['score']}/10"];
                $history[] = ['role' => 'system', 'content' => "Code Evaluation: " . json_encode($evaluation)];

                $db->prepare("UPDATE mock_ai_interview_sessions SET conversation_history = ? WHERE id = ?")
                    ->execute([json_encode($history), $sessionId]);

                ob_clean();
                echo json_encode([
                    'success' => true,
                    'evaluation' => $evaluation
                ]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Evaluation service failed. Please try again.']);
            }
            break;

        case 'end_session':
            $sessionId = $input['session_id'] ?? 0;

            // Fetch session
            $sql = "SELECT * FROM mock_ai_interview_sessions WHERE id = ? AND student_id = ? AND status = 'active'";
            $stmt = $db->prepare($sql);
            $stmt->execute([$sessionId, $studentIdForDb]);
            $session = $stmt->fetch();

            if (!$session) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Session not found or already closed']);
                exit;
            }

            $role = $session['role_name'];
            $concept = $session['concept'] ?? '';
            $history = sanitizeHistory(json_decode($session['conversation_history'], true));
            $completedAt = date('Y-m-d H:i:s');

            // Engagement Check for Manual End
            $userMsgs = array_filter($history, fn($m) => $m['role'] === 'user' && !empty(trim($m['content'])));
            if (count($userMsgs) === 0) {
                $reportContent = "You did not participate in the interview.";
                $overallScore = 0;
                $type = $input['type'] ?? 'Technical';
            } else {
                // Generate Report
                $reportContent = null;
                $overallScore = null;
                $type = $input['type'] ?? 'Technical';

                $reportRes = $aiService->generateTechnicalInterviewReport($role, $history, $type, $concept);
                if ($reportRes['success']) {
                    $reportContent = $reportRes['content'];
                    $overallScore = $reportRes['overall_score'] ?? null;
                } else {
                    ob_clean();
                    echo json_encode([
                        'success' => false,
                        'message' => 'Report generation failed. Please try ending the session again.'
                    ]);
                    exit;
                }
            }

            // 5% Score Deduction Per Strike / Flag Calculation.
            // Server recount of logged strikes (portfolio_id holds the session id, so no time window);
            // the browser's figure can only raise it.
            $serverStrikes = 0;
            try {
                $serverStrikes = \App\Services\ProctoringService::countAttemptStrikes($db, $studentIdForDb, (int)$sessionId);
            } catch (\Throwable $e) {
                error_log("Mock interview strike recount failed: " . $e->getMessage());
            }
            $strikeCount = max($serverStrikes, (int)($input['strike_count'] ?? 0));
            $penaltyPct = min(100, $strikeCount * 5);
            $rawScore = $overallScore !== null ? (float)$overallScore : 0.0;
            $adjustedScore = max(0.0, round($rawScore - $penaltyPct));

            // Build Assessment Integrity Report from logged events
            $integrityReport = [
                'screen_sharing_active_pct' => 100.0,
                'camera_availability_pct' => 100.0,
                'face_presence_pct' => 100.0,
                'gaze_confidence_pct' => 92.5,
                'attention_deviations' => 0,
                'longest_deviation_sec' => 0.0,
                'screen_interruptions' => 0,
                'multiple_faces_count' => 0,
                'strike_count' => $strikeCount,
                'penalty_deducted_pct' => $penaltyPct,
                'raw_score' => $rawScore,
                'adjusted_score' => $adjustedScore,
                'integrity_status' => 'No significant anomalies detected'
            ];

            try {
                $eventStmt = $db->prepare("SELECT event_type, duration, confidence, severity FROM assessment_integrity_events WHERE student_id = ? AND portfolio_id = ?");
                $eventStmt->execute([$studentIdForDb, $sessionId]);
                $events = $eventStmt->fetchAll(PDO::FETCH_ASSOC);

                $totalEvents = count($events);
                $confSum = 0;
                $maxDev = 0;

                foreach ($events as $evt) {
                    $confSum += (float)($evt['confidence'] ?? 1.0);
                    $dur = (float)($evt['duration'] ?? 0);

                    if ($evt['event_type'] === 'GAZE_DEVIATION' || $evt['event_type'] === 'LOOKING_AWAY') {
                        $integrityReport['attention_deviations']++;
                        if ($dur > $maxDev) $maxDev = $dur;
                    } else if ($evt['event_type'] === 'SCREEN_SHARE_STOPPED' || $evt['event_type'] === 'FULLSCREEN_EXIT') {
                        $integrityReport['screen_interruptions']++;
                    } else if ($evt['event_type'] === 'MULTI_FACE') {
                        $integrityReport['multiple_faces_count']++;
                    } else if ($evt['event_type'] === 'NO_FACE') {
                        $integrityReport['face_presence_pct'] = max(70.0, $integrityReport['face_presence_pct'] - 5.0);
                    }
                }

                if ($totalEvents > 0) {
                    $integrityReport['gaze_confidence_pct'] = round(($confSum / $totalEvents) * 100, 1);
                }
                $integrityReport['longest_deviation_sec'] = round($maxDev, 1);

                if (isset($input['client_face_presence_pct'])) {
                    $cFacePct = (float)$input['client_face_presence_pct'];
                    $integrityReport['face_presence_pct'] = round(min($integrityReport['face_presence_pct'], $cFacePct), 1);
                }

                $autoSubmitted = !empty($input['auto_submitted']) || $strikeCount >= 3;
                $integrityReport['auto_submitted'] = $autoSubmitted;
                $integrityReport['server_strike_count'] = $serverStrikes;

                if ($autoSubmitted || $strikeCount >= 3) {
                    $integrityReport['integrity_status'] = 'Auto-Submitted: Maximum Security Violations (3/3) Exceeded';
                } else if ($strikeCount > 0 || $integrityReport['screen_interruptions'] > 0 || $maxDev >= 15.0 || $integrityReport['multiple_faces_count'] > 0) {
                    $integrityReport['integrity_status'] = 'Integrity Penalties Applied (-' . $penaltyPct . '% Deducted)';
                }
            } catch (\Throwable $e) {
                error_log("Failed to build mock AI integrity report: " . $e->getMessage());
            }

            // SAVE TO UNIFIED TABLE
            if ($reportContent !== null) {
                try {
                    $profile = $studentModel->getByUserId($userId);
                    $companyNameFromInput = $input['company'] ?? 'General';
                    $assessmentTypeFromInput = $input['type'] ?? 'Technical';
                    // Map to allowed ENUM values
                    $enumType = 'Technical';
                    if (stripos($assessmentTypeFromInput, 'HR') !== false)
                        $enumType = 'HR';
                    if (stripos($assessmentTypeFromInput, 'Aptitude') !== false)
                        $enumType = 'Aptitude';

                    $sqlUnified = "INSERT INTO unified_ai_assessments (
                    student_id, institution, student_name, usn, aadhar, 
                    current_sem, branch, assessment_type, 
                    company_name, score, total_marks, 
                    feedback, details, status, completed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

                    $db->prepare($sqlUnified)->execute([
                        $studentIdForDb,
                        getInstitution(),
                        $profile['name'] ?? getFullName(),
                        $profile['usn'] ?? getUsername(),
                        $profile['aadhar'] ?? null,
                        $profile['semester'] ?? null,
                        $profile['department'] ?? null,
                        $enumType,
                        $companyNameFromInput,
                        $adjustedScore,
                        100,
                        $strikeCount > 0 ? "Interview Completed (Penalty: -{$penaltyPct}%)" : "Interview Completed",
                        json_encode([
                            'transcript' => $history,
                            'report' => $reportContent,
                            'role' => $role,
                            'raw_score' => $rawScore,
                            'penalty_pct' => $penaltyPct,
                            'strike_count' => $strikeCount,
                            'integrity_report' => $integrityReport
                        ]),
                        'completed'
                    ]);
                } catch (Exception $e) {
                    logMessage("Failed to save to unified table: " . $e->getMessage(), 'ERROR');
                }
            }

            // Update session
            $sqlH = "UPDATE mock_ai_interview_sessions SET status = 'completed', completed_at = ?, report_content = ?, overall_score = ? WHERE id = ?";
            $db->prepare($sqlH)->execute([$completedAt, $reportContent, $adjustedScore, $sessionId]);

            ob_clean();
            echo json_encode([
                'success' => true,
                'message' => 'Session ended',
                'session_id' => $sessionId,
                'score' => $adjustedScore,
                'raw_score' => $rawScore,
                'penalty_pct' => $penaltyPct,
                'strike_count' => $strikeCount,
                'integrity_report' => $integrityReport
            ]);
            break;

        case 'get_report':
            $sessionId = $input['session_id'] ?? 0;
            $sql = "SELECT report_content, role_name, conversation_history, started_at FROM mock_ai_interview_sessions WHERE id = ? AND student_id = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute([$sessionId, $studentIdForDb]);
            $session = $stmt->fetch();

            if ($session && $session['report_content']) {
                ob_clean();
                echo json_encode(['success' => true, 'report' => $session['report_content'], 'role' => $session['role_name']]);
            } else {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Report not found or not yet generated']);
            }
            break;

        case 'save_pdf':
            if (!isset($_FILES['report_pdf'])) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'No file uploaded']);
                exit;
            }

            $sessionId = $_POST['session_id'] ?? null;
            $currentUser = getUsername() ?? $studentIdForDb;
            $sem = 'Sem';

            if ($sessionId) {
                // Fix: current_sem column doesn't exist in mock_ai_interview_sessions.
                // Fall back to student profile for semester info.
                $profile = $studentModel->getByUserId($userId);
                $sem = $profile['semester'] ?? 'Sem';
            } else {
                $res = $db->prepare("SELECT id FROM mock_ai_interview_sessions WHERE student_id = ? ORDER BY id DESC LIMIT 1");
                $res->execute([$studentIdForDb]);
                $s = $res->fetch();
                $sessionId = $s['id'] ?? '0';
                $profile = $studentModel->getByUserId($userId);
                $sem = $profile['semester'] ?? 'Sem';
            }

            $filename = "{$currentUser}_{$sem}_{$sessionId}.pdf";
            $uploadDir = REPORTS_UPLOAD_PATH . '/mock_ai/';

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $destination = $uploadDir . $filename;

            if (move_uploaded_file($_FILES['report_pdf']['tmp_name'], $destination)) {
                $publicPath = "uploads/reports/mock_ai/" . $filename;
                ob_clean();
                echo json_encode(['success' => true, 'message' => 'Report stored successfully', 'path' => $publicPath]);
            } else {
                error_log("mock_ai save_pdf: move_uploaded_file failed for $destination");
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Failed to save report to server']);
            }
            break;

        case 'cancel_pending':
            $sessionId = $input['session_id'] ?? 0;
            $sql = "UPDATE mock_ai_interview_sessions SET status = 'cancelled', completed_at = CURRENT_TIMESTAMP 
                WHERE id = ? AND student_id = ? AND status = 'active'";
            $db->prepare($sql)->execute([$sessionId, $studentIdForDb]);
            ob_clean();
            echo json_encode(['success' => true, 'message' => 'Pending session retired']);
            break;

        default:
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Action not found']);
            break;
    }
} catch (Throwable $e) {
    // Any uncaught exception previously rendered an HTML fatal, which the
    // frontends could not parse — always answer with JSON.
    error_log("Mock AI Handler Exception [$action]: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}