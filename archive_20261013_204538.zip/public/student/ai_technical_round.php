<?php
require_once __DIR__ . '/../../config/bootstrap.php';
use App\Helpers\SessionFilterHelper;

requireLogin();

$driveId = isset($_GET['drive_id']) ? (int) $_GET['drive_id'] : 0;
$companyName = 'General';
$taskId = 0;
$concept = '';
$roleName = 'Software Engineer';

if ($driveId > 0) {
    $db = getDB();
    $usn = getUsername();
    // Fetch drive details
    $stmt = $db->prepare("
        SELECT cd.*, jp.title as job_title, jp.id as job_id, c.name as company_name
        FROM campus_drives cd
        JOIN job_postings jp ON cd.job_id = jp.id
        LEFT JOIN companies c ON jp.company_id = c.id
        WHERE cd.id = ?
    ");
    $stmt->execute([$driveId]);
    $drive = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$drive) {
        die("Recruitment drive not found.");
    }
    // Enforce applied check
    $stmt = $db->prepare("
        SELECT COUNT(*) FROM job_applications
        WHERE job_id = ? AND student_id = ?
    ");
    $stmt->execute([$drive['job_id'], $usn]);
    if ($stmt->fetchColumn() == 0) {
        die("Access denied. Only applied students can access this recruitment drive round.");
    }

    // Check if the round is actually active
    if (!$drive['technical_active']) {
        die("The Technical Round for this recruitment drive is currently disabled.");
    }

    $companyName = $drive['company_name'];
    $roleName = $drive['job_title'];
    $concept = $drive['technical_topics']; // Topics are the concepts
} else {
    // Handle POST from Assigned Task
    if (isPost() && (isset($_POST['company']) || isset($_POST['task_id']))) {
        SessionFilterHelper::setFilters('ai_technical_round', [
            'company' => $_POST['company'] ?? 'General',
            'concept' => $_POST['concept'] ?? '',
            'task_id' => $_POST['task_id'] ?? 0
        ]);
        header("Location: ai_technical_round.php");
        exit;
    }

    $filters = SessionFilterHelper::getFilters('ai_technical_round');
    $companyName = !empty($_GET['company']) ? clean($_GET['company']) : ($filters['company'] ?? 'General');
    $taskId = isset($_GET['task_id']) ? (int)$_GET['task_id'] : (int)($filters['task_id'] ?? 0);
    $concept = !empty($_GET['concept']) ? clean($_GET['concept']) : ($filters['concept'] ?? '');
    if (empty($concept) && $taskId) {
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT concept FROM coordinator_tasks WHERE id = ?");
            $stmt->execute([$taskId]);
            $concept = $stmt->fetchColumn() ?: '';
        } catch (Exception $e) {}
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technical Round - <?php echo htmlspecialchars($companyName); ?></title>
    <!-- Fonts & Icons -->
    <link
        href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Inter:wght@300;400;600&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- In-page dialogs (replaces native alert/confirm popups) -->
    <script src="../js/lakshya_dialogs.js?v=<?php echo APP_VERSION; ?>"></script>
    <!-- Code Mirror for Editor -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/dracula.min.css">
    <!-- KaTeX for equation rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js"></script>
    <!-- html2pdf -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script src="resilience.js?v=<?php echo APP_VERSION; ?>"></script>
    <script src="../js/proctor.js?v=<?php echo APP_VERSION; ?>"></script>


    <style>
        :root {
            --bg-dark: #121212;
            --panel-bg: #1e1e1e;
            --primary: #800000;
            /* Maroon */
            --accent: #e9c66f;
            /* Gold */
            --text: #e0e0e0;
            --code-bg: #282a36;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            background: var(--bg-dark);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background: #181818;
            padding: 15px 30px;
            border-bottom: 2px solid var(--primary);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .role-badge {
            background: var(--accent);
            color: #000;
            padding: 5px 10px;
            border-radius: 4px;
            font-weight: bold;
            font-size: 0.8rem;
            text-transform: uppercase;
        }

        .main-container {
            flex: 1;
            display: flex;
            overflow: hidden;
        }

        /* Left Split: Chat/Interaction */
        .chat-panel {
            width: 40%;
            background: var(--panel-bg);
            border-right: 1px solid #333;
            display: flex;
            flex-direction: column;
            padding: 0;
        }

        .chat-history {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            scroll-behavior: smooth;
        }

        .message {
            margin-bottom: 20px;
            max-width: 90%;
            line-height: 1.5;
            font-size: 0.95rem;
        }

        .message.ai {
            align-self: flex-start;
        }

        .message.ai .bubble {
            background: #2d2d2d;
            padding: 15px;
            border-radius: 12px 12px 12px 0;
            border-left: 3px solid var(--accent);
        }

        .message.user {
            align-self: flex-end;
            margin-left: auto;
        }

        .message.user .bubble {
            background: var(--primary);
            color: white;
            padding: 12px 18px;
            border-radius: 12px 12px 0 12px;
        }

        .input-area {
            padding: 20px;
            background: #181818;
            border-top: 1px solid #333;
            display: flex;
            gap: 10px;
        }

        input[type="text"],
        textarea#userInput {
            flex: 1;
            padding: 12px;
            border: 1px solid #444;
            border-radius: 8px;
            background: #222;
            color: white;
            outline: none;
            resize: none;
            height: 45px;
            font-family: inherit;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.2s;
        }

        .btn-send {
            background: var(--primary);
            color: white;
        }

        .btn-send:hover {
            background: #a00000;
        }

        /* Right Split: Coding Environment */
        .code-panel {
            width: 60%;
            background: var(--bg-dark);
            display: flex;
            /* Hidden by default if conceptual, but flex here for layout */
            flex-direction: column;
        }

        .code-header {
            padding: 10px 20px;
            background: #181818;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #333;
        }

        .code-wrapper {
            flex: 1;
            position: relative;
        }

        .CodeMirror {
            height: 100% !important;
            font-family: 'JetBrains Mono', monospace;
            font-size: 14px;
        }

        .console-panel {
            height: 150px;
            background: #1e1e1e;
            border-top: 1px solid #333;
            padding: 15px;
            overflow-y: auto;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.9rem;
        }

        .console-title {
            font-size: 0.8rem;
            color: #888;
            margin-bottom: 5px;
            text-transform: uppercase;
        }

        .output {
            color: #aaa;
        }

        .output.success {
            color: #50fa7b;
        }

        .output.error {
            color: #ff5555;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .hidden {
            display: none !important;
        }

        /* Score Modal */
        #scoreModal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.85);
            backdrop-filter: blur(8px);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .score-card {
            background: linear-gradient(145deg, #1e1e2f, #11111a);
            padding: 50px;
            border-radius: 24px;
            text-align: center;
            border: 2px solid #333;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            max-width: 500px;
            width: 90%;
            color: white;
            animation: popIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }

        @keyframes popIn {
            0% {
                transform: scale(0.8);
                opacity: 0;
            }

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .score-title {
            font-size: 24px;
            color: #aaa;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-weight: 600;
        }

        .score-number {
            font-size: 80px;
            font-weight: 900;
            color: #10b981;
            line-height: 1;
            text-shadow: 0 0 20px rgba(16, 185, 129, 0.4);
            margin-bottom: 5px;
        }

        .score-percentage {
            font-size: 30px;
            font-weight: 700;
            color: #10b981;
        }

        .score-zero {
            color: #ef4444;
            text-shadow: 0 0 20px rgba(239, 68, 68, 0.4);
        }

        .score-desc {
            font-size: 16px;
            color: #bbb;
            margin-bottom: 40px;
        }

        .btn-continue {
            background: #800000;
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            box-shadow: 0 10px 20px rgba(128, 0, 0, 0.3);
        }

        .btn-continue:hover {
            background: #a50000;
            transform: translateY(-3px);
        }

        /* Timer Styles */
        #sessionTimer {
            background: rgba(0, 0, 0, 0.3);
            padding: 8px 15px;
            border-radius: 8px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 0.9rem;
            color: var(--accent);
            border: 1px solid rgba(233, 198, 111, 0.2);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        #sessionTimer.locked {
            color: #ff5555;
            border-color: rgba(255, 85, 85, 0.3);
        }

        #sessionTimer.unlocked {
            color: #50fa7b;
            border-color: rgba(80, 250, 123, 0.3);
        }

        .btn-end {
            background: #333;
            color: white;
            margin-left: 15px;
            opacity: 1;
            transition: all 0.3s;
        }

        .btn-end:disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }

        .btn-end.unlocked {
            background: var(--primary);
            color: white;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(128, 0, 0, 0.7);
            }

            70% {
                box-shadow: 0 0 0 10px rgba(128, 0, 0, 0);
            }

            100% {
                box-shadow: 0 0 0 0 rgba(128, 0, 0, 0);
            }
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(8px);
            z-index: 5000;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            transition: opacity 0.5s;
        }

        .loading-spinner {
            width: 80px;
            height: 80px;
            border: 5px solid rgba(255, 255, 255, 0.1);
            border-top-color: var(--accent);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
    </style>
</head>

<body>

    <!-- Intro Overlay -->
    <div id="introOverlay" class="overlay">
        <div
            style="text-align: center; max-width: 600px; padding: 40px; background: #1e1e1e; border-radius: 16px; border: 1px solid #333;">
            <h1 style="color: var(--accent);">Technical Round</h1>
            <p>Company: <strong><?php echo htmlspecialchars($companyName); ?></strong></p>
            <p style="color: #aaa; margin: 20px 0;">
                Prepare for a rigorous technical assessment.<br>
                The AI interviewer is strict and expects precise answers.<br>
                You will face both <strong>Conceptual</strong> questions and <strong>Practical Industry
                    Scenarios</strong>.
            </p>
            <div style="margin-bottom: 20px; <?php echo $driveId > 0 ? 'display:none;' : ''; ?>">
                <input type="text" id="roleInput" placeholder="Enter specific role (e.g. Backend Dev)"
                    value="<?php echo htmlspecialchars($roleName); ?>"
                    style="padding: 10px 14px; width: 100%; max-width: 320px; text-align: center; border-radius: 8px; border: 1px solid #444; background: #2a2a2a; color: #fff;">
            </div>
            <div id="proctor-env-box" style="margin-bottom: 20px; padding: 12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; text-align: left; font-size: 0.9rem;">
                <div style="font-weight: 600; color: var(--accent);"><i class="fas fa-shield-alt"></i> AI Proctoring Active</div>
                <div id="proctor-env-status" style="margin-top: 4px; color: #aaa; font-size: 0.85rem;">Camera & baseline calibration will initialize on start.</div>
            </div>
            <button id="btnStartTech" onclick="startSession()" class="btn-send" style="padding: 15px 40px; font-size: 1.1rem; border-radius: 8px; cursor: pointer;">Start Interface</button>
        </div>
    </div>

    <header>
        <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-terminal" style="color: var(--accent); font-size: 1.5rem;"></i>
            <div>
                <h2 style="margin: 0; font-size: 1.2rem;">Technical Assessment</h2>
                <div style="font-size: 0.8rem; color: #888;"><?php echo htmlspecialchars($companyName); ?></div>
            </div>
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
            <div id="sessionTimer" class="locked">
                <i class="fas fa-clock"></i>
                <span id="timerText">Initializing...</span>
            </div>
            <span class="role-badge" id="roleBadge">Loading...</span>
            <button id="endSessionBtn" onclick="endSession()" class="btn-end" disabled
                title="Minimum 20 minutes required for assigned tasks">End Session</button>
        </div>
    </header>

    <div class="main-container">
        <!-- Chat Side -->
        <div class="chat-panel">
            <div class="chat-history" id="chatHistory">
                <!-- Messages go here -->
            </div>
            <div class="input-area">
                <textarea id="userInput" placeholder="Type your answer... (Enter to send, Shift+Enter for new line)"
                    onkeydown="handleEnter(event)"></textarea>
                <button class="btn-send" onclick="sendMessage()"><i class="fas fa-paper-plane"></i></button>
            </div>
        </div>

        <!-- Code Side -->
        <div class="code-panel" id="codePanel" style="position: relative;">
            <!-- Locked Overlay -->
            <div id="editorLocked"
                style="position: absolute; top:0; left:0; width: 100%; height: 100%; z-index: 10; background: rgba(0,0,0,0.8); display: flex; flex-direction: column; justify-content: center; align-items: center; color: #888; text-align: center; padding: 20px;">
                <i class="fas fa-lock" style="font-size: 2rem; margin-bottom: 10px; color: var(--primary);"></i>
                <p style="margin-bottom: 5px; color: #fff; font-weight: bold;">Editor Locked</p>
                <small style="margin-bottom: 15px; display: block;">Waiting for Coding Challenge...</small>
                <button onclick="unlockWorkspaceManually()" class="btn" style="background: var(--accent); color: black; font-size: 0.8rem; padding: 6px 12px; font-weight: bold; border-radius: 4px; cursor: pointer; border: none; display: flex; align-items: center; gap: 5px;">
                    <i class="fas fa-unlock"></i> Unlock Coding Workspace
                </button>
            </div>

            <div class="code-header">
                <span id="problemTitle" style="font-weight: bold;">Coding Workspace</span>
                <div style="display: flex; gap: 10px;">
                    <select id="langSelect" style="background:#222; color:white; border:none; padding:5px;">
                        <option value="python">Python</option>
                        <option value="javascript">JavaScript</option>
                        <option value="java">Java</option>
                        <option value="cpp">C++</option>
                    </select>
                    <button onclick="runCode()" style="background: var(--accent); color: black;"><i
                            class="fas fa-play"></i> Run & Check</button>
                </div>
            </div>
            <div class="code-wrapper">
                <textarea id="codeEditor"></textarea>
            </div>
            <div class="console-panel">
                <div class="console-title">Output Console</div>
                <div id="consoleOutput" class="output">// Execution results will appear here...</div>
            </div>
        </div>
    </div>

    <!-- Score Modal -->
    <div id="scoreModal" class="hidden">
        <div class="score-card">
            <div class="score-title">Assessment Complete</div>
            <div>
                <span id="finalScoreNum" class="score-number">0</span><span id="finalScorePct"
                    class="score-percentage">%</span>
            </div>
            <div id="proctorPenaltyBox" style="display: none; margin: 12px 0; padding: 10px; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; font-size: 0.85rem;">
                <div style="color: #ccc;">Raw Performance: <strong id="rawScoreVal" style="color: #fff;">0%</strong></div>
                <div style="color: #ef4444; font-weight: 700; margin-top: 3px;"><i class="fas fa-shield-alt"></i> Proctor Penalty: <span id="penaltyPctVal">-0%</span></div>
            </div>
            <div class="score-desc" id="scoreDescText">Your technical performance has been evaluated.</div>
            <button class="btn-continue" onclick="closeSession()">Continue</button>
        </div>
    </div>


    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/python/python.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay hidden">
        <div class="loading-spinner"></div>
        <h2 style="margin: 0; letter-spacing: 2px;">GENERATING REPORT</h2>
        <p style="color: rgba(255,255,255,0.6); margin-top: 10px;">Please wait while AI evaluates your performance...
        </p>
    </div>

    <!-- Warning Overlay -->
    <div id="warningOverlay" class="overlay hidden" style="background: rgba(0,0,0,0.95); z-index: 2000;">
        <div
            style="text-align: center; max-width: 500px; padding: 30px; border: 2px solid var(--primary); background: #000; border-radius: 12px;">
            <i class="fas fa-exclamation-triangle"
                style="color: var(--primary); font-size: 3rem; margin-bottom: 20px;"></i>
            <h2 id="warningTitle" style="color: #fff; margin-bottom: 10px;">Security Violation</h2>
            <p id="warningText" style="color: #ccc; margin-bottom: 25px;">
                You left the assessment window or exited Full Screen mode. This is a violation of the assessment protocols.<br>
                Please return to full screen immediately to continue.
            </p>
            <button id="warningBtn" onclick="resumeFullscreen()" class="btn-send" style="width: 100%;">RESUME ASSESSMENT</button>
        </div>
    </div>

    <script>
        window.CSRF_TOKEN = '<?php echo $_SESSION['csrf_token'] ?? ''; ?>';

        function renderMath(element) {
            if (typeof renderMathInElement === 'function') {
                renderMathInElement(element, {
                    delimiters: [
                        { left: "$$", right: "$$", display: true },
                        { left: "$", right: "$", display: false },
                        { left: "\\(", right: "\\)", display: false },
                        { left: "\\[", right: "\\]", display: true }
                    ],
                    throwOnError: false
                });
            } else {
                setTimeout(() => renderMath(element), 100);
            }
        }
        let sessionId = null;
        // json_encode (not addslashes) so a value containing a closing script tag or a line break can't break the script
        let company = <?php echo json_encode((string)$companyName, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
        let driveId = <?php echo $driveId; ?>;
        let concept = <?php echo json_encode((string)$concept, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
        let editor;
        let currentProblem = null;
        let isSessionActive = false; // Track session state
        let isProcessing = false;    // Fix: was undefined, caused loadNextQuestion() to return immediately
        let startTime = null;
        let isTaskId = <?php echo $taskId ? 'true' : 'false'; ?>;
        const MIN_REQUIRED_TIME = 20 * 60; // 20 minutes in seconds
        let proctorEngine = null;
        let proctorReady = false;      // camera calibrated + monitoring started (don't redo it on a retry)
        let timerInterval = null;
        let isRunningCode = false;
        let isEndingSession = false;

        function escapeHtml(text) {
            return String(text ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }

        // Initialize Proctoring Engine
        try {
            proctorEngine = new ProctoringEngine({
                studentId: <?php echo json_encode((string)getUsername(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
                assessmentId: <?php echo (int)($taskId ?: ($driveId ?: 1)); ?>,
                assessmentType: 'technical',
                apiEndpoint: 'proctor_handler.php',
                onWarning: (data) => {
                    console.warn("Proctor Warning:", data);
                },
                onAutoSubmit: () => {
                    console.error("Proctor: Assessment auto-terminated due to maximum integrity violations.");
                    endSession(true);
                }
            });
        } catch (e) {
            console.error("ProctoringEngine instantiation error:", e);
        }

        // Initialize CodeMirror
        window.onload = function () {
            editor = CodeMirror.fromTextArea(document.getElementById("codeEditor"), {
                mode: "python",
                theme: "dracula",
                lineNumbers: true,
                autoCloseBrackets: true
            });
            editor.setValue("# Waiting for a coding challenge...");
        };

        // --- Fullscreen helpers (Safari < 16.4 only has the webkit-prefixed API) ---
        function getFullscreenElement() {
            return document.fullscreenElement || document.webkitFullscreenElement || null;
        }

        // The macOS fullscreen transition briefly blurs the window; don't treat that as leaving the test
        let fullscreenGraceUntil = 0;

        function requestFullscreenCompat() {
            fullscreenGraceUntil = Date.now() + 1500;
            if (proctorEngine && typeof proctorEngine.noteFullscreenRequest === 'function') {
                proctorEngine.noteFullscreenRequest();
            }
            const el = document.documentElement;
            if (el.requestFullscreen) return el.requestFullscreen();
            if (el.webkitRequestFullscreen) {
                el.webkitRequestFullscreen();
                return Promise.resolve();
            }
            return Promise.reject(new Error('Fullscreen API not supported'));
        }

        function exitFullscreenCompat() {
            if (!getFullscreenElement()) return;
            if (document.exitFullscreen) document.exitFullscreen().catch(e => console.log(e));
            else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
        }

        // isPrompt = true: plain "enter full screen" request (not a violation, e.g. the browser
        // refused fullscreen at session start because the click was too long ago)
        function showSecurityOverlay(isPrompt) {
            const titleEl = document.getElementById('warningTitle');
            const textEl = document.getElementById('warningText');
            const btnEl = document.getElementById('warningBtn');
            if (isPrompt) {
                titleEl.textContent = 'Full Screen Required';
                textEl.textContent = 'Click the button below to enter full screen and continue. This is not counted as a warning.';
                btnEl.textContent = 'ENTER FULL SCREEN';
            } else {
                titleEl.textContent = 'Security Violation';
                textEl.innerHTML = 'You left the assessment window or exited Full Screen mode. This is a violation of the assessment protocols.<br>Please return to full screen immediately to continue.';
                btnEl.textContent = 'RESUME ASSESSMENT';
            }
            document.getElementById('warningOverlay').classList.remove('hidden');
        }

        // These only show the overlay — strikes are counted by the proctoring engine itself
        function onFullscreenChange() {
            if (!getFullscreenElement() && isSessionActive) showSecurityOverlay(false);
        }
        document.addEventListener('fullscreenchange', onFullscreenChange);
        document.addEventListener('webkitfullscreenchange', onFullscreenChange);

        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden' && isSessionActive && Date.now() > fullscreenGraceUntil) {
                showSecurityOverlay(false);
            }
        });

        window.addEventListener('blur', () => {
            if (isSessionActive && Date.now() > fullscreenGraceUntil) {
                showSecurityOverlay(false);
            }
        });

        // --- Security Measures: Disable Copy/Paste/Right-Click ---
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('copy', e => e.preventDefault());
        document.addEventListener('cut', e => e.preventDefault());
        document.addEventListener('paste', e => e.preventDefault());

        document.addEventListener('keydown', e => {
            const key = (e.key || '').toLowerCase();
            // Disable Ctrl/Cmd+C, V, X, U (metaKey = Cmd on macOS). Other editor shortcuts (Cmd+Z/A/S, arrows) still work.
            if ((e.ctrlKey || e.metaKey) && ['c', 'v', 'x', 'u'].includes(key)) {
                e.preventDefault();
            }
            // Inspect: Ctrl+Shift+I / Cmd+Shift+I / Cmd+Option+I (Option changes e.key on Mac, so check e.code)
            if (((e.ctrlKey || e.metaKey) && e.shiftKey && (key === 'i' || e.code === 'KeyI')) ||
                (e.metaKey && e.altKey && e.code === 'KeyI')) {
                e.preventDefault();
            }
            // Disable F12
            if (e.key === 'F12') {
                e.preventDefault();
            }
        });

        function resumeFullscreen() {
            requestFullscreenCompat().then(() => {
                document.getElementById('warningOverlay').classList.add('hidden');
            }).catch(e => {
                // A native popup here would blur the window again, so show the hint inline
                const textEl = document.getElementById('warningText');
                if (textEl && !textEl.querySelector('.fs-blocked-hint')) {
                    textEl.insertAdjacentHTML('beforeend', '<br><br><span class="fs-blocked-hint" style="color:#f59e0b;">Your browser blocked full screen. Please click the button again, and allow full screen if your browser asks.</span>');
                }
            });
        }

        // Called once the session is live: the fullscreen request usually comes long after the
        // Start click (camera + calibration in between), so browsers refuse it. Ask for one more click.
        function ensureFullscreenOrPrompt() {
            setTimeout(() => {
                if (isSessionActive && !getFullscreenElement()) showSecurityOverlay(true);
            }, 700);
        }

        async function startSession() {
            const roleInput = document.getElementById('roleInput').value;
            const startBtn = document.getElementById('btnStartTech') || document.querySelector('.btn-send');
            const statusEl = document.getElementById('proctor-env-status');
            const isMac = /Mac/i.test(navigator.platform || navigator.userAgent);
            // Prevent a second click while camera/calibration/start is in progress
            if (startBtn) startBtn.disabled = true;

            // 1. Initialize Proctoring & Camera (skipped on a retry once calibration already passed)
            if (proctorEngine && !proctorReady) {
                if (statusEl) statusEl.innerHTML = '<i class="fas fa-spinner fa-spin" style="color:var(--accent);"></i> Initializing camera & proctoring session...';

                try {
                    // On a calibration retry the camera is already open — re-opening it would leak the old stream
                    if (!proctorEngine._stream) {
                        const camReady = await proctorEngine.init();
                        if (!camReady) {
                            // The engine wrote the specific reason (denied / in use / not found) into the status line
                            const engineMsg = statusEl ? statusEl.textContent.trim() : '';
                            if (startBtn) { startBtn.disabled = false; startBtn.textContent = 'Retry Camera'; }
                            if (statusEl) statusEl.innerHTML = '<span style="color:#ef4444;font-weight:600;"><i class="fas fa-exclamation-triangle"></i> '
                                + escapeHtml(engineMsg || 'Camera access required. Please allow camera in browser and retry.') + '</span>'
                                + (isMac
                                    ? '<br><span style="font-size:0.8rem;color:#aaa;">On a Mac: open System Settings → Privacy &amp; Security → Camera, turn on your browser, then quit and reopen the browser. Close FaceTime, Zoom or Teams if they are using the camera.</span>'
                                    : '<br><span style="font-size:0.8rem;color:#aaa;">Click the camera icon in the address bar to allow access, and close other apps that are using the camera.</span>');
                            return;
                        }
                    }

                    if (statusEl) statusEl.innerHTML = '<i class="fas fa-spinner fa-spin" style="color:var(--accent);"></i> Calibrating posture & identity baseline... Keep your face centered in the camera preview (bottom-right).';
                    const envCheck = await proctorEngine.runEnvCheck();
                    if (!envCheck.passed) {
                        if (startBtn) { startBtn.disabled = false; startBtn.textContent = 'Retry Calibration'; }
                        const reason = (envCheck.reasons && envCheck.reasons.length) ? envCheck.reasons.join(' ') : 'Camera calibration failed. Please ensure face is centered and lighting is adequate.';
                        if (statusEl) statusEl.innerHTML = `<span style="color:#ef4444;font-weight:600;"><i class="fas fa-exclamation-triangle"></i> ${escapeHtml(reason)}</span><br><span style="font-size:0.8rem;color:#aaa;">Face the screen with your face fully visible in the preview, add light in front of you, then click Retry Calibration.</span>`;
                        return;
                    }

                    proctorEngine.start();
                    proctorReady = true;
                } catch (pErr) {
                    console.warn("Proctor init warning:", pErr);
                }
            }

            // 2. Check for Active Session Resumption
            const checkRes = await apiCall({ action: 'check_active_session', company: company, drive_id: driveId });

            if (checkRes.success && checkRes.has_active) {
                sessionId = checkRes.session_id;
                isSessionActive = true;

                // Sync start time from server using elapsed_seconds to prevent timezone mismatches
                if (checkRes.elapsed_seconds !== undefined) {
                    startTime = Date.now() - (checkRes.elapsed_seconds * 1000);
                } else if (checkRes.started_at) {
                    startTime = new Date(checkRes.started_at.replace(/-/g, "/")).getTime();
                } else {
                    startTime = Date.now();
                }

                document.getElementById('introOverlay').classList.add('hidden');
                document.getElementById('roleBadge').innerText = checkRes.role || roleInput;

                await requestFullscreenCompat().catch((e) => console.log(e));
                ensureFullscreenOrPrompt();

                startTimer();
                updateState("Resuming technical session...", "neutral");

                // Re-render history
                if (checkRes.history && checkRes.history.length > 0) {
                    let lastPayload = null;
                    checkRes.history.forEach(m => {
                        if (m.content) {
                            // If it's a structured JSON string from assistant, try parsing it
                            let text = m.content;
                            try {
                                const parsed = JSON.parse(m.content);
                                if (m.role === 'assistant') {
                                    lastPayload = parsed;
                                }
                                if (parsed.question) text = parsed.question;
                                else if (parsed.problem_statement) text = parsed.problem_statement;
                            } catch (e) { }
                            addMessage(m.role === 'assistant' ? 'ai' : 'user', text);
                        }
                    });
                    addMessage('ai', "Continuing interview. Please look at the previous context.");

                    if (lastPayload && lastPayload.type === 'coding') {
                        currentProblem = lastPayload;
                        activateCodingMode(lastPayload);
                    } else {
                        currentProblem = null;
                        document.getElementById('editorLocked').style.display = 'flex';
                    }
                } else {
                    loadNextQuestion();
                }
                return;
            }

            const role = roleInput;
            document.getElementById('roleBadge').innerText = role;
            document.getElementById('introOverlay').classList.add('hidden');

            // Fullscreen trigger
            await requestFullscreenCompat().catch((e) => console.log(e));

            // API Call to start
            const res = await apiCall({ action: 'start_session', role: role, company: company, task_id: "<?php echo (int)$taskId; ?>", drive_id: driveId, concept: concept });
            if (res.success) {
                sessionId = res.session_id;
                isSessionActive = true;
                startTime = Date.now();
                ensureFullscreenOrPrompt();
                startTimer();
                loadNextQuestion();
            } else {
                // Previously a failed start left a blank screen with no feedback
                document.getElementById('introOverlay').classList.remove('hidden');
                if (startBtn) { startBtn.disabled = false; startBtn.textContent = 'Start Interface'; }
                await LakshyaDialog.alert('Could not start the technical round: ' + (res.message || 'Unknown error') + '\nPlease try again.', { type: 'error', title: 'Could Not Start' });
            }
        }

        function startTimer() {
            const timerContainer = document.getElementById('sessionTimer');
            const timerText = document.getElementById('timerText');
            const endBtn = document.getElementById('endSessionBtn');

            if (timerInterval) clearInterval(timerInterval);
            timerInterval = setInterval(() => {
                if (!isSessionActive) return;

                const elapsed = Math.floor((Date.now() - startTime) / 1000);

                if (isTaskId && elapsed < MIN_REQUIRED_TIME) {
                    const remaining = MIN_REQUIRED_TIME - elapsed;
                    const mins = Math.floor(remaining / 60);
                    const secs = remaining % 60;
                    timerText.innerText = `Lock: ${mins}:${secs.toString().padStart(2, '0')}`;
                    timerContainer.className = 'locked';
                    endBtn.disabled = true;
                    endBtn.title = `You must wait ${mins}m ${secs}s more before ending this assigned task.`;
                } else {
                    const mins = Math.floor(elapsed / 60);
                    const secs = elapsed % 60;
                    timerText.innerText = `Duration: ${mins}:${secs.toString().padStart(2, '0')}`;
                    timerContainer.className = 'unlocked';
                    endBtn.disabled = false;
                    endBtn.classList.add('unlocked');
                    endBtn.title = "";
                }
            }, 1000);
        }

        async function loadNextQuestion(userMsg = '') {
            if (isProcessing) return;
            isProcessing = true;
            showTyping();

            try {
                const res = await apiCall({ action: 'get_question', session_id: sessionId, message: userMsg });

                if (res.success && res.job_id) {
                    pollJobStatus(res.job_id, (data) => {
                        hideTyping();
                        isProcessing = false;
                        processAIResponse(data);
                    }, (err) => {
                        hideTyping();
                        isProcessing = false;
                        addMessage('ai', "⚠️ " + err + " — please resend your last answer to continue.");
                    });
                } else if (res.success && res.result) {
                    // Synchronous fallback path (queue/worker unavailable server-side)
                    hideTyping();
                    isProcessing = false;
                    processAIResponse(res.result);
                } else {
                    hideTyping();
                    isProcessing = false;
                    addMessage('ai', "⚠️ " + (res.message || "Failed to reach AI.") + " — please resend your last answer to continue.");
                }
            } catch (e) {
                hideTyping();
                isProcessing = false;
                LakshyaDialog.alert("Connection failed. Please resend your last answer to continue.", { type: 'error', title: 'Connection Failed' });
            }
        }

        async function pollJobStatus(jobId, onSuccess, onError, timeoutMs = 180000) {
            const startedAt = Date.now();
            let consecutiveErrors = 0;
            const poll = async () => {
                if (Date.now() - startedAt > timeoutMs) {
                    onError("The AI took too long to respond (timeout). Please try again.");
                    return;
                }
                try {
                    const res = await fetch(`ai_job_status.php?job_id=${jobId}`);
                    const data = await res.json();
                    consecutiveErrors = 0;
                    if (data.success === false) {
                        onError(data.message || "Job error");
                        return;
                    }
                    if (data.status === 'completed') {
                        if (data.result && data.result.success === false) {
                            onError(data.result.message || "AI failed to process request.");
                        } else {
                            onSuccess(data.result);
                        }
                    } else if (data.status === 'failed') onError(data.error || "AI job failed.");

                    else setTimeout(poll, 1500);
                } catch (e) {
                    // A single dropped poll must not abort the whole question load
                    consecutiveErrors++;
                    if (consecutiveErrors >= 5) onError("Polling error — connection lost.");
                    else setTimeout(poll, 3000);
                }
            };
            poll();
        }

        function processAIResponse(data) {
            if (!data) {
                addMessage('ai', "⚠️ The AI returned an empty response — please resend your last answer to continue.");
                return;
            }
            let payload = data;

            if (data.result && typeof data.result === 'object') {
                payload = data.result;
            } else if (data.content && typeof data.content === 'string') {
                try { payload = JSON.parse(data.content); } catch (e) { }
            }

            let isCode = payload.type === 'coding';
            let questionText = isCode ? payload.problem_statement : payload.question;

            // Fallback detection: if the AI asked a coding question but marked it as conceptual
            if (!isCode && typeof questionText === 'string' && questionText) {
                const textLower = questionText.toLowerCase();
                if (
                    textLower.includes('write a function') ||
                    textLower.includes('write a program') ||
                    textLower.includes('write code') ||
                    textLower.includes('implement a function') ||
                    textLower.includes('write a python') ||
                    textLower.includes('write a java') ||
                    textLower.includes('coding question') ||
                    textLower.includes('coding challenge') ||
                    textLower.includes('write a script') ||
                    textLower.includes('implement a method') ||
                    textLower.includes('write a method') ||
                    textLower.includes('write a class') ||
                    textLower.includes('implement a class') ||
                    textLower.includes('create a function') ||
                    textLower.includes('write a c++') ||
                    textLower.includes('write a sql') ||
                    textLower.includes('write sql') ||
                    textLower.includes('write javascript') ||
                    textLower.includes('write code to') ||
                    textLower.includes('coding task') ||
                    textLower.includes('program to') ||
                    textLower.includes('complete the code') ||
                    textLower.includes('write an algorithm') ||
                    textLower.includes('implement an algorithm')
                ) {
                    isCode = true;
                    payload.type = 'coding';
                    payload.problem_statement = questionText;
                }
            }

            const feedbackText = typeof payload.feedback === 'string' && payload.feedback.trim() !== '' ? `**Evaluation:** ${payload.feedback}\n\n` : '';

            let messageText = feedbackText;
            if (questionText) {
                messageText += questionText;
            } else if (typeof payload === 'string') {
                messageText += payload;
            }

            if (messageText.trim() !== '') {
                addMessage('ai', messageText.trim());
            }

            // Save AI response to database to persist context
            apiCall({ action: 'append_ai_history', session_id: sessionId, message: JSON.stringify(payload) });

            // Handle Coding State
            if (isCode) {
                currentProblem = payload;
                activateCodingMode(payload);
            } else {
                currentProblem = null;
                document.getElementById('editorLocked').style.display = 'flex';
            }
        }

        async function sendMessage() {
            const input = document.getElementById('userInput');
            const txt = input.value.trim();
            if (!txt) return;
            // loadNextQuestion() ignores calls while a request is in flight, so
            // sending now would show the answer in chat but never submit it.
            if (isProcessing) {
                LakshyaDialog.alert("The interviewer is still responding. Please wait for the next question, then send your answer.", { type: 'info', title: 'Please Wait' });
                return;
            }

            addMessage('user', txt);
            input.value = '';

            // If we are in coding mode, user might be explaining logic, but actual code submission is via Run button.
            // However, we process chat normally.
            loadNextQuestion(txt);
        }

        async function runCode() {
            if (!currentProblem) {
                LakshyaDialog.alert("No active coding challenge.", { type: 'info', title: 'No Challenge' });
                return;
            }
            // Repeated clicks used to submit the same code several times (and skip several questions on a pass)
            if (isRunningCode) return;
            isRunningCode = true;

            const code = editor.getValue();
            const lang = document.getElementById('langSelect').value;
            const outputDiv = document.getElementById('consoleOutput');

            outputDiv.innerText = "Running test cases via AI Evaluator...";
            outputDiv.className = "output";

            const res = await apiCall({
                action: 'submit_code',
                session_id: sessionId,
                code: code,
                language: lang,
                problem_statement: currentProblem.problem_statement
            });

            const renderEvaluation = (resultData) => {
                isRunningCode = false;
                let result = resultData;
                // Unwrap the possible payload shapes: {result: {...}} nesting or a JSON string in .content
                if (result && result.result && typeof result.result === 'object') {
                    result = result.result;
                } else if (result && result.content && typeof result.content === 'string') {
                    try { result = JSON.parse(result.content); } catch (e) { }
                }
                if (!result || typeof result !== 'object') {
                    outputDiv.innerText = "Evaluation returned an unreadable result. Please run again.";
                    outputDiv.className = "output error";
                    return;
                }
                outputDiv.innerText = `${result.feedback || 'No feedback'}\n\nPassed: ${result.passed ? 'YES ✓' : 'NO ✗'}\nScore: ${result.score || 0}/10`;
                outputDiv.className = result.passed ? "output success" : "output error";
                if (result.passed) {
                    setTimeout(async () => {
                        await LakshyaDialog.alert("Great execution! Moving to next challenge.", { type: 'success', title: 'Challenge Passed' });
                        if (isSessionActive) loadNextQuestion("Code submitted successfully. Ready for next.");
                    }, 2000);
                }
            };

            if (res.success && res.job_id) {
                outputDiv.innerText = "Evaluating... (this may take ~10s)";
                pollJobStatus(res.job_id, renderEvaluation, (err) => {
                    isRunningCode = false;
                    outputDiv.innerText = "Evaluation failed: " + err;
                    outputDiv.className = "output error";
                });
            } else if (res.success && res.result) {
                // Synchronous fallback path (queue/worker unavailable server-side)
                renderEvaluation(res.result);
            } else {
                isRunningCode = false;
                outputDiv.innerText = "Failed to submit code: " + (res.message || "Unknown error");
                outputDiv.className = "output error";
            }
        }

        async function endSession(forceAutoSubmit = false) {
            if (isEndingSession) return;
            if (!forceAutoSubmit) {
                const ok = await LakshyaDialog.confirm("Are you sure? This will end your session and generate your score.", {
                    title: 'End Session?', type: 'warning', okText: 'End & Generate Score', cancelText: 'Continue Interview'
                });
                // A proctor auto-submit may have started while the dialog was open
                if (!ok || isEndingSession) return;
            }
            isEndingSession = true;

            isSessionActive = false; // Disable enforcement for report generation
            if (proctorEngine) {
                try { proctorEngine.stop(); } catch (e) { }
            }
            document.getElementById('warningOverlay').classList.add('hidden');
            exitFullscreenCompat();

            document.getElementById('loadingOverlay').classList.remove('hidden');

            // 1. Get Report Data with proctoring audit token
            const res = await apiCall({
                action: 'generate_report_data',
                session_id: sessionId,
                proctor_token: proctorEngine ? (proctorEngine._token || '') : ''
            });

            document.getElementById('loadingOverlay').classList.add('hidden');
            if (res.success) {
                const modal = document.getElementById('scoreModal');
                const scoreNum = document.getElementById('finalScoreNum');
                const scorePct = document.getElementById('finalScorePct');
                const penaltyBox = document.getElementById('proctorPenaltyBox');

                scoreNum.innerText = res.score;
                if (res.score <= 0) {
                    scoreNum.classList.add('score-zero');
                    scorePct.classList.add('score-zero');
                } else {
                    scoreNum.classList.remove('score-zero');
                    scorePct.classList.remove('score-zero');
                }

                if (res.penalty_pct > 0 && penaltyBox) {
                    document.getElementById('rawScoreVal').innerText = (res.raw_score || res.score) + '%';
                    document.getElementById('penaltyPctVal').innerText = '-' + res.penalty_pct + '% (' + res.strike_count + ' Strike' + (res.strike_count > 1 ? 's' : '') + ')';
                    penaltyBox.style.display = 'block';
                }

                modal.classList.remove('hidden');
            } else {
                // Resume the interview so the student can keep going / retry ending
                isEndingSession = false;
                isSessionActive = true;
                LakshyaDialog.alert(res.message || "Failed to generate score data.", { type: 'error', title: 'Could Not Generate Score' });
            }

        }

        function closeSession() {
            window.location.href = driveId > 0 ? `student_drive.php?drive_id=${driveId}` : 'dashboard.php';
        }

        function activateCodingMode(data) {
            document.getElementById('editorLocked').style.display = 'none';

            document.getElementById('problemTitle').innerText = "CHALLENGE ACTIVE";

            // Set starter code or comment
            const problemText = data.problem_statement || data.question || '';
            const starter = `# Problem: ${problemText}\n# Constraints: ${data.constraints || 'None'}\n# Write your solution below:\n\n`;
            editor.setValue(starter);
        }

        function unlockWorkspaceManually() {
            // Unlocks the workspace manually if classification failed
            const currentMessageNodes = document.querySelectorAll('.message.ai');
            let lastAiText = "Custom Coding Task";
            if (currentMessageNodes.length > 0) {
                lastAiText = currentMessageNodes[currentMessageNodes.length - 1].innerText;
            }

            // Construct a mock coding payload
            const mockPayload = {
                type: 'coding',
                problem_statement: lastAiText,
                constraints: 'None'
            };

            currentProblem = mockPayload;
            activateCodingMode(mockPayload);
        }

        // --- Helpers ---
        async function apiCall(data) {
            try {
                const formData = new FormData();
                for (const k in data) formData.append(k, data[k]);
                // Tells the handler whether session_id is a drive attempt or a practice session
                if (!('drive_id' in data)) formData.append('drive_id', driveId);
                formData.append('csrf_token', window.CSRF_TOKEN);

                const response = await fetch('ai_technical_handler', {
                    method: 'POST',
                    headers: { 'X-CSRF-TOKEN': window.CSRF_TOKEN },
                    body: formData
                });
                const responseClone = response.clone();
                let result;
                try {
                    result = await response.json();
                } catch (jsonErr) {
                    return { success: false, message: 'Server communication error.' };
                }
                return result;
            } catch (e) {
                return { success: false, message: 'Connection Error' };
            }
        }

        function addMessage(role, text) {
            const div = document.createElement('div');
            div.className = `message ${role}`;

            // Escape first: code like vector<int> or List<String> was being parsed
            // as HTML tags, silently swallowing parts of the question.
            const escaped = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            // Simple Markdown parsing
            let html = escaped.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\n/g, '<br>');

            div.innerHTML = `<div class="bubble">${html}</div>`;
            document.getElementById('chatHistory').appendChild(div);
            renderMath(div);
            document.getElementById('chatHistory').scrollTop = document.getElementById('chatHistory').scrollHeight;
        }

        function showTyping() { /* optional loader */ }
        function hideTyping() { /* optional loader */ }

        function handleEnter(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        }
        function updateState(msg, type) {
            // State update handled internally
        }
    </script>
</body>

</html>