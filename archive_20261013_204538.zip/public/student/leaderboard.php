<?php
/**
 * Student Leaderboard - Premium UI with Insight Panel
 */

require_once __DIR__ . '/../../config/bootstrap.php';
use App\Services\LeaderboardService;

requireRole(ROLE_STUDENT);
if (!isFeatureEnabled('feature_leaderboard')) {
    Session::flash('info', 'The AI Leaderboard is temporarily disabled for maintenance or updates.');
    redirect('/Lakshya/student/dashboard.php');
}

$myUsn = getUsername();
$myDept = getDepartment();
$myInst = getInstitution();

// Resolve canonical USN and Aadhar for GMIT students
// (login may use Aadhar, but leaderboard entries use student_id/USN)
$myAadhar = '';
$myCanonicalUsn = $myUsn; // default
try {
    $remoteDB = getDB('gmit');
    if ($remoteDB && $myInst === INSTITUTION_GMIT) {
        $stmtMe = $remoteDB->prepare(
            "SELECT IFNULL(NULLIF(usn, ''), student_id) as canonical_usn, aadhar 
             FROM ad_student_details 
             WHERE student_id = ? OR usn = ? OR aadhar = ? LIMIT 1"
        );
        $stmtMe->execute([$myUsn, $myUsn, $myUsn]);
        $meRow = $stmtMe->fetch(PDO::FETCH_ASSOC);
        if ($meRow) {
            $myCanonicalUsn = $meRow['canonical_usn'] ?: $myUsn;
            $myAadhar = $meRow['aadhar'] ?: '';
        }
    }
} catch (Exception $e) {
    // Ignore — fallback to username
}

$pageTitle = "Leaderboard | Lakshya";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <script>
        const originalWarn = console.warn;
        console.warn = function(...args) {
            if (args[0] && typeof args[0] === 'string' && args[0].includes('cdn.tailwindcss.com should not be used')) return;
            originalWarn(...args);
        };
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/Flip.min.js"></script>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
    <link rel="shortcut icon" href="data:image/x-icon;," type="image/x-icon">

    <style>
        :root {
            --primary: #800000;
            --secondary: #4a0000;
            --accent: #D4AF37;
            --gold: #D4AF37;
            --silver: #94A3B8;
            --bronze: #CD7F32;
            --bg-glass: rgba(255, 255, 255, 0.88);
        }

        * { box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: #faf9f7;
            color: #0f172a;
            overflow-x: hidden;
            position: relative;
        }

        .outfit { font-family: 'Outfit', sans-serif; }

        /* Background Animated Blobs */
        .vibe-container {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }
        .blob {
            position: absolute;
            width: 500px; height: 500px;
            filter: blur(90px);
            border-radius: 50%;
            opacity: 0.12;
            animation: move 20s infinite alternate;
        }
        .blob-1 { top: -120px; right: -80px; background: radial-gradient(circle, #800000, #4a0000); animation-duration: 25s; }
        .blob-2 { bottom: -150px; left: -100px; background: radial-gradient(circle, #D4AF37, #a07c10); opacity: 0.10; animation-duration: 30s; }
        .blob-3 { top: 35%; left: 25%; width: 350px; height: 350px; background: radial-gradient(circle, #800000, transparent); opacity: 0.07; animation-duration: 22s; }

        @keyframes move {
            from { transform: translate(0, 0) scale(1); }
            to { transform: translate(80px, 60px) scale(1.12); }
        }

        /* Glass Card */
        .glass-card {
            background: var(--bg-glass);
            backdrop-filter: blur(28px) saturate(200%);
            -webkit-backdrop-filter: blur(28px) saturate(200%);
            border: 1px solid rgba(255,255,255,0.85);
            box-shadow: 0 8px 32px rgba(0,0,0,0.04);
            border-radius: 24px;
        }

        /* Rank Row */
        .rank-row {
            transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .rank-row.is-me {
            cursor: pointer;
        }
        .rank-row.is-me:hover {
            transform: scale(1.01) translateY(-3px);
            background: rgba(255,255,255,1);
            box-shadow: 0 20px 50px rgba(128,0,0,0.09);
            border-color: rgba(128,0,0,0.18);
        }
        .rank-row.is-me.selected {
            box-shadow: 0 0 0 2px #800000, 0 20px 50px rgba(128,0,0,0.12);
        }

        /* Rank Badges */
        .rank-badge {
            width: 42px; height: 42px;
            display: flex; align-items: center; justify-content: center;
            border-radius: 14px;
            font-weight: 800;
            font-size: 1rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        .rank-1 { background: linear-gradient(135deg, #FFD93D, #FF8400); color: #fff; }
        .rank-2 { background: linear-gradient(135deg, #DEE4E7, #94A3B8); color: #fff; }
        .rank-3 { background: linear-gradient(135deg, #FFBB5C, #C63D2F); color: #fff; }

        /* Podium */
        .podium-container {
            display: flex;
            align-items: flex-end;
            justify-content: center;
            gap: 20px;
            margin-bottom: 60px;
            perspective: 2000px;
        }
        .podium-step {
            flex: 1;
            max-width: 340px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
        }
        .podium-card {
            width: 100%;
            transition: all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
            border: 1px solid rgba(255,255,255,0.4);
            z-index: 10;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }
        .podium-base {
            width: 100%;
            margin-top: -45px;
            border-radius: 24px 24px 0 0;
            display: flex;
            align-items: flex-end; /* Align to bottom */
            justify-content: center;
            padding-bottom: 10px; /* Push number up slightly from absolute bottom */
            font-family: 'Outfit', sans-serif;
            font-weight: 900;
            font-size: 4rem;
            color: rgba(255,255,255,0.25);
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15), inset 0 2px 10px rgba(255,255,255,0.3);
        }
        .podium-base::after {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 50%, rgba(0,0,0,0.1) 100%);
            pointer-events: none;
        }
        
        /* Rank Specific Steps */
        .step-1 .podium-base { 
            height: 220px; 
            background: linear-gradient(135deg, #FFD700 0%, #D4AF37 50%, #B8860B 100%); 
            z-index: 5;
            box-shadow: 0 0 40px rgba(212, 175, 55, 0.3), inset 0 0 20px rgba(255,255,255,0.4);
        }
        .step-1 .podium-card {
            transform: translateY(-5px);
            animation: float-1 4s ease-in-out infinite;
        }
        .step-2 .podium-base { 
            height: 160px; 
            background: linear-gradient(135deg, #F8FAFC 0%, #CBD5E1 50%, #94A3B8 100%); 
            z-index: 4;
        }
        .step-2 .podium-card {
            animation: float-2 5s ease-in-out infinite;
        }
        .step-3 .podium-base { 
            height: 120px; 
            background: linear-gradient(135deg, #FFE4B5 0%, #CD7F32 50%, #A0522D 100%); 
            z-index: 3;
        }
        .step-3 .podium-card {
            animation: float-3 6s ease-in-out infinite;
        }

        @keyframes float-1 { 0%, 100% { transform: translateY(-5px); } 50% { transform: translateY(-15px); } }
        @keyframes float-2 { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
        @keyframes float-3 { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }

        .podium-card.winner {
            border-color: rgba(212, 175, 55, 0.5);
            background: rgba(255, 255, 255, 0.85);
            box-shadow: 0 25px 70px rgba(212, 175, 55, 0.25);
        }
        .podium-card.is-me.selected { box-shadow: 0 0 0 4px #800000, 0 30px 80px rgba(128,0,0,0.2); }

        @media (max-width: 768px) {
            .podium-container { flex-direction: column; align-items: stretch; gap: 32px; }
            .podium-step { max-width: 100%; }
            .podium-base { height: 24px !important; margin-top: 10px; border-radius: 12px; font-size: 1.5rem; }
            .step-1 .podium-card, .step-2 .podium-card, .step-3 .podium-card { animation: none; }
        }

        /* --- INSIGHT DRAWER --- */
        #insight-drawer {
            position: fixed;
            right: 0;
            top: 0;
            bottom: 0;
            height: 100vh;
            width: 440px;
            max-width: 96vw;
            background: #fff;
            box-shadow: -15px 0 60px rgba(0,0,0,0.25);
            z-index: 2500;
            transform: translateX(110%);
            transition: transform 0.45s cubic-bezier(0.4, 0, 0.2, 1);
            overflow-y: auto;
            scrollbar-width: none;
            border-left: 1px solid rgba(0,0,0,0.06);
        }
        #insight-drawer.open { transform: translateX(0); }
        #insight-drawer::-webkit-scrollbar { display: none; }
        #insight-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 23, 42, 0.45);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            z-index: 2400;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.35s ease;
        }
        #insight-overlay.open { opacity: 1; pointer-events: all; }

        .drawer-header-gold { background: linear-gradient(135deg, #800000 0%, #4a0000 100%); }

        .insight-pill {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 5px 14px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 700;
        }

        .suggestion-item {
            display: flex; gap: 14px; align-items: flex-start;
            padding: 14px 0;
            border-bottom: 1px solid #f1f5f9;
            animation: fadeSlideIn 0.4s ease both;
        }
        .suggestion-item:last-child { border-bottom: none; }

        @keyframes fadeSlideIn {
            from { opacity: 0; transform: translateX(20px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .suggestion-icon {
            width: 40px; height: 40px; border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0; font-size: 1.1rem;
        }

        /* Gap bar */
        .gap-bar-track {
            background: #f1f5f9; border-radius: 50px; height: 8px; width: 100%;
        }
        .gap-bar-fill {
            height: 8px; border-radius: 50px;
            background: linear-gradient(90deg, #800000, #D4AF37);
            transition: width 1.2s cubic-bezier(0.4,0,0.2,1);
        }

        /* Sticky Rank */
        .sticky-rank {
            position: fixed;
            bottom: 2rem; left: 50%;
            transform: translateX(-50%);
            width: 90%; max-width: 800px;
            z-index: 500;
        }

        /* Shimmer */
        .shimmer {
            background: linear-gradient(90deg, #f8fafc 25%, #f1f5f9 50%, #f8fafc 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
        }
        @keyframes shimmer {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        /* Toggle buttons */
        .btn-toggle { position: relative; overflow: hidden; z-index: 1; }
        .btn-toggle::after {
            content: '';
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            z-index: -1; opacity: 0;
            transition: opacity 0.3s ease;
        }
        .btn-toggle.active { color: white; }
        .btn-toggle.active::after { opacity: 1; }

        /* Loader */
        #leaderboard-loader {
            position: fixed; inset: 0;
            background: rgba(255,255,255,0.5);
            backdrop-filter: blur(12px);
            z-index: 1000;
            display: none; align-items: center; justify-content: center;
            opacity: 0; transition: opacity 0.3s ease;
        }
        @keyframes pulse {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.05); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.8; }
        }
        @keyframes bounceIn {
            from { opacity: 0; transform: scale(0.3); }
            to { opacity: 1; transform: scale(1); }
        }
        .loader-icon {
            font-size: 3rem;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            animation: pulse 1.5s infinite;
        }

        /* Celebration Overlay */
        #celebration-overlay {
            position: fixed; inset: 0;
            pointer-events: none; z-index: 1000;
            display: none; align-items: center; justify-content: center;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(8px);
        }

        /* Avatar letter circle */
        .avatar-circle {
            background: linear-gradient(135deg, #800000 0%, #D4AF37 100%);
            color: white;
            font-weight: 900;
            font-family: 'Outfit', sans-serif;
            letter-spacing: -0.5px;
        }

        /* Crown glow for #1 */
        @keyframes crownGlow {
            0%, 100% { filter: drop-shadow(0 0 6px #D4AF37) drop-shadow(0 0 14px #D4AF37aa); }
            50% { filter: drop-shadow(0 0 12px #D4AF37) drop-shadow(0 0 28px #D4AF37cc); }
        }
        .crown-glow { animation: crownGlow 2.5s ease-in-out infinite; font-size: 1.3rem; }

        /* Stat chip */
        .stat-chip {
            background: #fff8f0;
            border: 1px solid #fde8c0;
            border-radius: 12px;
            padding: 10px 16px;
            text-align: center;
        }

        /* How it Works Modal */
        #info-modal {
            position: fixed; inset: 0;
            background: rgba(15, 23, 42, 0.45);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            z-index: 3000;
            display: none; align-items: center; justify-content: center;
            opacity: 0; transition: opacity 0.4s ease;
            padding: 20px;
        }
        #info-modal.open { display: flex; opacity: 1; }
        .info-card {
            background: rgba(255, 255, 255, 0.98);
            width: 100%; max-width: 680px;
            max-height: 88vh;
            overflow-y: auto;
            border-radius: 32px;
            box-shadow: 0 40px 100px rgba(0,0,0,0.25);
            animation: modalSlideUp 0.5s cubic-bezier(0.19, 1, 0.22, 1);
        }
        .info-card::-webkit-scrollbar { width: 6px; }
        .info-card::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        @keyframes modalSlideUp {
            from { transform: translateY(40px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .info-header {
            background: #fff;
            padding: 40px 40px 20px;
            position: relative;
            text-align: center;
        }
        .info-body { padding: 0 40px 40px; }
        .scoring-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 24px;
        }
        .scoring-card {
            background: #f8fafc;
            border-radius: 24px;
            padding: 24px;
            border: 1px solid #e2e8f0;
            text-align: center;
            transition: all 0.3s ease;
        }
        .scoring-card:hover { border-color: #80000033; transform: translateY(-2px); }
        .scoring-card.primary { background: #fff1f2; border-color: #fecaca; }
        
        .info-close {
            position: absolute; top: 24px; right: 24px;
            width: 32px; height: 32px;
            border-radius: 50%;
            background: #f1f5f9;
            color: #64748b;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: all 0.2s;
        }
        .info-close:hover { background: #e2e8f0; color: #0f172a; }

        /* --- Score Calculation Breakdown Modal --- */
        .breakdown-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            z-index: 3000;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .breakdown-modal-window {
            background: #ffffff;
            border-radius: 24px;
            width: 100%;
            max-width: 520px;
            box-shadow: 0 25px 60px -12px rgba(0, 0, 0, 0.35);
            overflow: hidden;
            animation: bdModalSlideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            border: 1px solid rgba(226, 232, 240, 0.9);
        }

        @keyframes bdModalSlideUp {
            from { opacity: 0; transform: translateY(24px) scale(0.96); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        .breakdown-modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid #f1f5f9;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #ffffff;
        }

        .breakdown-modal-header h3 {
            font-size: 17px;
            font-weight: 800;
            color: #0f172a;
            font-family: 'Outfit', sans-serif;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .breakdown-modal-close-btn {
            background: #f1f5f9;
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 9px;
            font-size: 18px;
            color: #64748b;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.15s;
        }

        .breakdown-modal-close-btn:hover {
            background: #e2e8f0;
            color: #0f172a;
        }

        .breakdown-modal-body {
            padding: 22px 24px;
            max-height: calc(85vh - 120px);
            overflow-y: auto;
        }

        .calc-breakdown-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 14px 16px;
            margin-bottom: 12px;
        }

        .calc-card-title {
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #475569;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            font-family: 'Outfit', sans-serif;
        }

        .calc-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 4px 0;
            font-size: 12.5px;
            color: #64748b;
        }

        .calc-row strong {
            color: #0f172a;
        }

        .calc-subtotal-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 8px;
            margin-top: 8px;
            border-top: 1px dashed #cbd5e1;
            font-size: 13px;
            font-weight: 700;
            color: #1e293b;
            font-family: 'Outfit', sans-serif;
        }

        .calc-final-banner {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            color: #ffffff;
            border-radius: 16px;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
            box-shadow: 0 10px 25px -4px rgba(15, 23, 42, 0.35);
        }

        .calc-final-banner .lbl {
            font-size: 13px;
            font-weight: 800;
            color: #94a3b8;
            font-family: 'Outfit', sans-serif;
        }

        .calc-final-banner .val {
            font-size: 26px;
            font-weight: 900;
            color: #38bdf8;
            font-family: 'Outfit', sans-serif;
        }
    </style>
</head>
<body class="min-h-screen">

    <div class="vibe-container">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php include 'includes/navbar.php'; ?>

    <!-- Loader -->
    <div id="leaderboard-loader" style="display:none; align-items:center; justify-content:center;">
        <div style="text-align:center; animation:bounceIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275) both;">
            <div class="loader-icon outfit font-black"><i class="fas fa-crown"></i></div>
            <h2 class="text-xl font-black outfit text-slate-800 mt-3">Summarizing Greatness...</h2>
            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Syncing Elite Data</p>
        </div>
    </div>

    <main class="container mx-auto px-4 py-8 pb-36">

        <!-- Header -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-5">
            <div>
                <div class="flex items-center gap-3 mb-1">
                    <span class="crown-glow">👑</span>
                    <h1 class="text-3xl font-black outfit text-slate-900">Elite Leaderboard</h1>
                    <button onclick="openInfoModal()" class="w-8 h-8 rounded-full bg-slate-100 text-slate-400 hover:bg-[#800000]/10 hover:text-[#800000] flex items-center justify-center transition-all ml-1 shadow-sm border border-slate-200" title="How it works">
                        <i class="fas fa-info text-xs"></i>
                    </button>
                </div>
                <p class="text-slate-500 font-medium tracking-tight">Real-time performance rankings based on AI Pillars &amp; Portfolio. <span class="text-[#800000] font-semibold">Click on your card for personalised insights.</span></p>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-xs text-slate-400 font-bold uppercase tracking-wider hidden md:flex items-center gap-2">
                    <span class="w-2 h-2 bg-green-400 rounded-full inline-block animate-pulse"></span>Live
                </div>
                <div class="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm">
                    <button onclick="changeView('local')" id="btn-local" class="btn-toggle active view-btn px-7 py-2.5 rounded-xl text-sm font-bold transition-all duration-300">
                        <i class="fas fa-building mr-1.5 text-xs"></i> Department
                    </button>
                    <button onclick="changeView('global')" id="btn-global" class="btn-toggle view-btn px-7 py-2.5 rounded-xl text-sm font-bold transition-all duration-300 text-slate-500 hover:text-slate-700">
                        <i class="fas fa-globe mr-1.5 text-xs"></i> Global
                    </button>
                </div>
            </div>
        </div>

        <!-- Podium -->
        <div id="podium-container" class="podium-container pt-12">
            <!-- Rendered by JS -->
        </div>

        <!-- Table Header -->
        <div class="hidden md:grid grid-cols-12 px-7 py-3 text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
            <div class="col-span-1">Rank</div>
            <div class="col-span-8">Student</div>
            <div class="col-span-3 text-right">Total Points</div>
        </div>

        <!-- Rankings List -->
        <div id="rankings-list" class="space-y-3">
            <?php for($i=0; $i<5; $i++): ?>
                <div class="glass-card h-20 rounded-2xl shimmer opacity-50"></div>
            <?php endfor; ?>
        </div>
    </main>

    <!-- Sticky My Rank Bar -->
    <div id="my-sticky-rank" class="sticky-rank hidden">
        <div class="glass-card px-6 py-4 rounded-[28px] border border-red-100 shadow-[0_20px_50px_rgba(128,0,0,0.12)] flex items-center justify-between gap-4">
            <div class="flex items-center gap-4">
                <div id="my-rank-badges" class="bg-gradient-to-br from-[#800000] to-[#4a0000] text-white w-12 h-12 flex items-center justify-center rounded-2xl font-black text-lg shadow-lg ring-2 ring-[#D4AF37]/40">--</div>
                <div>
                    <h4 class="font-black text-slate-800 outfit text-base">Your Performance</h4>
                    <p class="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Keep pushing to climb!</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right cursor-pointer group" onclick="showMyScoreBreakdown()" title="Click to view detailed Score Breakdown">
                    <div id="my-total-score" class="text-2xl font-black outfit text-transparent bg-clip-text bg-gradient-to-r from-[#800000] to-[#4a0000] group-hover:opacity-80 transition flex items-center justify-end gap-1.5">--</div>
                    <div class="text-[10px] uppercase font-black text-[#800000]/60 tracking-[0.2em] flex items-center gap-1 justify-end">
                        Total Points <i class="fas fa-calculator text-[8px] opacity-70"></i>
                    </div>
                </div>
                <button onclick="openMyInsight()" class="bg-gradient-to-br from-[#800000] to-[#4a0000] text-white px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 hover:opacity-90 transition shadow-lg">
                    <i class="fas fa-chart-line"></i> My Insight
                </button>
            </div>
        </div>
    </div>

    <!-- Insight Drawer Overlay -->
    <div id="insight-overlay" onclick="closeDrawer()"></div>

    <!-- Insight Drawer -->
    <div id="insight-drawer">
        <!-- Drawer Header (sticky inside drawer scroll) -->
        <div class="drawer-header-gold p-6 text-white sticky top-0 z-20">
            <div class="flex justify-between items-start mb-4">
                <div class="flex items-center gap-3">
                    <div id="drawer-avatar" class="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black outfit shadow-lg bg-white/20 backdrop-blur overflow-hidden"></div>
                    <div>
                        <p class="text-white/70 text-xs font-bold uppercase tracking-widest">Rank Insights</p>
                        <h2 id="drawer-name" class="text-xl font-black outfit leading-tight"></h2>
                        <p id="drawer-dept" class="text-white/60 text-xs font-semibold uppercase tracking-wider mt-0.5"></p>
                    </div>
                </div>
                <button onclick="closeDrawer()" class="w-9 h-9 rounded-xl bg-white/20 hover:bg-white/30 flex items-center justify-center transition">
                    <i class="fas fa-times text-white text-sm"></i>
                </button>
            </div>
            <!-- Score Row -->
            <div class="grid grid-cols-3 gap-3">
                <div class="bg-white/15 rounded-2xl p-3 text-center cursor-pointer hover:bg-white/25 transition group" onclick="showScoreBreakdownByUsn(selectedUsn)" title="Click to view detailed Score Breakdown">
                    <div id="drawer-score" class="text-2xl font-black outfit"></div>
                    <div class="text-[10px] text-white/70 font-bold uppercase tracking-wider mt-0.5 flex items-center justify-center gap-1">
                        Score <i class="fas fa-calculator text-[8px] opacity-80"></i>
                    </div>
                </div>
                <div class="bg-white/15 rounded-2xl p-3 text-center">
                    <div id="drawer-rank" class="text-2xl font-black outfit"></div>
                    <div class="text-[10px] text-white/60 font-bold uppercase tracking-wider mt-0.5">Rank</div>
                </div>
                <div class="bg-white/15 rounded-2xl p-3 text-center">
                    <div id="drawer-rank-change" class="text-2xl font-black outfit"></div>
                    <div class="text-[10px] text-white/60 font-bold uppercase tracking-wider mt-0.5">Change</div>
                </div>
            </div>
        </div>

        <!-- Drawer Body -->
        <div class="p-6 space-y-6">

            <!-- Detailed Score Breakdown Action Button -->
            <button type="button" onclick="showScoreBreakdownByUsn(selectedUsn)" class="w-full p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 hover:from-black hover:to-slate-900 text-white flex items-center justify-between shadow-lg hover:shadow-xl transition group text-left">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-amber-400 text-lg group-hover:scale-110 transition">
                        <i class="fas fa-calculator"></i>
                    </div>
                    <div>
                        <div class="text-xs font-black outfit uppercase tracking-wider text-amber-300">Detailed Score Breakdown</div>
                        <div class="text-xs text-slate-300 font-medium">See AI pipeline, portfolio points &amp; decay</div>
                    </div>
                </div>
                <div class="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white/70 group-hover:text-white group-hover:translate-x-0.5 transition text-xs">
                    <i class="fas fa-chevron-right"></i>
                </div>
            </button>

            <!-- Gap from #1 -->
            <div id="gap-section" class="hidden">
                <div class="flex justify-between items-center mb-2">
                    <p class="text-sm font-bold text-slate-700"><i class="fas fa-crosshairs text-[#800000] mr-1.5"></i> Gap from #1</p>
                    <span id="gap-label" class="text-xs font-black text-[#800000]"></span>
                </div>
                <div class="gap-bar-track">
                    <div id="gap-bar-fill" class="gap-bar-fill" style="width:0%"></div>
                </div>
                <p id="gap-desc" class="text-xs text-slate-400 mt-1.5 font-medium"></p>
            </div>

            <!-- Motivation / Status Message -->
            <div id="motivation-block" class="rounded-2xl p-4 border">
                <p id="motivation-icon" class="text-2xl mb-2"></p>
                <h3 id="motivation-title" class="font-black text-sm outfit mb-1"></h3>
                <p id="motivation-text" class="text-sm text-slate-600 leading-relaxed"></p>
            </div>

            <!-- Suggestions -->
            <div>
                <h3 class="text-sm font-black text-slate-800 outfit mb-3 flex items-center gap-2">
                    <span class="w-6 h-6 bg-[#800000] text-white rounded-lg flex items-center justify-center text-xs"><i class="fas fa-lightbulb"></i></span>
                    Action Plan
                </h3>
                <div id="suggestions-list"></div>
            </div>
        </div>
    </div>

    <!-- Celebration Overlay -->
    <div id="celebration-overlay">
        <div class="text-center">
            <lottie-player src="https://fonts.gstatic.com/s/e/notoemoji/latest/1f389/lottie.json" background="transparent" speed="1" style="width:300px;height:300px;margin:0 auto;" autoplay></lottie-player>
            <h2 class="text-4xl font-black outfit text-[#800000] mt-[-30px] mb-2 drop-shadow-lg" id="celebration-text">Congratulations!</h2>
            <p class="text-xl text-slate-700 font-semibold" id="celebration-subtext">You've entered the Top 10!</p>
        </div>
    </div>

    <!-- How it Works Modal -->
    <div id="info-modal" onclick="closeInfoModal(event)">
        <div class="info-card" onclick="event.stopPropagation()">
            <div class="info-header text-slate-900 pb-2 border-b border-slate-100">
                <button class="info-close" onclick="closeInfoModal(event)">
                    <i class="fas fa-times"></i>
                </button>
                <div class="flex justify-center mb-2">
                    <div class="w-12 h-12 bg-[#800000] rounded-2xl flex items-center justify-center text-white text-xl shadow-lg ring-4 ring-red-50">
                        <i class="fas fa-trophy"></i>
                    </div>
                </div>
                <h2 class="text-2xl font-black outfit leading-tight text-slate-900">How Leaderboard Points Work</h2>
                <p class="text-slate-400 text-[11px] font-bold uppercase tracking-widest mt-0.5">Fair, Competitive & Transparent</p>
                
                <!-- Tab Selector -->
                <div class="flex items-center justify-center p-1 bg-slate-100 rounded-xl mt-3 max-w-sm mx-auto">
                    <button type="button" id="tab-btn-rules" onclick="switchInfoTab('rules')" class="flex-1 py-1.5 px-3 text-xs font-black outfit rounded-lg transition-all bg-white text-[#800000] shadow-sm">
                        <i class="fas fa-calculator mr-1"></i> Scoring Rules
                    </button>
                    <button type="button" id="tab-btn-examples" onclick="switchInfoTab('examples')" class="flex-1 py-1.5 px-3 text-xs font-black outfit rounded-lg transition-all text-slate-500 hover:text-slate-800">
                        <i class="fas fa-users-viewfinder mr-1"></i> Real Examples & Data
                    </button>
                </div>
            </div>

            <div class="info-body space-y-4 pt-4">
                <!-- TAB 1: RULES & WEIGHTS -->
                <div id="info-tab-rules" class="space-y-4">
                    <!-- Score Breakdown Grid -->
                    <div class="scoring-grid !mb-0">
                        <div class="scoring-card primary">
                            <div class="text-[10px] font-black text-[#800000] uppercase tracking-wider mb-1">AI Assessment Score</div>
                            <div class="text-3xl font-black outfit text-slate-800">70<span class="text-sm ml-0.5 text-[#800000] opacity-60">%</span></div>
                            <p class="text-[10px] text-slate-500 font-bold mt-1 uppercase">Tech (45%) · Apt (30%) · HR (25%)</p>
                        </div>
                        <div class="scoring-card">
                            <div class="text-[10px] font-black text-slate-500 uppercase tracking-wider mb-1">Portfolio Score</div>
                            <div class="text-3xl font-black outfit text-slate-800">30<span class="text-sm ml-0.5 opacity-40">%</span></div>
                            <p class="text-[10px] text-slate-500 font-bold mt-1 uppercase">Skills · Projects</p>
                        </div>
                    </div>

                    <!-- Practice Safe Shield Callout -->
                    <div class="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-start gap-3">
                        <div class="w-8 h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-sm shrink-0 shadow-sm mt-0.5">
                            <i class="fas fa-shield-halved"></i>
                        </div>
                        <div>
                            <h4 class="text-xs font-black text-emerald-900 uppercase tracking-wider">Practice With Confidence (Top-3 Mastery)</h4>
                            <p class="text-[12px] text-emerald-700 font-medium mt-0.5 leading-relaxed">
                                Taking more mocks and practice tests <b>never reduces your score</b>. Your rank uses your <b>Top 3 Best Performances</b> (50% Best + 30% 2nd + 20% 3rd). A lower practice attempt will never drag your rank down!
                            </p>
                        </div>
                    </div>

                    <!-- Difficulty Tiers -->
                    <div class="bg-slate-50 rounded-2xl p-3.5 border border-slate-100">
                        <h4 class="text-xs font-black text-slate-800 uppercase tracking-wider mb-2.5 flex items-center gap-2">
                            <i class="fas fa-layer-group text-[#800000]"></i>
                            Difficulty Tiers & Score Ceilings
                        </h4>
                        <div class="grid grid-cols-3 gap-2 text-center text-xs">
                            <div class="bg-white p-2.5 rounded-xl border border-slate-100 shadow-sm">
                                <span class="inline-block px-2 py-0.5 bg-slate-100 text-slate-600 font-bold rounded-md text-[10px] uppercase">Easy</span>
                                <div class="font-black outfit text-slate-800 text-base mt-1">Max 60</div>
                                <span class="text-[10px] text-slate-400 font-medium">0.60x Multiplier</span>
                            </div>
                            <div class="bg-white p-2.5 rounded-xl border border-slate-100 shadow-sm">
                                <span class="inline-block px-2 py-0.5 bg-blue-50 text-blue-600 font-bold rounded-md text-[10px] uppercase">Medium</span>
                                <div class="font-black outfit text-slate-800 text-base mt-1">Max 80</div>
                                <span class="text-[10px] text-slate-400 font-medium">0.80x Multiplier</span>
                            </div>
                            <div class="bg-white p-2.5 rounded-xl border border-amber-200 bg-amber-50/30 shadow-sm">
                                <span class="inline-block px-2 py-0.5 bg-amber-100 text-amber-700 font-bold rounded-md text-[10px] uppercase">Hard / Mock</span>
                                <div class="font-black outfit text-[#800000] text-base mt-1">Max 100</div>
                                <span class="text-[10px] text-amber-600 font-medium">1.00x Full Merit</span>
                            </div>
                        </div>
                        <p class="text-[11px] text-slate-500 font-medium mt-2 italic text-center">
                            To enter the 80–100 Top Tier, you must tackle Hard mocks and AI technical interviews.
                        </p>
                    </div>

                    <!-- Rules List -->
                    <div class="bg-slate-50 rounded-2xl p-3.5 border border-slate-100">
                        <h4 class="text-xs font-black text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                            <i class="fas fa-list-check text-blue-500"></i>
                            Bonus & Retention Rules
                        </h4>
                        <ul class="text-[12px] text-slate-600 space-y-2 font-medium">
                            <li class="flex items-start gap-2">
                                <span class="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-[9px] shrink-0 mt-0.5"><i class="fas fa-plus"></i></span>
                                <span><b>Consistency Bonus:</b> Earn up to <b>+5 bonus points</b> by taking regular assessments (diminishing curve to prevent farming).</span>
                            </li>
                            <li class="flex items-start gap-2">
                                <span class="w-4 h-4 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-[9px] shrink-0 mt-0.5"><i class="fas fa-briefcase"></i></span>
                                <span><b>Portfolio:</b> +2 pts per verified Skill (max 50) & +5 pts per verified Project (max 50).</span>
                            </li>
                            <li class="flex items-start gap-2">
                                <span class="w-4 h-4 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center text-[9px] shrink-0 mt-0.5"><i class="fas fa-hourglass-half"></i></span>
                                <span><b>Active Retention:</b> Active within 7 days = 100% score. Inactive >7 days gradually loses 10%/week. Taking any test immediately restores your standing!</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- TAB 2: EXAMPLES & CASE STUDIES -->
                <div id="info-tab-examples" class="space-y-3.5 hidden">
                    <!-- Example 1: Active Practicer -->
                    <div class="p-3.5 bg-emerald-50/70 rounded-2xl border border-emerald-100">
                        <div class="flex items-center justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <span class="w-6 h-6 rounded-lg bg-emerald-500 text-white flex items-center justify-center text-xs font-bold"><i class="fas fa-user-check"></i></span>
                                <h4 class="text-xs font-black text-emerald-950 uppercase tracking-wider">Rahul (Active Practicer)</h4>
                            </div>
                            <span class="text-xs font-black outfit text-emerald-800 px-2 py-0.5 bg-emerald-100 rounded-md">Score: 73.8 pts</span>
                        </div>
                        <p class="text-[11px] text-slate-600 leading-relaxed">
                            <b>Test History:</b> 3 Hard Tech mocks (95%, 90%, 85%) + 4 lower experimental practice attempts (40%, 50%, 60%, 45%).<br>
                            <b>Result:</b> Top 3 scores [95, 90, 85] are counted ($91.5$ Tech). The 4 low practice runs are <b>ignored</b>. Practice never hurt his score!
                        </p>
                    </div>

                    <!-- Example 2: Easy Spammer -->
                    <div class="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-100">
                        <div class="flex items-center justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <span class="w-6 h-6 rounded-lg bg-rose-500 text-white flex items-center justify-center text-xs font-bold"><i class="fas fa-ban"></i></span>
                                <h4 class="text-xs font-black text-rose-950 uppercase tracking-wider">Priya (Easy Test Spammer)</h4>
                            </div>
                            <span class="text-xs font-black outfit text-rose-800 px-2 py-0.5 bg-rose-100 rounded-md">Score: 49.9 pts</span>
                        </div>
                        <p class="text-[11px] text-slate-600 leading-relaxed">
                            <b>Test History:</b> 30 Easy quizzes completed with 100%.<br>
                            <b>Result:</b> Easy tests are capped at 60 max. Even with 30 tests, score cannot exceed <b>49.9 pts</b>. Gated from Top 10 until Hard mocks are tackled!
                        </p>
                    </div>

                    <!-- Example 3: Inactive Student -->
                    <div class="p-3.5 bg-amber-50/70 rounded-2xl border border-amber-100">
                        <div class="flex items-center justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <span class="w-6 h-6 rounded-lg bg-amber-500 text-white flex items-center justify-center text-xs font-bold"><i class="fas fa-clock-rotate-left"></i></span>
                                <h4 class="text-xs font-black text-amber-950 uppercase tracking-wider">Amit (1-Hit Inactive Student)</h4>
                            </div>
                            <span class="text-xs font-black outfit text-amber-800 px-2 py-0.5 bg-amber-100 rounded-md">Score: 20.2 pts</span>
                        </div>
                        <p class="text-[11px] text-slate-600 leading-relaxed">
                            <b>Test History:</b> 1 Hard mock (92%) taken 3 weeks ago, 0 Aptitude/HR, inactive for 21 days.<br>
                            <b>Result:</b> 1 attempt has provisional factor (0.85x) + 20% decay (2 weeks inactive past 7-day grace @ 10%/week). Drops to 20.2 pts. Cannot park at #1 without active practice.
                        </p>
                    </div>

                    <!-- Example 4: Top Performer -->
                    <div class="p-3.5 bg-purple-50/70 rounded-2xl border border-purple-100">
                        <div class="flex items-center justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <span class="w-6 h-6 rounded-lg bg-[#800000] text-white flex items-center justify-center text-xs font-bold"><i class="fas fa-award"></i></span>
                                <h4 class="text-xs font-black text-purple-950 uppercase tracking-wider">Ananya (Top Performer)</h4>
                            </div>
                            <span class="text-xs font-black outfit text-purple-800 px-2 py-0.5 bg-purple-100 rounded-md">Score: 84.6 pts</span>
                        </div>
                        <p class="text-[11px] text-slate-600 leading-relaxed">
                            <b>Test History:</b> 3+ Hard Tech, Aptitude & HR mocks + 15 verified skills + 6 verified projects + Active this week.<br>
                            <b>Result:</b> Balanced excellence across all 3 pillars + portfolio unlocks the elite 80–90+ rank band!
                        </p>
                    </div>

                    <!-- Comparison Table -->
                    <div class="overflow-x-auto rounded-xl border border-slate-200">
                        <table class="w-full text-left text-[11px]">
                            <thead class="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                                <tr>
                                    <th class="p-2">Student Scenario</th>
                                    <th class="p-2 text-center text-rose-600">Old System</th>
                                    <th class="p-2 text-center text-emerald-700">New System</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 text-slate-600 font-medium">
                                <tr>
                                    <td class="p-2 font-bold">Active Practicer (extra mocks)</td>
                                    <td class="p-2 text-center text-rose-600 font-bold">54.2 ❌ (dropped)</td>
                                    <td class="p-2 text-center text-emerald-700 font-bold">73.8 ✅ (safe)</td>
                                </tr>
                                <tr>
                                    <td class="p-2 font-bold">Spamming 30 Easy Tests</td>
                                    <td class="p-2 text-center text-rose-600 font-bold">85.0+ ❌ (inflated)</td>
                                    <td class="p-2 text-center text-emerald-700 font-bold">49.9 🔒 (capped)</td>
                                </tr>
                                <tr>
                                    <td class="p-2 font-bold">1-Hit Inactive (3 weeks ago)</td>
                                    <td class="p-2 text-center text-rose-600 font-bold">64.4 ❌ (stayed #1)</td>
                                    <td class="p-2 text-center text-emerald-700 font-bold">24.2 ⏳ (decayed)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <button onclick="closeInfoModal(event)" class="w-full bg-[#800000] text-white py-3.5 rounded-2xl font-black outfit text-sm hover:opacity-95 transition shadow-lg mt-1">
                    Got it, Let's Climb!
                </button>
            </div>
        </div>
    </div>

    <!-- Score Calculation Breakdown Modal -->
    <div id="breakdownModal" class="breakdown-modal-overlay" onclick="closeBreakdownModal(event)">
        <div class="breakdown-modal-window" onclick="event.stopPropagation()">
            <div class="breakdown-modal-header">
                <div>
                    <h3 id="breakdownName">Score Calculation Breakdown</h3>
                    <p id="breakdownMeta" style="font-size: 12px; color: #64748b; margin-top: 2px; font-weight: 500;"></p>
                </div>
                <button type="button" class="breakdown-modal-close-btn" onclick="closeBreakdownModal()">&times;</button>
            </div>
            <div class="breakdown-modal-body">
                <!-- 1. AI Assessment Pipeline -->
                <div class="calc-breakdown-card">
                    <div class="calc-card-title">
                        <span><i class="fas fa-robot text-blue-500 mr-1.5"></i> 1. AI Assessment Pipeline (70% Weight)</span>
                        <span id="aiPillarsAvg" class="text-blue-600 font-black"></span>
                    </div>
                    <div class="calc-row">
                        <span>Technical Assessment (45% weight)</span>
                        <span id="bdTech"></span>
                    </div>
                    <div class="calc-row">
                        <span>Aptitude Assessment (30% weight)</span>
                        <span id="bdApt"></span>
                    </div>
                    <div class="calc-row">
                        <span>HR &amp; Soft Skills (25% weight)</span>
                        <span id="bdHr"></span>
                    </div>
                    <div class="calc-subtotal-row">
                        <span id="aiSubtotalLabel">Weighted AI Base (Avg × 70%)</span>
                        <span id="aiBreakdown" class="text-blue-600 font-extrabold"></span>
                    </div>
                </div>

                <!-- 2. Portfolio Rigor -->
                <div class="calc-breakdown-card">
                    <div class="calc-card-title">
                        <span><i class="fas fa-briefcase text-emerald-500 mr-1.5"></i> 2. Portfolio Rigor (30% Weight)</span>
                        <span id="portRawTotal" class="text-emerald-600 font-black"></span>
                    </div>
                    <div class="calc-row">
                        <span>Verified Skills (+2 pts each, max 50)</span>
                        <span id="bdSkills"></span>
                    </div>
                    <div class="calc-row">
                        <span>Verified Projects (+5 pts each, max 50)</span>
                        <span id="bdProjects"></span>
                    </div>
                    <div class="calc-subtotal-row">
                        <span id="portSubtotalLabel">Weighted Portfolio (Score × 30%)</span>
                        <span id="portBreakdown" class="text-emerald-600 font-extrabold"></span>
                    </div>
                </div>

                <!-- 3. Dynamic Modifiers -->
                <div class="calc-breakdown-card" style="margin-bottom: 0;">
                    <div class="calc-card-title">
                        <span><i class="fas fa-sliders-h text-amber-500 mr-1.5"></i> 3. Dynamic Modifiers</span>
                    </div>
                    <div class="calc-row">
                        <span>Base Total (AI 70% + Portfolio 30%)</span>
                        <strong id="bdBaseTotal"></strong>
                    </div>
                    <div class="calc-row">
                        <span>Practice &amp; Consistency Bonus <i class="fas fa-bolt text-sky-500 text-[11px] ml-1"></i></span>
                        <span id="bdActivityBonus" class="text-sky-600 font-bold"></span>
                    </div>
                    <div class="calc-row">
                        <span>Inactivity Decay (Past 7-day grace period)</span>
                        <span id="bdInactivityDecay"></span>
                    </div>
                </div>

                <!-- Final Score Box -->
                <div class="calc-final-banner">
                    <div>
                        <div class="lbl">Final Weighted Total</div>
                        <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">Formula: (Base + Bonus) × (1 - Decay)</div>
                    </div>
                    <div class="val" id="totalBreakdown"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openInfoModal() {
            const modal = document.getElementById('info-modal');
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('open'), 10);
        }
        function closeInfoModal() {
            const modal = document.getElementById('info-modal');
            modal.classList.remove('open');
            setTimeout(() => modal.style.display = 'none', 400);
        }

        function switchInfoTab(tab) {
            const rulesTab = document.getElementById('info-tab-rules');
            const examplesTab = document.getElementById('info-tab-examples');
            const btnRules = document.getElementById('tab-btn-rules');
            const btnExamples = document.getElementById('tab-btn-examples');

            if (tab === 'rules') {
                rulesTab.classList.remove('hidden');
                examplesTab.classList.add('hidden');
                btnRules.className = 'flex-1 py-1.5 px-3 text-xs font-black outfit rounded-lg transition-all bg-white text-[#800000] shadow-sm';
                btnExamples.className = 'flex-1 py-1.5 px-3 text-xs font-black outfit rounded-lg transition-all text-slate-500 hover:text-slate-800';
            } else {
                rulesTab.classList.add('hidden');
                examplesTab.classList.remove('hidden');
                btnExamples.className = 'flex-1 py-1.5 px-3 text-xs font-black outfit rounded-lg transition-all bg-white text-[#800000] shadow-sm';
                btnRules.className = 'flex-1 py-1.5 px-3 text-xs font-black outfit rounded-lg transition-all text-slate-500 hover:text-slate-800';
            }
        }

        let currentView = 'local';
        let currentData = [];
        let myUsn = '<?php echo addslashes($myUsn); ?>'.toLowerCase();
        let myCanonicalUsn = '<?php echo addslashes($myCanonicalUsn); ?>'.toLowerCase();
        let myAadhar = '<?php echo addslashes($myAadhar); ?>'.toLowerCase();
        let selectedUsn = null;

        // Helper: returns true if a ranking entry belongs to the current student
        // Handles GMIT students who may have logged in via Aadhar
        function isMyEntry(s) {
            const usnLow = (s.usn || '').toLowerCase();
            const aadharLow = (s.aadhar || '').toLowerCase();
            if (usnLow === myUsn || usnLow === myCanonicalUsn) return true;
            if (myAadhar && (usnLow === myAadhar || aadharLow === myAadhar)) return true;
            if (myCanonicalUsn && aadharLow === myCanonicalUsn) return true;
            return false;
        }

        gsap.registerPlugin(Flip);

        /* ===== FETCH ===== */
        async function fetchRankings(showLoader = false) {
            const loader = document.getElementById('leaderboard-loader');
            if (showLoader) {
                loader.style.display = 'flex';
                gsap.to(loader, { opacity: 1, duration: 0.3 });
            }
            try {
                const res = await fetch(`leaderboard_handler.php`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `view=${currentView}`
                });
                const data = await res.json();
                if (data.success) {
                    updateLeaderboard(data.rankings);
                }
            } catch (err) {
                console.error("Failed to fetch rankings", err);
            } finally {
                if (showLoader) {
                    gsap.to(loader, { opacity: 0, duration: 0.3, delay: 0.5, onComplete: () => loader.style.display = 'none' });
                }
            }
        }

        /* ===== RENDER LEADERBOARD ===== */
        function updateLeaderboard(newList) {
            const listEl = document.getElementById('rankings-list');
            const stickyEl = document.getElementById('my-sticky-rank');

            const state = Flip.getState(".rank-row");
            checkRankChanges(newList);
            currentData = newList;

            if (newList.length === 0) {
                document.getElementById('podium-container').innerHTML = '';
                listEl.innerHTML = `<div class="p-12 text-center glass-card"><div class="w-16 h-16 mx-auto bg-slate-100 rounded-full flex items-center justify-center mb-4 text-slate-400 text-2xl"><i class="fas fa-ghost"></i></div><h3 class="text-lg font-bold text-slate-700">No Rankings Yet</h3><p class="text-sm text-slate-500 mt-1">No students have completed assessments for this view.</p></div>`;
                stickyEl.classList.add('hidden');
                return;
            }

            renderPodium(newList.slice(0, 3));

            const remaining = newList.slice(3, 20);
            listEl.innerHTML = remaining.map(s => renderStudentRow(s)).join('');

            // Animate
            Flip.from(state, {
                duration: 0.8, ease: "power2.inOut", stagger: 0.05,
                onEnter: els => gsap.fromTo(els, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6 }),
                onLeave: els => gsap.to(els, { opacity: 0, y: -20, duration: 0.6 })
            });

            // My sticky — show if student is outside the visible top 20
            const myData = newList.find(s => isMyEntry(s));
            if (myData) {
                document.getElementById('my-rank-badges').textContent = `#${myData.rank}`;
                document.getElementById('my-total-score').textContent = myData.total;
                // Show sticky bar when student is not in the visible rendered list (top 20)
                stickyEl.classList.toggle('hidden', myData.rank <= 20);
            } else {
                // Student not yet ranked — hide sticky
                stickyEl.classList.add('hidden');
            }
        }

        /* ===== RENDER STUDENT ROW ===== */
        function renderStudentRow(s) {
            const isMe = isMyEntry(s);
            const prevRank = parseInt(s.previous_rank) || s.rank;
            let rankIndicator = '';
            if (prevRank > s.rank) {
                rankIndicator = `<div class="flex items-center text-green-500 text-[10px] font-bold"><i class="fas fa-arrow-up mr-0.5 text-[8px]"></i>+${prevRank - s.rank}</div>`;
            } else if (prevRank < s.rank) {
                rankIndicator = `<div class="flex items-center text-red-400 text-[10px] font-bold"><i class="fas fa-arrow-down mr-0.5 text-[8px]"></i>-${s.rank - prevRank}</div>`;
            } else {
                rankIndicator = `<div class="text-slate-300 text-[10px] font-bold">–</div>`;
            }

            return `
                <div data-flip-id="${s.usn}" ${isMe ? `onclick="openInsight('${s.usn}')"` : ''}
                     class="rank-row glass-card p-4 md:px-7 md:py-5 flex md:grid md:grid-cols-12 items-center gap-4 ${isMe ? 'is-me ring-2 ring-[#800000] bg-red-50/30' : ''}">
                    <div class="col-span-1 pr-3 border-r border-slate-100">
                        <div class="flex flex-col items-center gap-1">
                            <span class="rank-badge ${s.rank <= 3 ? 'rank-' + s.rank : 'bg-slate-50 text-slate-400 border border-slate-200'}">${s.rank}</span>
                            ${rankIndicator}
                        </div>
                    </div>
                    <div class="col-span-8 flex items-center gap-4 pl-2">
                        <div class="w-11 h-11 rounded-xl avatar-circle flex-shrink-0 flex items-center justify-center text-base shadow overflow-hidden">
                            ${s.photo ? `<img src="${s.photo}" alt="${s.name}" class="w-full h-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">` : ''}
                            <span style="${s.photo ? 'display: none;' : ''}" class="flex items-center justify-center">${s.name.charAt(0).toUpperCase()}</span>
                        </div>
                        <div class="min-w-0">
                            <div class="font-bold text-slate-800 text-sm md:text-base flex items-center gap-2 flex-wrap">
                                ${s.name}
                                ${isMe ? '<span class="px-2 py-0.5 bg-[#800000] text-white text-[9px] rounded-full font-black uppercase tracking-wider">You</span>' : ''}
                                ${s.rank === 1 ? '<span class="crown-glow">👑</span>' : ''}
                            </div>
                            <div class="text-[11px] text-slate-400 uppercase tracking-wider font-semibold mt-0.5 truncate">${s.discipline} · ${s.institution}${s.sem ? ` · Sem ${s.sem}` : ''}</div>
                        </div>
                    </div>
                    <div class="col-span-3 text-right">
                        <div onclick="event.stopPropagation(); showScoreBreakdownByUsn('${s.usn}')" class="group inline-block cursor-pointer p-1.5 -mr-1.5 rounded-2xl hover:bg-slate-100/90 transition" title="Click to view detailed Score Breakdown">
                            <div class="text-2xl md:text-3xl font-black outfit text-slate-900 group-hover:text-[#800000] transition flex items-center justify-end gap-1.5">
                                ${s.total}
                                <i class="fas fa-calculator text-xs text-slate-300 group-hover:text-[#800000] transition"></i>
                            </div>
                            <div class="text-[10px] text-[#800000] font-black uppercase tracking-widest flex items-center justify-end gap-1">
                                Total Points <i class="fas fa-circle-info text-[9px] opacity-60"></i>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        /* ===== RENDER PODIUM ===== */
        function renderPodium(top3) {
            const podiumEl = document.getElementById('podium-container');
            if (top3.length === 0) {
                podiumEl.innerHTML = '';
                return;
            }

            // Order for podium: [2nd, 1st, 3rd]
            const podiumOrder = [];
            if (top3[1]) podiumOrder.push(top3[1]); // 2nd
            if (top3[0]) podiumOrder.push(top3[0]); // 1st
            if (top3[2]) podiumOrder.push(top3[2]); // 3rd

            podiumEl.innerHTML = podiumOrder.map(s => {
                const rankNum = s.rank;
                const isWinner = rankNum === 1;
                const badgeClass = rankNum === 1 ? 'rank-1' : (rankNum === 2 ? 'rank-2' : 'rank-3');
                const isMe = isMyEntry(s);

                return `
                    <div class="podium-step step-${rankNum}" data-rank="${rankNum}">
                        <div ${isMe ? `onclick="openInsight('${s.usn}')"` : ''}
                             class="podium-card glass-card p-6 md:p-8 rounded-[40px] text-center relative ${isWinner ? 'winner' : 'opacity-95'} ${isMe ? 'is-me ring-2 ring-[#800000]' : ''}">
                            
                            ${isWinner ? '<div class="absolute -top-6 left-1/2 -translate-x-1/2 bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600 text-white px-6 py-2 rounded-full text-[11px] font-black uppercase tracking-[0.2em] shadow-[0_10px_30px_rgba(212,175,55,0.4)] ring-4 ring-white whitespace-nowrap z-20">CHAMPION <i class="fas fa-fire ml-1"></i></div>' : ''}

                            <div class="relative w-20 h-20 mx-auto mb-6">
                                <div class="absolute inset-0 rounded-2xl rotate-6 bg-slate-100 scale-125 opacity-40"></div>
                                <div class="relative w-full h-full rounded-3xl avatar-circle flex items-center justify-center text-3xl font-black outfit shadow-2xl border-2 border-white/50 overflow-hidden">
                                    ${s.photo ? `<img src="${s.photo}" alt="${s.name}" class="w-full h-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">` : ''}
                                    <span style="${s.photo ? 'display: none;' : ''}" class="flex items-center justify-center">${s.name.charAt(0).toUpperCase()}</span>
                                </div>
                                <div class="absolute -bottom-2 -right-2 w-10 h-10 ${badgeClass} rounded-2xl flex items-center justify-center text-sm font-black border-4 border-white shadow-xl ring-2 ring-black/5">
                                    ${rankNum}
                                </div>
                            </div>

                            <div class="font-black text-slate-800 text-lg md:text-xl outfit mb-1 truncate px-2">${s.name}</div>
                            <div class="text-[10px] text-slate-400 mb-6 truncate uppercase font-extrabold tracking-[0.15em] opacity-80">${s.discipline}${s.sem ? ` · Sem ${s.sem}` : ''}</div>

                            <div onclick="event.stopPropagation(); showScoreBreakdownByUsn('${s.usn}')" class="p-5 rounded-[28px] bg-gradient-to-br from-white to-slate-50/50 border border-slate-100 shadow-inner cursor-pointer hover:shadow-md hover:border-amber-300 transition group" title="Click to view detailed Score Breakdown">
                                <div class="text-4xl font-black outfit text-slate-900 tracking-tighter group-hover:text-[#800000] transition flex items-center justify-center gap-1.5">
                                    ${s.total}
                                    <i class="fas fa-calculator text-sm text-slate-300 group-hover:text-[#800000] transition opacity-60 group-hover:opacity-100"></i>
                                </div>
                                <div class="text-[10px] text-[#D4AF37] font-black uppercase tracking-[0.25em] mt-1.5 opacity-90 flex items-center justify-center gap-1">
                                    ${currentView === 'local' ? 'DEPT POINTS' : 'GLOBAL POINTS'} <i class="fas fa-circle-info text-[9px]"></i>
                                </div>
                            </div>
                        </div>
                        <div class="podium-base rounded-t-3xl shadow-2xl">
                            ${rankNum}
                        </div>
                    </div>
                `;
            }).join('');

            // GSAP Entrance
            gsap.from(".podium-step", {
                y: 100,
                opacity: 0,
                duration: 1,
                stagger: 0.15,
                ease: "back.out(1.7)",
                delay: 0.2
            });
            
            // Winning card extra pop
            gsap.to(".step-1 .podium-card", {
                scale: 1.05,
                duration: 0.8,
                delay: 1.2,
                ease: "elastic.out(1, 0.5)"
            });
        }

        function openInsight(usn) {
            if (!isMyEntry({usn: usn, aadhar: ''})) return;
            const student = currentData.find(s => s.usn.toLowerCase() === usn.toLowerCase());
            if (!student) return;

            selectedUsn = usn;

            // Highlight selected
            document.querySelectorAll('.rank-row, .podium-card').forEach(el => el.classList.remove('selected'));
            document.querySelectorAll(`[data-flip-id="${usn}"]`).forEach(el => el.classList.add('selected'));

            const leader = currentData[0];
            const gapFromTop = leader ? (parseFloat(leader.total) - parseFloat(student.total)).toFixed(1) : 0;
            const isMe = isMyEntry({usn: usn, aadhar: ''});
            const isFirst = student.rank === 1;
            const prevRank = parseInt(student.previous_rank) || student.rank;
            const rankChange = prevRank - student.rank;

            // Header
            const drawerAvatarEl = document.getElementById('drawer-avatar');
            drawerAvatarEl.innerHTML = student.photo 
                ? `<img src="${student.photo}" alt="${student.name}" class="w-full h-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">` 
                : '';
            const fallbackSpan = document.createElement('span');
            fallbackSpan.style.display = student.photo ? 'none' : 'flex';
            fallbackSpan.className = 'flex items-center justify-center';
            fallbackSpan.textContent = student.name.charAt(0).toUpperCase();
            drawerAvatarEl.appendChild(fallbackSpan);
            document.getElementById('drawer-name').textContent = student.name;
            document.getElementById('drawer-dept').textContent = `${student.discipline} · ${student.institution}${student.sem ? ` · Sem ${student.sem}` : ''}`;
            document.getElementById('drawer-score').textContent = student.total;
            document.getElementById('drawer-rank').textContent = `#${student.rank}`;

            const rankChangeEl = document.getElementById('drawer-rank-change');
            if (rankChange > 0) { rankChangeEl.textContent = `▲${rankChange}`; rankChangeEl.style.color = '#2ecc71'; }
            else if (rankChange < 0) { rankChangeEl.textContent = `▼${Math.abs(rankChange)}`; rankChangeEl.style.color = '#e74c3c'; }
            else { rankChangeEl.textContent = '—'; rankChangeEl.style.color = 'rgba(255,255,255,0.6)'; }

            // Gap bar
            const gapSection = document.getElementById('gap-section');
            const gapBarFill = document.getElementById('gap-bar-fill');
            gapBarFill.style.width = '0%'; // reset before animating
            if (!isFirst) {
                gapSection.classList.remove('hidden');
                const topScore = parseFloat(leader.total);
                const myScore = parseFloat(student.total);
                const pct = Math.min(100, Math.round((myScore / topScore) * 100));
                document.getElementById('gap-label').textContent = `${gapFromTop} pts behind #1`;
                const pronoun = isMe ? 'You are' : `${student.name.split(' ')[0]} is`;
                document.getElementById('gap-desc').textContent = `${pronoun} at ${pct}% of the top performer's score.`;
                setTimeout(() => { gapBarFill.style.width = pct + '%'; }, 150);
            } else {
                gapSection.classList.add('hidden');
            }

            // Motivation
            const motivationBlock = document.getElementById('motivation-block');
            const rival = currentData.find(s => s.rank == student.rank + 1);
            const {icon, title, text, bg, border} = getMotivation(student, isMe, rival);
            document.getElementById('motivation-icon').textContent = icon;
            document.getElementById('motivation-title').textContent = title;
            document.getElementById('motivation-text').textContent = text;
            motivationBlock.style.background = bg;
            motivationBlock.style.borderColor = border;

            // Suggestions
            const suggestions = getSuggestions(student, leader, isMe);
            document.getElementById('suggestions-list').innerHTML = suggestions.map((s, i) => `
                <div class="suggestion-item" style="animation-delay: ${i * 0.08}s">
                    <div class="suggestion-icon" style="background:${s.bg}">${s.icon}</div>
                    <div>
                        <div class="text-sm font-bold text-slate-800">${s.title}</div>
                        <div class="text-xs text-slate-500 mt-0.5 leading-relaxed">${s.desc}</div>
                    </div>
                </div>
            `).join('');

            // Open
            document.getElementById('insight-drawer').classList.add('open');
            document.getElementById('insight-overlay').classList.add('open');
        }

        function openMyInsight() {
            if (myUsn || myCanonicalUsn) {
                const myEntry = currentData.find(s => isMyEntry(s));
                if (myEntry) openInsight(myEntry.usn);
            }
        }

        function closeDrawer() {
            document.getElementById('insight-drawer').classList.remove('open');
            document.getElementById('insight-overlay').classList.remove('open');
            document.querySelectorAll('.rank-row, .podium-card').forEach(el => el.classList.remove('selected'));
            selectedUsn = null;
        }

        /* ===== MOTIVATION CONTENT ===== */
        function getMotivation(student, isMe, rival = null) {
            const rank = student.rank;
            const rivalName = rival ? rival.name.split(' ')[0] : 'others';
            const rivalWarning = rival ? `Be careful, ${rivalName} at #${rival.rank} is catching up fast!` : `Keep pushing to stay ahead of the competition!`;

            if (rank === 1) {
                return {
                    icon: '👑',
                    title: 'The Undisputed Champion!',
                    text: `You are at the top of the leaderboard! But stay sharp — ${rivalWarning} Top contenders are gaining momentum and can easily overtake you if you pause.`,
                    bg: '#fffbeb', border: '#D4AF37'
                };
            } else if (rank === 2) {
                return {
                    icon: '🔥',
                    title: `So Close — #1 is Within Reach!`,
                    text: `You're just one spot away from the top. ${rivalWarning} A focused push on your weakest assessment area can bridge the gap to #1 fast while keeping your lead on #3.`,
                    bg: '#fff7f0', border: '#ff8400'
                };
            } else if (rank === 3) {
                return {
                    icon: '⚡',
                    title: `On the Podium — Keep Fighting!`,
                    text: `You're in the elite top 3! But remember, ${rivalWarning} Sharpen your technical performance to surge toward #1 while securing your podium spot.`,
                    bg: '#fdf4f4', border: '#e67e22'
                };
            } else if (rank <= 10) {
                return {
                    icon: '🚀',
                    title: 'Top 10 — Elite Territory!',
                    text: `You're in the top 10 — that is elite! However, ${rivalWarning} A consistent streak of AI assessments will help you climb into the top 3 and defend your position.`,
                    bg: '#f0fdf4', border: '#86efac'
                };
            } else {
                return {
                    icon: '💡',
                    title: 'Huge Potential — Start the Climb!',
                    text: `Every champion started where you're standing. ${rivalWarning} Complete pending AI assessments and add skills to your portfolio to jump many ranks at once!`,
                    bg: '#f0f9ff', border: '#7dd3fc'
                };
            }
        }

        /* ===== SUGGESTIONS ===== */
        function getSuggestions(student, leader, isMe) {
            const rank = student.rank;
            const gap = leader ? (parseFloat(leader.total) - parseFloat(student.total)).toFixed(1) : 0;

            if (rank === 1) {
                return [
                    { icon: '🧠', bg: '#fff8e1', title: 'Push for a Perfect Score', desc: 'Retake low-scoring AI assessments (Aptitude, Technical) to maximise your total beyond the current ceiling.' },
                    { icon: '🗂️', bg: '#fff0f0', title: 'Add 2+ Verified Portfolio Projects', desc: 'Verified projects with real GitHub links significantly boost your Architect score and widen the gap from rank #2.' },
                    { icon: '🏅', bg: '#f0fff4', title: 'Earn New Certifications', desc: 'Platform certifications add directly to your portfolio points. Target AWS, Google or industry-recognised badges.' },
                    { icon: '🎯', bg: '#f5f3ff', title: 'Complete the Mock AI Interview', desc: 'Full completion of all pillars ensures you hold the highest possible score across the board. Leave no stone unturned.' },
                    { icon: '📣', bg: '#fdf4ff', title: 'Inspire the cohort', desc: 'Being #1 puts you in the spotlight. Share your strategies — your leadership reputation is part of your elite personal brand.' },
                ];
            } else if (rank === 2) {
                return [
                    { icon: '⚔️', bg: '#fff8e1', title: `Close the ${gap}-pt Gap Fast`, desc: 'Identify which assessment pillars the top student outscores you on and focus your next study sessions there.' },
                    { icon: '📋', bg: '#fff0f0', title: 'Complete All Pending Assessments', desc: 'Unattempted assessments are guaranteed lost points. Each completed pillar adds directly to your total.' },
                    { icon: '🔬', bg: '#f0fff4', title: 'Boost Skill Verification Score', desc: 'Request re-verification of your top skills for a higher proficiency rating — this directly impacts portfolio points.' },
                    { icon: '💼', bg: '#f0f9ff', title: 'Add a High-Impact Project', desc: 'A well-documented, verified project with live links can earn substantial bonus portfolio points above rank #1.' },
                    { icon: '⚡', bg: '#fdf4ff', title: 'Retake the Aptitude or Technical Test', desc: 'Even a small 3–5 point improvement in any assessment can push you past the current leader.' },
                ];
            } else if (rank === 3) {
                return [
                    { icon: '🔝', bg: '#fff8e1', title: `Only ${gap} Points Behind #1`, desc: 'This gap is beatable in a single assessment round. Prioritise completing and optimising your weakest area today.' },
                    { icon: '📂', bg: '#fff0f0', title: 'Complete Your Portfolio', desc: 'Adding skills, projects and certifications that are still missing from your profile can yield immediate rank jumps.' },
                    { icon: '🤖', bg: '#f0fff4', title: 'Full AI Assessment Completion', desc: 'Ensure every Lakshya AI module is completed — Aptitude, HR, Technical, Skill Verification and Project Viva.' },
                    { icon: '🛠️', bg: '#f0f9ff', title: 'Improve Project Quality', desc: 'Update your existing projects with better descriptions, GitHub links and verified tech stacks for higher scores.' },
                ];
            } else if (rank <= 10) {
                return [
                    { icon: '📊', bg: '#fff8e1', title: 'Complete All AI Assessments', desc: 'Unattempted modules are free points on the table. Complete every available assessment to close the gap.' },
                    { icon: '📁', bg: '#fff0f0', title: 'Expand Your Portfolio', desc: 'Add at least 3 verified skills and 2 projects. Portfolio completeness is one of the highest-weighted scoring factors.' },
                    { icon: '🎓', bg: '#f0fff4', title: 'Add Industry Certifications', desc: 'Each verified certification boosts your portfolio section significantly and shows real-world credibility.' },
                    { icon: '🔄', bg: '#f0f9ff', title: 'Retake Your Lowest Assessment', desc: 'Review the feedback from your lowest-scoring round and retake to improve your pillar average.' },
                ];
            } else {
                return [
                    { icon: '🚀', bg: '#fff8e1', title: 'Start With Aptitude Assessment', desc: 'The Aptitude module is the fastest path to earning your first significant points. Complete it this week.' },
                    { icon: '📝', bg: '#fff0f0', title: 'Build Your Portfolio from Scratch', desc: 'Add at least 5 skills and 1 project to your portfolio. These are instant, high-value points available right now.' },
                    { icon: '💬', bg: '#f0fff4', title: 'Complete HR & Communication Round', desc: 'This round rewards communication and confidence. It is often overlooked — completing it gives an immediate rank boost.' },
                    { icon: '🔗', bg: '#f0f9ff', title: 'Link GitHub to Your Projects', desc: 'Verified GitHub links on your projects significantly increase your portfolio\'s assessed quality score.' },
                    { icon: '📅', bg: '#fdf4ff', title: 'Set a 7-Day Challenge', desc: 'Commit to completing one Lakshya module per day for a week. Consistent action is the fastest route to the top.' },
                ];
            }
        }

        /* ===== QUICK STATS ===== */
        function getQuickStats(student, leader, totalStudents) {
            const percentile = Math.round(((totalStudents - student.rank) / totalStudents) * 100);
            const gap = leader ? (parseFloat(leader.total) - parseFloat(student.total)).toFixed(1) : '—';
            const rankChange = (parseInt(student.previous_rank) || student.rank) - student.rank;

            return `
                <div class="stat-chip">
                    <div class="text-xl font-black outfit text-[#800000]">${percentile}%</div>
                    <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Percentile</div>
                </div>
                <div class="stat-chip">
                    <div class="text-xl font-black outfit text-[#800000]">${gap === '—' || gap == 0 ? '—' : gap + ' pts'}</div>
                    <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Gap from #1</div>
                </div>
                <div class="stat-chip">
                    <div class="text-xl font-black outfit ${rankChange > 0 ? 'text-green-500' : rankChange < 0 ? 'text-red-400' : 'text-slate-400'}">${rankChange > 0 ? '▲' + rankChange : rankChange < 0 ? '▼' + Math.abs(rankChange) : '—'}</div>
                    <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Rank Δ</div>
                </div>
                <div class="stat-chip">
                    <div class="text-xl font-black outfit text-[#800000]">#${student.rank}</div>
                    <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Current Rank</div>
                </div>
            `;
        }

        /* ===== RANK CHANGE CELEBRATION ===== */
        function checkRankChanges(newList) {
            if (currentData.length === 0) return;
            const oldMe = currentData.find(s => isMyEntry(s));
            const newMe = newList.find(s => isMyEntry(s));
            if (oldMe && newMe && oldMe.rank !== newMe.rank && newMe.rank <= 10 && oldMe.rank > 10) {
                triggerCelebration();
            }
        }

        function triggerCelebration() {
            const overlay = document.getElementById('celebration-overlay');
            overlay.style.display = 'flex';
            gsap.fromTo(overlay, { opacity: 0 }, { opacity: 1, duration: 0.5 });
            setTimeout(() => gsap.to(overlay, { opacity: 0, duration: 1, onComplete: () => overlay.style.display = 'none' }), 4000);
        }

        /* ===== VIEW TOGGLE ===== */
        function changeView(view) {
            currentView = view;
            document.querySelectorAll('.view-btn').forEach(b => {
                b.classList.remove('active');
                if (!b.classList.contains('active')) b.classList.add('text-slate-500');
            });
            const activeBtn = document.getElementById(view === 'local' ? 'btn-local' : 'btn-global');
            activeBtn.classList.remove('text-slate-500');
            activeBtn.classList.add('active');
            closeDrawer();
            fetchRankings(true);
        }

        /* ===== SCORE BREAKDOWN MODAL ===== */
        function showScoreBreakdown(data) {
            document.getElementById('breakdownName').innerText = "Score Breakdown: " + data.name;
            document.getElementById('breakdownMeta').innerText = (data.discipline || '') + (data.sem ? ' • Semester ' + data.sem : '');
            
            // AI Assessments
            const techWeighted = (data.tech * 0.45).toFixed(1);
            const aptWeighted = (data.apt * 0.30).toFixed(1);
            const hrWeighted = (data.hr * 0.25).toFixed(1);
            
            document.getElementById('bdTech').innerHTML = `<strong>${data.tech}%</strong> <span style="color:#94a3b8; font-size:11px;">(${techWeighted} pts)</span>`;
            document.getElementById('bdApt').innerHTML = `<strong>${data.apt}%</strong> <span style="color:#94a3b8; font-size:11px;">(${aptWeighted} pts)</span>`;
            document.getElementById('bdHr').innerHTML = `<strong>${data.hr}%</strong> <span style="color:#94a3b8; font-size:11px;">(${hrWeighted} pts)</span>`;
            document.getElementById('aiPillarsAvg').innerText = `${data.ai_avg} / 100`;
            document.getElementById('aiSubtotalLabel').innerText = `Weighted AI Base (${data.ai_avg} × 70%)`;
            document.getElementById('aiBreakdown').innerText = `+${data.ai_pts} pts`;
            
            // Portfolio
            const skillsPts = Math.min(50, (data.port_skills || 0) * 2);
            const projPts = Math.min(50, (data.port_projects || 0) * 5);
            document.getElementById('bdSkills').innerHTML = `<strong>${data.port_skills || 0}</strong> verified <span style="color:#94a3b8; font-size:11px;">(${skillsPts} pts)</span>`;
            document.getElementById('bdProjects').innerHTML = `<strong>${data.port_projects || 0}</strong> verified <span style="color:#94a3b8; font-size:11px;">(${projPts} pts)</span>`;
            document.getElementById('portRawTotal').innerText = `${data.port_raw} / 100`;
            document.getElementById('portSubtotalLabel').innerText = `Weighted Portfolio (${data.port_raw} × 30%)`;
            document.getElementById('portBreakdown').innerText = `+${data.port_pts} pts`;
            
            // Modifiers
            document.getElementById('bdBaseTotal').innerText = `${data.base_total} pts`;
            document.getElementById('bdActivityBonus').innerText = data.activity_bonus > 0 ? `+${data.activity_bonus} pts (${data.attempts} attempts)` : `+0.0 pts (${data.attempts} attempts)`;
            document.getElementById('bdInactivityDecay').innerHTML = data.inactivity_decay > 0 
                ? `<span style="color:#ef4444; font-weight:700;">-${data.inactivity_decay}%</span>` 
                : `<span style="color:#10b981; font-weight:700;">0% (Active)</span>`;
            
            // Total
            document.getElementById('totalBreakdown').innerText = data.total;
            
            const modal = document.getElementById('breakdownModal');
            if (modal) {
                modal.style.display = 'flex';
            }
        }

        function showScoreBreakdownByUsn(usn) {
            if (!usn || !currentData) return;
            const s = currentData.find(item => 
                (item.usn && item.usn.toLowerCase() === usn.toLowerCase()) || 
                (item.aadhar && item.aadhar.toLowerCase() === usn.toLowerCase())
            );
            if (!s) return;
            
            const techWeighted = (parseFloat(s.technical || 0) * 0.45).toFixed(1);
            const aptWeighted = (parseFloat(s.aptitude || 0) * 0.30).toFixed(1);
            const hrWeighted = (parseFloat(s.hr || 0) * 0.25).toFixed(1);
            const aiAvg = parseFloat(s.ai_avg || 0).toFixed(1);
            const aiPts = (parseFloat(s.ai_avg || 0) * 0.7).toFixed(1);
            
            const portSkills = s.skills_count !== undefined ? s.skills_count : (s.skills ? s.skills.length : 0);
            const portProjects = s.projects_count !== undefined ? s.projects_count : 0;
            const portRaw = s.portfolio !== undefined ? s.portfolio : Math.min(100, (portSkills * 2) + (portProjects * 5));
            const portPts = (portRaw * 0.3).toFixed(1);
            
            const baseTotal = s.base_total !== undefined ? s.base_total : (parseFloat(aiPts) + parseFloat(portPts)).toFixed(1);
            const attempts = s.total_attempts !== undefined ? s.total_attempts : (s.ai_count || 0);
            const activityBonus = s.activity_bonus !== undefined ? s.activity_bonus : 0;
            const inactivityDecay = s.inactivity_decay_pct !== undefined ? s.inactivity_decay_pct : 0;
            
            const data = {
                name: s.name,
                discipline: s.discipline,
                sem: s.sem,
                apt: Math.round(s.aptitude * 10) / 10,
                tech: Math.round(s.technical * 10) / 10,
                hr: Math.round(s.hr * 10) / 10,
                ai_avg: aiAvg,
                ai_pts: aiPts,
                port_raw: portRaw,
                port_skills: portSkills,
                port_projects: portProjects,
                port_pts: portPts,
                base_total: baseTotal,
                attempts: attempts,
                activity_bonus: activityBonus,
                inactivity_decay: inactivityDecay,
                total: s.total
            };
            showScoreBreakdown(data);
        }

        function showMyScoreBreakdown() {
            const myEntry = currentData.find(s => isMyEntry(s));
            if (myEntry) {
                showScoreBreakdownByUsn(myEntry.usn);
            }
        }

        function closeBreakdownModal() {
            const modal = document.getElementById('breakdownModal');
            if (modal) {
                modal.style.display = 'none';
            }
        }

        // Keyboard ESC to close drawer & breakdown modal
        document.addEventListener('keydown', e => { 
            if (e.key === 'Escape') {
                closeDrawer();
                closeBreakdownModal();
            }
        });

        // Init
        fetchRankings();
        setInterval(fetchRankings, 30000);
    </script>
    <?php renderFeatureAnnouncement('feature_leaderboard'); ?>
</body>
</html>

