<?php
/**
 * NQT HR Round Handler
 * Manages NQT behavioral interview sessions.
 */

require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../../src/Services/AIService.php';
require_once __DIR__ . '/../../src/Models/StudentProfile.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

set_time_limit(300);

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$input = array_merge($input, $_POST);
$action = $input['action'] ?? '';

requireLogin();
$userId = getUserId();
$studentIdForDb = getStudentIdForAssessment();

$db = getDB();
$ai = new AIService();
$studentModel = new StudentProfile();

switch ($action) {
    case 'start_session':
        $profile = $studentModel->getByUserId($userId);
        
        // Fetch projects for context
        require_once __DIR__ . '/../../src/Models/Portfolio.php';
        $portfolioModel = new Portfolio();
        $portfolio = $portfolioModel->getStudentPortfolio($userId, getInstitution());
        
        $projects = [];
        foreach ($portfolio as $item) {
            if ($item['category'] === 'Project') {
                $projects[] = [
                    'title' => $item['title'],
                    'description' => $item['description'] ?? '',
                    'tech_stack' => $item['sub_title'] ?? '',
                    'link' => $item['link'] ?? ''
                ];
            }
        }
        
        $sql = "INSERT INTO unified_ai_assessments (
            student_id, institution, student_name, usn, branch, current_sem, assessment_type, company_name, status, details, started_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'NQT HR', 'TCS NQT Practice', 'active', ?, CURRENT_TIMESTAMP)";

        $stmt = $db->prepare($sql);
        $stmt->execute([
            $studentIdForDb,
            getInstitution(),
            $profile['name'] ?? getFullName(),
            $profile['usn'] ?? getUsername(),
            $profile['department'] ?? null,
            $profile['semester'] ?? null,
            json_encode([
                'role' => 'TCS Graduate Candidate', 
                'history' => [],
                'projects' => $projects,
                'task_id' => $input['task_id'] ?? null
            ])
        ]);

        echo json_encode(['success' => true, 'session_id' => $db->lastInsertId()]);
        break;

    case 'get_question':
        $sessionId = (int)($input['session_id'] ?? 0);
        $userMessage = $input['message'] ?? '';
        
        // Only the student who owns the session may continue it
        $stmt = $db->prepare("SELECT * FROM unified_ai_assessments WHERE id = ? AND student_id = ? AND assessment_type = 'NQT HR'");
        $stmt->execute([$sessionId, $studentIdForDb]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$session) {
            echo json_encode(['success' => false, 'message' => 'Session not found']);
            exit;
        }
        $details = json_decode($session['details'], true);
        $history = $details['history'] ?? [];
        $projects = $details['projects'] ?? [];

        if (!empty($userMessage)) {
            $history[] = ['role' => 'user', 'content' => $userMessage];
        } else if (count($history) > 0) {
            $history[] = ['role' => 'user', 'content' => '[No response / skipped]'];
        }

        // Fetch previously asked questions for this student to prevent repetition
        $previousQuestions = [];
        $extractQuestions = function ($historyArr) {
            $questions = [];
            if (!is_array($historyArr))
                return $questions;
            foreach ($historyArr as $msg) {
                if (($msg['role'] ?? '') === 'assistant') {
                    $content = $msg['content'] ?? '';
                    $parsed = @json_decode($content, true);
                    if ($parsed && !empty($parsed['question'])) {
                        $questions[] = $parsed['question'];
                    } elseif (!empty(trim($content))) {
                        $questions[] = trim($content);
                    }
                }
            }
            return $questions;
        };

        $previousQuestions = array_merge($previousQuestions, $extractQuestions($history));

        $stmtPrev = $db->prepare("SELECT details FROM unified_ai_assessments WHERE student_id = ? AND assessment_type = 'NQT HR' AND id != ? ORDER BY started_at DESC LIMIT 5");
        $stmtPrev->execute([$studentIdForDb, $sessionId]);
        while ($row = $stmtPrev->fetch(PDO::FETCH_ASSOC)) {
            $det = json_decode($row['details'], true);
            if (!empty($det['history'])) {
                $previousQuestions = array_merge($previousQuestions, $extractQuestions($det['history']));
            }
        }
        $previousQuestions = array_values(array_unique($previousQuestions));

        session_write_close();
        $response = $ai->getHRQuestion('TCS NQT Candidate', $history, $projects, null, $previousQuestions);
        
        if ($response['success']) {
            $aiData = $response['result'];
            $cleanQuestion = $aiData['question'] ?? '';
            $history[] = ['role' => 'assistant', 'content' => $cleanQuestion];
            
            $details['history'] = $history;
            $db->prepare("UPDATE unified_ai_assessments SET details = ? WHERE id = ? AND student_id = ?")
               ->execute([json_encode($details), $sessionId, $studentIdForDb]);

            echo json_encode(['success' => true, 'data' => $aiData]);
        } else {
            echo json_encode(['success' => false, 'message' => 'AI failed']);
        }
        break;

    case 'submit_interview':
        $sessionId = (int)($input['session_id'] ?? 0);
        $telemetry = isset($input['telemetry']) ? json_decode($input['telemetry'], true) : null;
        
        $stmt = $db->prepare("SELECT details FROM unified_ai_assessments WHERE id = ? AND student_id = ?");
        $stmt->execute([$sessionId, $studentIdForDb]);
        $rawDetails = $stmt->fetchColumn();
        if ($rawDetails === false) {
            echo json_encode(['success' => false, 'message' => 'Session not found']);
            exit;
        }
        $details = json_decode($rawDetails ?: '{}', true) ?: [];
        if ($telemetry) {
            $details['telemetry'] = $telemetry;
        }
        
        $db->prepare("UPDATE unified_ai_assessments SET status = 'completed', completed_at = NOW(), details = ? WHERE id = ? AND student_id = ?")
           ->execute([json_encode($details), $sessionId, $studentIdForDb]);
        echo json_encode(['success' => true]);
        break;

    case 'generate_report_data':
        $sessionId = $input['session_id'] ?? 0;
        
        $stmt = $db->prepare("SELECT * FROM unified_ai_assessments WHERE id = ? AND student_id = ?");
        $stmt->execute([$sessionId, $studentIdForDb]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$session) {
            echo json_encode(['success' => false, 'message' => 'Session not found']);
            exit;
        }

        $details = json_decode($session['details'], true);
        $role = $details['role'] ?? 'Candidate';
        $history = $details['history'] ?? [];

        // STRICT SCORING: Count actual user contributions
        $userMessages = 0;
        foreach ($history as $msg) {
            if ($msg['role'] === 'user' && strlen(trim($msg['content'])) > 5) {
                $userMessages++;
            }
        }

        // Generate Text Report via AI
        session_write_close();
        $reportRes = $ai->generateHRReport($role, $history);
        
        if ($reportRes['success']) {
            $reportText = $reportRes['content'];
            $aiScore = $reportRes['overall_score'] ?? 0;

            // Enforcement: If less than 3 meaningful responses, score is 0.
            $performanceScore = $userMessages >= 3 ? $aiScore : 0;

            // Generate HTML for the PDF
            $html = generateReportHTML($session['usn'], $session['current_sem'] ?? 'N/A', $session['student_name'], "Behavioral Assessment (HR)", $performanceScore, $reportText);
            $filename = "{$session['usn']}_NQT_HR_" . ($session['current_sem'] ?? 'Sem') . ".pdf";

            // Update DB with Final Strict Score
            $db->prepare("UPDATE unified_ai_assessments SET score = ?, feedback = ? WHERE id = ?")
               ->execute([$performanceScore, "HR Report Generated", $sessionId]);

            echo json_encode(['success' => true, 'report_html' => $html, 'filename' => $filename]);
        } else {
            $errorMsg = $reportRes['message'] ?? 'AI Report Synthesis failed';
            echo json_encode(['success' => false, 'message' => "Report generation failed: " . $errorMsg]);
        }
        break;

    case 'save_pdf_report':
        $sessionId = (int)($_POST['session_id'] ?? 0);

        // Ownership check before accepting any file for this session
        $stmt = $db->prepare("SELECT details, usn, current_sem FROM unified_ai_assessments WHERE id = ? AND student_id = ?");
        $stmt->execute([$sessionId, $studentIdForDb]);
        $sessionRow = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$sessionRow) {
            echo json_encode(['success' => false, 'message' => 'Session not found']);
            exit;
        }
        
        if (isset($_FILES['pdf']) && $_FILES['pdf']['error'] === UPLOAD_ERR_OK) {
            // Must really be a PDF — the client-supplied name/extension was trusted before,
            // which allowed uploading e.g. a .php file into a web-served folder
            $header = (string)@file_get_contents($_FILES['pdf']['tmp_name'], false, null, 0, 5);
            if ($header !== '%PDF-') {
                echo json_encode(['success' => false, 'message' => 'Invalid report file']);
                exit;
            }

            $dir = REPORTS_UPLOAD_PATH . '/hr/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            
            // Server-chosen name, unique per session, so students can't overwrite each other's reports
            $safeUsn = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($sessionRow['usn'] ?? 'student'));
            $safeSem = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($sessionRow['current_sem'] ?? 'Sem'));
            $filename = "{$safeUsn}_NQT_HR_{$safeSem}_{$sessionId}.pdf";
            $targetPath = $dir . $filename;
            
            if (move_uploaded_file($_FILES['pdf']['tmp_name'], $targetPath)) {
                $publicPath = "uploads/reports/hr/" . $filename;
                
                $details = json_decode($sessionRow['details'] ?? '{}', true) ?: [];
                $details['report_path'] = $publicPath;
                
                $db->prepare("UPDATE unified_ai_assessments SET details = ? WHERE id = ? AND student_id = ?")
                   ->execute([json_encode($details), $sessionId, $studentIdForDb]);

                echo json_encode(['success' => true, 'path' => $publicPath]);
            } else {
                echo json_encode(['success' => false, 'message' => 'File save failed']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'No file uploaded']);
        }
        break;
}

function generateReportHTML($usn, $sem, $name, $type, $score, $content) {
    // Escape student-controlled fields; $content is the AI report body and is sanitized client-side
    $esc = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $usn = $esc($usn); $sem = $esc($sem); $name = $esc($name); $type = $esc($type);
    $score = is_numeric($score) ? (float)$score : 0;
    $favicon = $esc(APP_URL . '/assets/img/favicon.png');
    return "
    <html>
    <head>
    <link rel='icon' type='image/png' href='{$favicon}'>
        <style>
            body { font-family: sans-serif; padding: 40px; line-height: 1.6; color: #333; }
            h1 { color: #800000; border-bottom: 2px solid #800000; padding-bottom: 10px; margin-bottom: 20px; }
            h2 { color: #333; margin-top: 30px; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
            .meta { background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #ddd; }
            .score-box { float: right; background: #800000; color: white; padding: 15px 25px; border-radius: 8px; font-size: 24px; font-weight: bold; }
            .content { font-size: 14px; }
            strong { color: #000; }
        </style>
    </head>
    <body>
        <div class='score-box'>{$score}%</div>
        <h1>NQT HR Behavioral Report</h1>
        <div class='meta'>
            <p><strong>Student Name:</strong> {$name}</p>
            <p><strong>USN:</strong> {$usn}</p>
            <p><strong>Semester:</strong> {$sem}</p>
            <p><strong>Assessment Type:</strong> {$type}</p>
            <p><strong>Date:</strong> " . date('d M Y') . "</p>
        </div>
        <div class='content'>
            {$content}
        </div>
    </body>
    </html>";
}

