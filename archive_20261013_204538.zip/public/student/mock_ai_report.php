<?php
require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/../../src/Models/StudentProfile.php';
require_once __DIR__ . '/../../src/Models/User.php';

use App\Helpers\SessionFilterHelper;

requireRole(ROLE_STUDENT);

$userId = getUserId();
$studentIdForDb = getStudentIdForAssessment();

// Handle POST from assessment completion or dashboard
if (isPost() && isset($_POST['session_id'])) {
    SessionFilterHelper::setFilters('mock_ai_report', [
        'session_id' => $_POST['session_id'] ?? 0
    ]);
    header("Location: mock_ai_report.php");
    exit;
}

// Handle GET redirect from interview completion (e.g. ?session_id=123)
if (!isPost() && isset($_GET['session_id']) && intval($_GET['session_id']) > 0) {
    SessionFilterHelper::setFilters('mock_ai_report', [
        'session_id' => intval($_GET['session_id'])
    ]);
}

$filters = SessionFilterHelper::getFilters('mock_ai_report');
$sessionId = intval($_GET['session_id'] ?? ($_GET['id'] ?? ($filters['session_id'] ?? 0)));

$db = getDB();
$sql = "SELECT m.* FROM mock_ai_interview_sessions m WHERE m.id = ? AND m.student_id = ?";
$stmt = $db->prepare($sql);
$stmt->execute([$sessionId, $studentIdForDb]);
$session = $stmt->fetch();

if (!$session || !$session['report_content']) {
    Session::flash('error', 'Report not found or still generating.');
    redirect('mock_ai_interview');
}

// Fetch proctoring logs and integrity report details
$integrityReport = [
    'screen_share_integrity_pct' => 100,
    'camera_available_pct' => 100,
    'face_presence_pct' => 100,
    'gaze_confidence_pct' => 95,
    'attention_deviations' => 0,
    'longest_deviation_sec' => 0,
    'screen_interruptions' => 0,
    'multiple_faces_count' => 0,
    'integrity_status' => 'Verified • Authentic Candidate Environment'
];
$strikeCount = 0;
$penaltyPct = 0;
$adjustedScore = (int) ($session['overall_score'] ?? 0);
$rawScore = $adjustedScore;

// 1. Check unified_ai_assessments for rich snapshot
try {
    $uStmt = $db->prepare("SELECT details, score, feedback FROM unified_ai_assessments WHERE student_id = ? AND (assessment_type = 'Technical' OR assessment_type = 'HR' OR assessment_type = 'Aptitude') AND completed_at >= ? ORDER BY completed_at DESC LIMIT 1");
    $uStmt->execute([$studentIdForDb, $session['started_at'] ?? '2000-01-01']);
    $uRow = $uStmt->fetch();
    if ($uRow && !empty($uRow['details'])) {
        $uDetails = json_decode($uRow['details'], true);
        if (is_array($uDetails)) {
            if (isset($uDetails['integrity_report']) && is_array($uDetails['integrity_report'])) {
                $integrityReport = array_merge($integrityReport, $uDetails['integrity_report']);
            }
            if (isset($uDetails['raw_score'])) $rawScore = (int)$uDetails['raw_score'];
            if (isset($uDetails['penalty_pct'])) $penaltyPct = (int)$uDetails['penalty_pct'];
            if (isset($uDetails['strike_count'])) $strikeCount = (int)$uDetails['strike_count'];
        }
    }
} catch (Exception $e) {}

// 2. Query proctoring_logs directly for exact session event audit
try {
    $pStmt = $db->prepare("SELECT * FROM proctoring_logs WHERE session_id = ? AND student_id = ? ORDER BY created_at ASC");
    $pStmt->execute([$sessionId, $studentIdForDb]);
    $pLogs = $pStmt->fetchAll();
    if ($pLogs && count($pLogs) > 0) {
        $secViolations = 0;
        $maxDev = 0;
        foreach ($pLogs as $pLog) {
            $evtType = $pLog['event_type'] ?? '';
            $dur = (float)($pLog['duration_seconds'] ?? 0);
            if ($evtType === 'SECURITY_VIOLATION' || $evtType === 'TAB_SWITCH' || $evtType === 'WINDOW_BLUR' || $evtType === 'SCREEN_SHARE_STOPPED' || $evtType === 'FULLSCREEN_EXIT' || $evtType === 'MULTI_FACE' || $evtType === 'NO_FACE') {
                $secViolations++;
            }
            if ($evtType === 'GAZE_DEVIATION' || $evtType === 'LOOKING_AWAY') {
                $integrityReport['attention_deviations']++;
                if ($dur > $maxDev) $maxDev = $dur;
            } else if ($evtType === 'SCREEN_SHARE_STOPPED' || $evtType === 'FULLSCREEN_EXIT') {
                $integrityReport['screen_interruptions']++;
            } else if ($evtType === 'MULTI_FACE') {
                $integrityReport['multiple_faces_count']++;
            } else if ($evtType === 'NO_FACE') {
                $integrityReport['face_presence_pct'] = max(70, $integrityReport['face_presence_pct'] - 5);
            }
        }
        if ($secViolations > $strikeCount) {
            $strikeCount = $secViolations;
            $penaltyPct = min(15, $strikeCount * 5);
        }
        $integrityReport['longest_deviation_sec'] = $maxDev;
        if ($strikeCount >= 3) {
            $integrityReport['integrity_status'] = 'Auto-Submitted: Maximum Security Violations (3/3) Exceeded';
        } else if ($strikeCount > 0) {
            $integrityReport['integrity_status'] = "Integrity Penalties Applied (-{$penaltyPct}% Deducted)";
        }
    }
} catch (Exception $e) {}

// Resolve student name: on server use remote GMU/GMIT via User model; fallback to session name if remote unavailable
$studentName = getFullName() ?: 'Student';
$institution = $session['institution'] ?? getInstitution();
$lookupId = $userId ?: getUsername();
if ($lookupId && $institution) {
    try {
        $userModel = new User();
        $remoteUser = $userModel->find($lookupId, $institution);
        if ($remoteUser && !empty($remoteUser['full_name'])) {
            $studentName = $remoteUser['full_name'];
        }
    } catch (Exception $e) {
        // Remote DB not available (e.g. local dev): keep getFullName()
    }
}

$role = $session['role_name'];
$reportContent = $session['report_content'];
$date = date('d M Y', strtotime($session['started_at']));
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interview Performance Report - GM University</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- KaTeX for equation rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary-maroon: #800000;
            --primary-dark: #5b1f1f;
            --white: #ffffff;
            --bg: #f8f9fa;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg);
            color: #333;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 50px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            position: relative;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid var(--primary-maroon);
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .header-left h1 {
            color: var(--primary-maroon);
            margin: 0;
            font-size: 2rem;
            text-transform: uppercase;
        }

        .header-right {
            text-align: right;
        }

        .header-right p {
            margin: 2px 0;
            font-weight: 600;
            color: #666;
        }

        .report-section {
            margin-bottom: 30px;
        }

        .report-section h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--primary-maroon);
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
            margin-bottom: 15px;
        }

        .report-section h3 {
            color: #444;
            margin-top: 20px;
        }

        .metric-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .metric-card {
            background: #fdfdfd;
            border: 1px solid #eee;
            padding: 15px;
            border-radius: 6px;
        }

        .score-badge {
            display: inline-block;
            background: var(--primary-maroon);
            color: white;
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
        }

        .btn-container {
            max-width: 900px;
            margin: 20px auto;
            display: flex;
            justify-content: space-between;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
        }

        .btn-download {
            background-color: var(--primary-maroon);
            color: white;
        }

        .btn-back {
            background-color: #666;
            color: white;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        @media print {
            .btn-container {
                display: none;
            }

            .container {
                box-shadow: none;
                margin: 0;
                width: 100%;
                border-radius: 0;
            }
        }

        /* Markdown-ish styling */
        .report-body strong {
            color: var(--primary-maroon);
        }

        .report-body ul {
            padding-left: 20px;
        }

        .report-body li {
            margin-bottom: 8px;
        }

        .report-body p {
            margin-bottom: 15px;
        }

        /* Assessment Integrity Card */
        .integrity-card {
            background: #fdfdfd;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 35px;
        }

        .integrity-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #edf2f7;
            padding-bottom: 12px;
            margin-bottom: 16px;
        }

        .integrity-header h3 {
            margin: 0;
            font-size: 1.05rem;
            color: var(--primary-maroon);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .integrity-pill {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .integrity-pill.success {
            background: #ecfdf5;
            color: #059669;
            border: 1px solid #a7f3d0;
        }

        .integrity-pill.warning {
            background: #fffbeb;
            color: #d97706;
            border: 1px solid #fde68a;
        }

        .integrity-pill.danger {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }

        .integrity-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }

        @media (max-width: 768px) {
            .integrity-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        .integrity-metric {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            padding: 10px 14px;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .integrity-metric .label {
            font-size: 0.72rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .integrity-metric .val {
            font-size: 1.05rem;
            font-weight: 800;
            color: #1e293b;
        }

        .score-breakdown-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 14px 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>

    <div class="btn-container">
        <button onclick="exitReport()" class="btn btn-back">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </button>
        <button onclick="downloadPDF()" class="btn btn-download">
            <i class="fas fa-file-pdf"></i> Download Performance Report
        </button>
    </div>

    <div class="container" id="reportContent">
        <div class="header">
            <div class="header-left">
                <h1>GM UNIVERSITY</h1>
                <p>Training & Placement Cell</p>
            </div>
            <div class="header-right">
                <p>Student: <?php echo htmlspecialchars((string) $studentName); ?></p>
                <p>Target Concepts: <?php echo htmlspecialchars((string) $role); ?></p>
                <?php if (!empty($session['difficulty'])): ?>
                    <p>Difficulty: <?php echo htmlspecialchars((string) $session['difficulty']); ?></p>
                <?php endif; ?>
                <p>Date: <?php echo $date; ?></p>
            </div>
        </div>

        <div class="report-body">
            <div
                style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); padding: 30px; border-radius: 12px; margin-bottom: 25px; border-left: 5px solid var(--primary-maroon); display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h3
                        style="margin: 0; color: #444; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px;">
                        Overall Performance Score</h3>
                    <p style="margin: 5px 0 0; color: #666; font-size: 0.85rem;">Based on technical accuracy,
                        communication, and problem-solving.</p>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 3rem; font-weight: 900; color: var(--primary-maroon); line-height: 1;">
                        <?php echo (int) ($session['overall_score'] ?? 0); ?><span
                            style="font-size: 1.2rem; color: #999;">/100</span></div>
                    <div
                        style="font-size: 0.75rem; font-weight: 800; margin-top: 5px; color: <?php echo ($session['overall_score'] >= 70) ? '#10b981' : (($session['overall_score'] >= 40) ? '#f59e0b' : '#ef4444'); ?>;">
                        <?php
                        if (($session['overall_score'] ?? 0) >= 80)
                            echo 'EXCEPTIONAL';
                        elseif (($session['overall_score'] ?? 0) >= 60)
                            echo 'READY FOR HIRE';
                        elseif (($session['overall_score'] ?? 0) >= 40)
                            echo 'NEEDS PRACTICE';
                        else
                            echo 'BEGINNER';
                        ?>
                    </div>
                </div>
            </div>

            <?php if ($penaltyPct > 0): ?>
            <div class="score-breakdown-box">
                <div>
                    <span style="color: #64748b; font-weight: 600;">Raw Score:</span> <strong><?php echo $rawScore; ?>/100</strong>
                </div>
                <div>
                    <span style="color: #ef4444; font-weight: 700;">Integrity Penalty: -<?php echo $penaltyPct; ?>%</span>
                    <span style="color: #64748b; font-size: 0.8rem;">(<?php echo $strikeCount; ?> violation<?php echo $strikeCount > 1 ? 's' : ''; ?> @ 5% each)</span>
                </div>
                <div>
                    <span style="color: #64748b; font-weight: 600;">Verified Final Score:</span> <strong style="color: var(--primary-maroon); font-size: 1.1rem;"><?php echo $adjustedScore; ?>/100</strong>
                </div>
            </div>
            <?php endif; ?>

            <!-- Assessment Integrity Audit Card -->
            <div class="integrity-card">
                <div class="integrity-header">
                    <h3><i class="fas fa-shield-alt" style="color: #10b981;"></i> Assessment Integrity Audit Report</h3>
                    <div class="integrity-pill <?php echo ($strikeCount >= 3) ? 'danger' : (($strikeCount > 0) ? 'warning' : 'success'); ?>">
                        <?php echo htmlspecialchars($integrityReport['integrity_status']); ?>
                    </div>
                </div>
                <div class="integrity-grid">
                    <div class="integrity-metric">
                        <div class="label">Screen Share</div>
                        <div class="val"><?php echo htmlspecialchars((string)$integrityReport['screen_share_integrity_pct']); ?>%</div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Camera Stream</div>
                        <div class="val"><?php echo htmlspecialchars((string)$integrityReport['camera_available_pct']); ?>%</div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Face Presence</div>
                        <div class="val"><?php echo htmlspecialchars((string)$integrityReport['face_presence_pct']); ?>%</div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Gaze Confidence</div>
                        <div class="val"><?php echo htmlspecialchars((string)$integrityReport['gaze_confidence_pct']); ?>%</div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Gaze Shifts</div>
                        <div class="val"><?php echo (int) $integrityReport['attention_deviations']; ?></div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Longest Shift</div>
                        <div class="val"><?php echo htmlspecialchars((string)$integrityReport['longest_deviation_sec']); ?>s</div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Screen Interruptions</div>
                        <div class="val"><?php echo (int) $integrityReport['screen_interruptions']; ?></div>
                    </div>
                    <div class="integrity-metric">
                        <div class="label">Multiple People</div>
                        <div class="val"><?php echo (int) $integrityReport['multiple_faces_count']; ?></div>
                    </div>
                </div>
            </div>

            <?php
            // Convert Markdown-ish to HTML.
            // Sanitize first: allow only harmless formatting tags so a malicious or
            // malformed report can never inject <script>/<style>/event handlers.
            $allowedTags = '<b><strong><br><p><ul><ol><li><em><i><h2><h3><h4><span><table><tr><td><th>';
            $html = strip_tags((string) $reportContent, $allowedTags);
            // strip_tags keeps attributes (onclick=, style=, …) — remove them all;
            // none of the allowed formatting tags need attributes here.
            $html = preg_replace('/<(\/?\w+)[^>]*>/', '<$1>', $html);
            // Basic Markdown Conversion
            $html = preg_replace('/^## (.*$)/m', '<h2>$1</h2>', $html);
            $html = preg_replace('/^### (.*$)/m', '<h3>$1</h3>', $html);
            $html = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $html);
            $html = preg_replace('/^- (.*$)/m', '<li>$1</li>', $html);

            // Wrap lists
            $html = preg_replace('/(<li>.*<\/li>)/s', '<ul>$1</ul>', $html);
            // Fix double ul
            $html = str_replace('</ul><ul>', '', $html);

            // Convert scores to badges
            $html = preg_replace('/Score: (\d+\/10)/', 'Score: <span class="score-badge">$1</span>', $html);

            echo $html;
            ?>
        </div>

        <div
            style="margin-top: 50px; border-top: 1px solid #eee; padding-top: 20px; font-size: 0.8rem; color: #999; text-align: center;">
            This is an AI-generated assessment report by GM University Placement Portal.
            It is intended for student evaluation and preparation purposes only.
        </div>
    </div>

    <script>
        function exitReport() {
            // Replace current history entry so browser "Back" doesn't return here
            window.location.replace('dashboard.php');
        }

        async function autoSaveReport() {
            const element = document.getElementById('reportContent');
            const opt = {
                margin: [10, 10, 10, 10],
                filename: 'temp_report.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };

            // Generate PDF as blob
            const pdfBlob = await html2pdf().set(opt).from(element).output('blob');

            // Upload to server
            const formData = new FormData();
            formData.append('action', 'save_pdf');
            formData.append('session_id', '<?php echo $sessionId; ?>');
            formData.append('report_pdf', pdfBlob, 'report.pdf');

            try {
                const res = await fetch('mock_ai_handler.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                console.log('Auto-save status:', data);
            } catch (e) {
                console.error('Failed to auto-save report:', e);
            }
        }

        function downloadPDF() {
            const element = document.getElementById('reportContent');
            const opt = {
                margin: [10, 10, 10, 10],
                filename: 'GMU_Mock_Interview_Report.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };

            html2pdf().set(opt).from(element).save();
        }

        function renderMath(element) {
            if (typeof renderMathInElement === 'function') {
                renderMathInElement(element, {
                    delimiters: [
                        { left: "$$", right: "$$", display: true },
                        { left: "$", right: "$", display: false },
                        { left: "\\(", right: "\\)", display: false },
                        { left: "\\[", right: "\\]", display: true }
                    ],
                    throwOnError: false
                });
            } else {
                setTimeout(() => renderMath(element), 100);
            }
        }

        // Trigger auto-save after a short delay for rendering
        window.onload = () => {
            renderMath(document.getElementById('reportContent'));
            setTimeout(autoSaveReport, 1500);
        };
    </script>

</body>

</html>