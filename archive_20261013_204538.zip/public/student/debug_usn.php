<?php
require_once __DIR__ . '/../../config/bootstrap.php';

$usn = '4GM22AI029';
echo "Debugging USN: $usn\n";

$userModel = new User();
$institutions = [
    INSTITUTION_GMU => DB_GMU_PREFIX,
    INSTITUTION_GMIT => DB_GMIT_PREFIX
];

foreach ($institutions as $inst => $prefix) {
    echo "Checking Institution: $inst (Prefix: $prefix)\n";
    $remoteDB = getDB('gmu');
    if (!$remoteDB) {
        echo "Error: Could not connect to remote DB\n";
        continue;
    }

    $table = $prefix . 'users';
    $sql = "SELECT * FROM {$table} WHERE USER_NAME = ? OR AADHAR = ?";
    $stmt = $remoteDB->prepare($sql);
    $stmt->execute([$usn, $usn]);
    $user = $stmt->fetch();

    if ($user) {
        echo "Found in {$table}!\n";
        print_r($user);
        
        $profileModel = new StudentProfile();
        $profile = $profileModel->getProfile($user['SL_NO'] ?? $user['ENQUIRY_NO'] ?? $usn);
        echo "\nProfile Data:\n";
        print_r($profile);
    } else {
        echo "Not found in {$table}\n";
    }
    echo "-------------------\n";
}
