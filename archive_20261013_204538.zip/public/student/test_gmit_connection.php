<?php
/**
 * GMIT Remote Database Connection Diagnostic
 * Run this on the SERVER to diagnose the connection issue
 */

echo "<h2>GMIT Remote Database Diagnostic</h2>";
echo "<pre>";

// Test 1: Check if we can connect to the remote database
echo "=== TEST 1: Remote Database Connection ===\n";
try {
    $dsn = "mysql:host=192.168.8.140;port=3306;dbname=gmit_new;charset=utf8mb4";
    $pdo = new PDO($dsn, 'gmu_leap', '$ecure@ccess@LEAP', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    echo "✅ Successfully connected to gmit_new database at 192.168.8.140\n\n";
} catch (PDOException $e) {
    echo "❌ Failed to connect: " . $e->getMessage() . "\n\n";
    die("Cannot proceed without database connection.");
}

// Test 2: Check if 'users' table exists
echo "=== TEST 2: Check if 'users' table exists ===\n";
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    $result = $stmt->fetch();
    if ($result) {
        echo "✅ Table 'users' exists\n\n";
    } else {
        echo "❌ Table 'users' does NOT exist\n";
        echo "Available tables:\n";
        $stmt = $pdo->query("SHOW TABLES");
        while ($row = $stmt->fetch()) {
            echo "  - " . $row[0] . "\n";
        }
        echo "\n";
    }
} catch (PDOException $e) {
    echo "❌ Error checking table: " . $e->getMessage() . "\n\n";
}

// Test 3: Check table structure
echo "=== TEST 3: Check 'users' table structure ===\n";
try {
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll();
    echo "Columns in 'users' table:\n";
    foreach ($columns as $col) {
        echo "  - {$col['Field']} ({$col['Type']})\n";
    }
    echo "\n";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n\n";
}

// Test 4: Check if ENQUIRY_NO and USER_NAME columns exist
echo "=== TEST 4: Check required columns ===\n";
$requiredColumns = ['ENQUIRY_NO', 'USER_NAME'];
foreach ($requiredColumns as $col) {
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE '$col'");
    if ($stmt->fetch()) {
        echo "✅ Column '$col' exists\n";
    } else {
        echo "❌ Column '$col' does NOT exist\n";
    }
}
echo "\n";

// Test 5: Try to find a sample GMIT student
echo "=== TEST 5: Search for GMIT23AI122 ===\n";
try {
    $sql = "SELECT * FROM users WHERE ENQUIRY_NO = ? OR USER_NAME = ? LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['GMIT23AI122', 'GMIT23AI122']);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "✅ Found user GMIT23AI122:\n";
        print_r($user);
    } else {
        echo "❌ User GMIT23AI122 not found\n";
        echo "\nTrying to find any GMIT users:\n";
        $stmt = $pdo->query("SELECT * FROM users WHERE USER_NAME LIKE 'GMIT%' LIMIT 5");
        $users = $stmt->fetchAll();
        if ($users) {
            echo "Sample GMIT users found:\n";
            foreach ($users as $u) {
                echo "  - USER_NAME: {$u['USER_NAME']}, ENQUIRY_NO: " . ($u['ENQUIRY_NO'] ?? 'N/A') . "\n";
            }
        } else {
            echo "No GMIT users found in the table\n";
        }
    }
} catch (PDOException $e) {
    echo "❌ Query error: " . $e->getMessage() . "\n";
}

echo "</pre>";
?>
