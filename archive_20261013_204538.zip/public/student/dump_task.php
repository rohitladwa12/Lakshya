<?php
require_once __DIR__ . '/../../config/bootstrap.php';
$db = getDB();
$stmt = $db->query("SELECT * FROM coordinator_tasks ORDER BY id DESC LIMIT 1");
$task = $stmt->fetch(PDO::FETCH_ASSOC);
file_put_contents('task_dump.txt', print_r($task, true));
?>
