<?php
// Simple test file to check if coding_handler.php is accessible
echo "Testing coding_handler.php accessibility...\n\n";

$handlerPath = __DIR__ . '/coding_handler.php';
echo "Handler path: $handlerPath\n";
echo "File exists: " . (file_exists($handlerPath) ? 'YES' : 'NO') . "\n";
echo "Is readable: " . (is_readable($handlerPath) ? 'YES' : 'NO') . "\n";

// Try to include it
if (file_exists($handlerPath)) {
    echo "\nFile found! The issue is likely with how you're accessing the page.\n";
    echo "\nMake sure you're accessing:\n";
    echo "http://localhost/placement_final/public/student/coding_practice.php\n";
    echo "\nNOT:\n";
    echo "http://localhost/placement_final/student/coding_practice\n";
} else {
    echo "\nFile NOT found at expected location!\n";
}
?>
