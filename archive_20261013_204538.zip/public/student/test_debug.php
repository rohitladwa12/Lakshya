<?php
require_once __DIR__ . '/../../config/bootstrap.php';

$username = $_GET['id'] ?? (function_exists('getUsername') ? getUsername() : 'GMIT123');
$branch = $_GET['branch'] ?? 'AIML';
$institution = $_GET['inst'] ?? (function_exists('getInstitution') ? getInstitution() : 'GMIT');

echo "<h1>Debug Task Visibility</h1>";
echo "Testing for Student: <strong>$username</strong> ($branch, $institution)<br><hr>";

try {
    $db = getDB();
    
    // 1. Check if user exists (rough check)
    // 2. Run the main query
    
    $query = "SELECT ct.id, ct.task_type, ct.title, 
                     ct.target_type, ct.target_students, ct.target_branches,
                     ct.deadline, ct.is_active,
                     dc.department, dc.institution as coord_inst
              FROM coordinator_tasks ct
              JOIN dept_coordinators dc ON ct.coordinator_id = dc.id
              LEFT JOIN task_completions tc ON ct.id = tc.task_id 
                                            AND tc.student_id = ?
              WHERE ct.is_active = 1 
                AND tc.id IS NULL
                AND (
                    (ct.target_type = 'department' AND dc.department = ? AND dc.institution = ?)
                    OR (ct.target_type = 'branch' AND JSON_CONTAINS(ct.target_branches, ?))
                    OR (ct.target_type = 'individual' AND ct.target_students LIKE ?)
                )";
    
    echo "<h3>Query Logic:</h3>";
    echo "<pre>" . htmlspecialchars($query) . "</pre>";
    
    $params = [
        $username,           // tc.student_id
        $branch,             // dc.department
        $institution,        // dc.institution
        "\"$branch\"",       // JSON branch
        "%\"$username\"%"    // LIKE student check
    ];
    
    echo "<h3>Parameters:</h3>";
    var_dump($params);
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Results:</h3>";
    if (empty($tasks)) {
        echo "<p style='color:red;'>No matching tasks found.</p>";
        
        // Check potential failures
        echo "<h4>Potential Reasons check:</h4>";
        
        // A. Is there ANY task?
        $allTasks = $db->query("SELECT * FROM coordinator_tasks ORDER BY id DESC LIMIT 5")->fetchAll();
        echo "Last 5 Tasks created:<br>";
        foreach ($allTasks as $t) {
            echo "ID: {$t['id']}, Type: {$t['target_type']}, Target Students: {$t['target_students']}, Deadline: {$t['deadline']}<br>";
            
            // Check individual match
            // Simulating LIKE
            $jsonStudents = $t['target_students'];
            if (strpos($jsonStudents, "\"$username\"") !== false) {
                 echo "  -> Matches user string!<br>";
            } else {
                 echo "  -> Does NOT match user string.<br>";
            }
            
            // Check deadline
            if (strtotime($t['deadline']) < time()) {
                 echo "  -> Deadline EXPIRED (" . $t['deadline'] . " vs NOW " . date('Y-m-d H:i:s') . ")<br>";
            }
        }
        
    } else {
        echo "<p style='color:green;'>Found " . count($tasks) . " tasks!</p>";
        foreach ($tasks as $t) {
            echo "Task ID: {$t['id']} - {$t['title']} (Type: {$t['task_type']})<br>";
        }
    }

} catch (Exception $e) {
    echo "<h2>ERROR:</h2>";
    echo $e->getMessage();
    echo "<br>Trace:<br>" . $e->getTraceAsString();
}
?>
