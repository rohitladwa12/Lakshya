// MUST be first: prevents PHP warnings from polluting JSON output
ob_start();

/**
 * Certification Viva Handler
 */

require_once __DIR__ . '/../../config/bootstrap.php';
requireLogin();
requireRole(ROLE_STUDENT);

header('Content-Type: application/json');

$userId = getUserId();
$username = getUsername();
$studentIdForDb = getStudentIdForAssessment();
$institution = $_SESSION['institution'] ?? 'GMU';

require_once __DIR__ . '/../../src/Services/AIService.php';
$aiService = new AIService();

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$input = array_merge($input, $_POST);
$action = $input['action'] ?? '';

// Rate limit: 10 viva AI requests per user per 60 seconds
if (!checkRateLimit("cert_viva_api_{$userId}", 10, 60)) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many requests. Please wait before trying again.']);
    exit;
}

try {
    switch ($action) {
        case 'generate_viva':
            $portfolioId = $input['portfolio_id'] ?? 0;
            
            // Verify ownership
            $stmt = getDB()->prepare("SELECT * FROM student_portfolio WHERE id = ? AND (student_id = ? OR UPPER(student_id) = UPPER(?))");
            $stmt->execute([$portfolioId, $username, $username]);
            $item = $stmt->fetch();
            
            if (!$item || $item['category'] !== 'Certification') {
                ob_clean(); echo json_encode(['success' => false, 'message' => 'Certification not found.']);
                exit;
            }

            session_write_close();
            require_once ROOT_PATH . '/src/Services/QueueService.php';
            $jobId = \App\Services\QueueService::pushJob('generateCertificationQuestions', [$item['title'], $item['sub_title'] ?: 'Unknown Issuer'], $userId);
            
            ob_clean(); echo json_encode([
                'success' => true, 
                'job_id' => $jobId,
                'message' => 'Generating questions...'
            ]);
            exit;

        case 'submit_viva':
            $portfolioId = $input['portfolio_id'] ?? 0;
            $history = $input['history'] ?? [];

            // Verify ownership
            $stmt = getDB()->prepare("SELECT * FROM student_portfolio WHERE id = ? AND (student_id = ? OR UPPER(student_id) = UPPER(?))");
            $stmt->execute([$portfolioId, $username, $username]);
            $item = $stmt->fetch();
            
            if (!$item) {
                ob_clean(); echo json_encode(['success' => false, 'message' => 'Certification not found.']);
                exit;
            }

            session_write_close();
            require_once ROOT_PATH . '/src/Services/QueueService.php';
            $jobId = \App\Services\QueueService::pushJob('evaluateCertificationViva', [$item['title'], $item['sub_title'], json_encode($history)], $userId);
            
            ob_clean(); echo json_encode([
                'success' => true, 
                'job_id' => $jobId,
                'message' => 'Evaluating responses...'
            ]);
            exit;

        case 'save_viva_result':
            $portfolioId = $input['portfolio_id'] ?? 0;
            $score = (float)($input['score'] ?? 0);
            $feedback = $input['feedback'] ?? '';
            $history = $input['history'] ?? [];

            // 1. Verify ownership
            $stmt = getDB()->prepare("SELECT * FROM student_portfolio WHERE id = ? AND (student_id = ? OR UPPER(student_id) = UPPER(?))");
            $stmt->execute([$portfolioId, $username, $username]);
            $item = $stmt->fetch();
            
            if (!$item) {
                ob_clean(); echo json_encode(['success' => false, 'message' => 'Certification not found.']);
                exit;
            }

            // 2. Update student_portfolio
            $isVerified = ($score >= 70) ? 1 : 0;
            $sql = "UPDATE student_portfolio SET 
                    is_verified = ?, 
                    verification_score = ?, 
                    verification_date = CURRENT_TIMESTAMP,
                    verification_details = ? 
                    WHERE id = ?";
            getDB()->prepare($sql)->execute([
                $isVerified,
                $score,
                json_encode(['feedback' => $feedback, 'transcript' => $history]),
                $portfolioId
            ]);

            // 3. Sync to unified_ai_assessments
            try {
                require_once ROOT_PATH . '/src/Models/StudentProfile.php';
                $studentModel = new StudentProfile();
                $profile = $studentModel->getByUserId($userId);

                $sqlUnified = "INSERT INTO unified_ai_assessments (
                    student_id, institution, student_name, usn, aadhar,
                    current_sem, branch, assessment_type,
                    company_name, score, total_marks,
                    feedback, details, status, completed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

                getDB()->prepare($sqlUnified)->execute([
                    $studentIdForDb,
                    $institution,
                    $profile['name'] ?? getFullName(),
                    $profile['usn'] ?? getUsername(),
                    $profile['aadhar'] ?? null,
                    $profile['semester'] ?? null,
                    $profile['department'] ?? null,
                    'Skill Verification',
                    $item['title'], 
                    $score,
                    100,
                    $feedback,
                    json_encode([
                        'transcript' => $history,
                        'cert_title' => $item['title'],
                        'issuer' => $item['sub_title']
                    ]),
                    'completed'
                ]);
            } catch (Exception $e) {
                error_log("Failed to sync certification verification to unified table: " . $e->getMessage());
            }

            ob_clean(); echo json_encode(['success' => true, 'message' => 'Result saved successfully.']);
            exit;

        default:
            ob_clean(); echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    }
} catch (Exception $e) {
    ob_clean(); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
