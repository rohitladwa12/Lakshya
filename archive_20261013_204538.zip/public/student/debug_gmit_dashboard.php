<?php
/**
 * Debug script to identify GMIT student data mismatch
 */

require_once __DIR__ . '/../../config/bootstrap.php';
requireRole(ROLE_STUDENT);

$userId = getUserId();
$username = getUsername();
$institution = $_SESSION['institution'] ?? '';

echo "<h2>GMIT Dashboard Debug</h2>";
echo "<pre>";
echo "User ID: " . htmlspecialchars($userId) . "\n";
echo "Username: " . htmlspecialchars($username) . "\n";
echo "Institution: " . htmlspecialchars($institution) . "\n";
echo "\n--- Checking User Table ---\n";

require_once __DIR__ . '/../../src/Models/User.php';
$userModel = new User();
$user = $userModel->find($userId, $institution);
echo "User Data:\n";
print_r($user);

echo "\n--- Checking student_sem_sgpa Table ---\n";
require_once __DIR__ . '/../../src/Models/StudentProfile.php';
$profileModel = new StudentProfile();

// Check what's actually in the table
$sql = "SELECT * FROM student_sem_sgpa WHERE student_id LIKE ? OR student_id LIKE ? LIMIT 10";
$stmt = $profileModel->db->prepare($sql);
$stmt->execute(["%{$userId}%", "%{$username}%"]);
$records = $stmt->fetchAll();

echo "Records found with LIKE search: " . count($records) . "\n";
if (!empty($records)) {
    echo "Sample records:\n";
    foreach ($records as $rec) {
        echo "  student_id: [{$rec['student_id']}] | institution: [{$rec['institution']}] | semester: {$rec['semester']} | sgpa: {$rec['sgpa']}\n";
    }
}

echo "\n--- Testing Exact Match ---\n";
$enquiryNo = strtoupper(trim((string)$user['id']));
$usernameUpper = strtoupper(trim((string)$user['username']));

echo "Searching for:\n";
echo "  enquiryNo (uppercase): [{$enquiryNo}]\n";
echo "  username (uppercase): [{$usernameUpper}]\n";
echo "  userId from session: [{$userId}]\n";

$sql2 = "SELECT * FROM student_sem_sgpa WHERE UPPER(TRIM(student_id)) = ? OR UPPER(TRIM(student_id)) = ? OR UPPER(TRIM(student_id)) = ?";
$stmt2 = $profileModel->db->prepare($sql2);
$stmt2->execute([$enquiryNo, $usernameUpper, strtoupper($userId)]);
$exactRecords = $stmt2->fetchAll();

echo "\nRecords found with exact match: " . count($exactRecords) . "\n";
if (!empty($exactRecords)) {
    foreach ($exactRecords as $rec) {
        echo "  student_id: [{$rec['student_id']}] | semester: {$rec['semester']} | sgpa: {$rec['sgpa']}\n";
    }
}

echo "\n--- All student_sem_sgpa records (first 20) ---\n";
$sql3 = "SELECT student_id, institution, semester, sgpa FROM student_sem_sgpa LIMIT 20";
$stmt3 = $profileModel->db->prepare($sql3);
$stmt3->execute();
$allRecords = $stmt3->fetchAll();
foreach ($allRecords as $rec) {
    echo "  student_id: [{$rec['student_id']}] | institution: [{$rec['institution']}] | semester: {$rec['semester']}\n";
}

echo "</pre>";
?>
