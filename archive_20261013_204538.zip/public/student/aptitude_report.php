<?php
/**
 * Unified AI Assessment Report
 * Displays results for Aptitude, Technical, and HR assessments
 */

require_once __DIR__ . '/../../config/bootstrap.php';

// Require student role
use App\Helpers\SessionFilterHelper;

requireLogin();

$userId = getUserId();
$studentIdForDb = getStudentIdForAssessment();
$db = getDB();

// Handle POST from assessment completion or dashboard
if (isPost() && isset($_POST['id'])) {
    SessionFilterHelper::setFilters('aptitude_report', [
        'id' => $_POST['id'] ?? 0
    ]);
    header("Location: aptitude_report.php");
    exit;
}

$filters = SessionFilterHelper::getFilters('aptitude_report');
$id = isset($_GET['id']) ? (int)$_GET['id'] : ($filters['id'] ?? 0);
$isDrive = isset($_GET['drive']) ? (bool)$_GET['drive'] : (!empty($filters['is_drive']));

$isStaff = isLoggedIn() && in_array(getRole(), [ROLE_ADMIN, ROLE_PLACEMENT_OFFICER, ROLE_HOD, ROLE_DEPT_COORDINATOR, ROLE_VC, ROLE_DEMO]);

$assessment = null;
if ($isDrive) {
    if ($isStaff) {
        $stmt = $db->prepare("
            SELECT sda.id, sda.round_type as assessment_type, c.name as company_name, 
                   sda.score, sda.status, sda.details, sda.started_at, sda.completed_at, sda.student_name,
                   sda.student_id as usn, sda.branch, sda.sem as current_sem
            FROM student_drive_attempts sda
            LEFT JOIN campus_drives cd ON sda.drive_id = cd.id
            LEFT JOIN job_postings jp ON cd.job_id = jp.id
            LEFT JOIN companies c ON jp.company_id = c.id
            WHERE sda.id = ?
        ");
        $stmt->execute([$id]);
    } else {
        $stmt = $db->prepare("
            SELECT sda.id, sda.round_type as assessment_type, c.name as company_name, 
                   sda.score, sda.status, sda.details, sda.started_at, sda.completed_at, sda.student_name,
                   sda.student_id as usn, sda.branch, sda.sem as current_sem
            FROM student_drive_attempts sda
            LEFT JOIN campus_drives cd ON sda.drive_id = cd.id
            LEFT JOIN job_postings jp ON cd.job_id = jp.id
            LEFT JOIN companies c ON jp.company_id = c.id
            WHERE sda.id = ? AND sda.student_id = ?
        ");
        $stmt->execute([$id, $studentIdForDb]);
    }
    $assessment = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (empty($assessment)) {
    if ($isStaff) {
        $stmt = $db->prepare("SELECT * FROM unified_ai_assessments WHERE id = ?");
        $stmt->execute([$id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM unified_ai_assessments WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentIdForDb]);
    }
    $assessment = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!$assessment) {
    die("Assessment record not found or access denied.");
}

$details = json_decode($assessment['details'], true) ?? [];
$questions = $details['questions'] ?? [];
$userAnswers = $details['user_answers'] ?? [];
$reportContent = $details['report_content'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Assessment Report - <?php echo htmlspecialchars($assessment['company_name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="../js/lakshya_dialogs.js?v=<?php echo APP_VERSION; ?>"></script>
    <script src="report_question.js?v=<?php echo APP_VERSION; ?>"></script>
    <style>
        :root {
            --primary: #800000;
            --secondary: #e9c66f;
            --dark: #1a1a1a;
            --card-bg: #262626;
            --white: #ffffff;
            --gray: #888888;
            --success: #27ae60;
            --error: #e74c3c;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Outfit', sans-serif; }
        body { background: #121212; color: var(--white); line-height: 1.6; }
        .container { max-width: 1000px; margin: 40px auto; padding: 20px; }

        .header {
            background: linear-gradient(135deg, var(--primary) 0%, #4a0000 100%);
            padding: 40px;
            border-radius: 24px;
            text-align: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .header h1 { font-size: 2.5rem; color: var(--secondary); margin-bottom: 10px; }
        .header p { opacity: 0.8; font-size: 1.1rem; }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.05);
        }

        .stat-card .label { color: var(--gray); font-size: 0.9rem; text-transform: uppercase; margin-bottom: 10px; }
        .stat-card .value { font-size: 2.5rem; font-weight: 700; color: var(--secondary); }

        .section {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 24px;
            margin-bottom: 30px;
        }

        .section-title { font-size: 1.5rem; color: var(--secondary); margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }

        .meta-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .meta-item { background: rgba(255,255,255,0.03); padding: 15px 20px; border-radius: 12px; }
        .meta-item span { color: var(--gray); font-size: 0.85rem; display: block; }
        .meta-item strong { font-size: 1.1rem; }

        .question-list { display: flex; flex-direction: column; gap: 20px; }
        .question-item {
            background: rgba(255,255,255,0.02);
            padding: 25px;
            border-radius: 16px;
            border-left: 5px solid transparent;
        }
        .question-item.correct { border-left-color: var(--success); }
        .question-item.wrong { border-left-color: var(--error); }

        .q-header { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .q-text { font-size: 1.2rem; font-weight: 600; margin-bottom: 20px; }
        
        .options-review { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .opt { padding: 12px 20px; border-radius: 10px; background: rgba(255,255,255,0.05); font-size: 0.95rem; }
        .opt.user-choice { border: 1px solid #fff; }
        .opt.correct-choice { background: rgba(39, 174, 96, 0.2); color: var(--success); font-weight: 600; }
        .opt.wrong-choice { background: rgba(231, 76, 60, 0.2); color: var(--error); }

        .explanation { margin-top: 20px; padding: 15px; background: rgba(233, 198, 111, 0.05); border-radius: 10px; font-size: 0.9rem; border: 1px dashed var(--secondary); }

        .btn-group { display: flex; justify-content: center; gap: 20px; margin-top: 40px; }
        .btn { padding: 15px 35px; border-radius: 50px; text-decoration: none; font-weight: 600; transition: all 0.3s; }
        .btn-primary { background: var(--secondary); color: var(--dark); }
        .btn-outline { border: 1px solid var(--white); color: var(--white); }
        .btn:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.3); }

        @media (max-width: 768px) {
            .meta-info, .options-review { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <p>AI ASSESSMENT PERFORMANCE</p>
        <h1><?php echo htmlspecialchars($assessment['assessment_type']); ?> Round</h1>
        <p><?php echo htmlspecialchars($assessment['company_name']); ?> • Completed on <?php echo date('d M Y, h:i A', strtotime($assessment['completed_at'])); ?></p>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Overall Score</div>
            <div class="value"><?php echo round($assessment['score']); ?>%</div>
        </div>
        <div class="stat-card">
            <div class="label">Total Questions</div>
            <div class="value"><?php echo $assessment['total_marks'] ?? count($questions); ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Status</div>
            <div class="value" style="color: <?php echo ($assessment['score'] >= 70) ? 'var(--success)' : '#ef4444'; ?>; font-size: 1.5rem;"><?php echo strtoupper($assessment['status']); ?></div>
        </div>
    </div>

    <?php 
    $rawScore = $details['raw_score'] ?? round($assessment['score']);
    $penaltyPct = (float)($details['penalty_pct'] ?? 0);
    $strikeCount = (int)($details['strike_count'] ?? 0);
    $integrityReport = $details['integrity_report'] ?? null;
    ?>

    <?php if ($penaltyPct > 0 || $strikeCount > 0): ?>
    <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 16px; padding: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
        <div>
            <span style="color: #aaa; font-size: 0.85rem; text-transform: uppercase; font-weight: 600; display: block;">Raw Score</span>
            <strong style="font-size: 1.3rem; color: #fff;"><?php echo $rawScore; ?>%</strong>
        </div>
        <div>
            <span style="color: #ef4444; font-size: 0.85rem; text-transform: uppercase; font-weight: 700; display: block;"><i class="fas fa-shield-alt"></i> Proctor Penalty</span>
            <strong style="font-size: 1.3rem; color: #ef4444;">-<?php echo $penaltyPct; ?>% (<?php echo $strikeCount; ?> Strike<?php echo $strikeCount > 1 ? 's' : ''; ?>)</strong>
        </div>
        <div>
            <span style="color: #aaa; font-size: 0.85rem; text-transform: uppercase; font-weight: 600; display: block;">Verified Final Score</span>
            <strong style="font-size: 1.4rem; color: var(--secondary);"><?php echo round($assessment['score']); ?>%</strong>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($integrityReport)): ?>
    <div class="section" style="padding: 25px;">
        <h2 class="section-title" style="margin-bottom: 15px;"><i class="fas fa-shield-alt" style="color: var(--secondary);"></i> Assessment Integrity Audit Report</h2>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.08);">
            <span style="color: #aaa; font-size: 0.9rem;">Integrity Assessment Status:</span>
            <span style="padding: 4px 12px; border-radius: 20px; font-weight: 700; font-size: 0.85rem; background: <?php echo ($strikeCount >= 3) ? 'rgba(239, 68, 68, 0.2)' : (($strikeCount > 0) ? 'rgba(245, 158, 11, 0.2)' : 'rgba(39, 174, 96, 0.2)'); ?>; color: <?php echo ($strikeCount >= 3) ? '#ef4444' : (($strikeCount > 0) ? '#f59e0b' : '#27ae60'); ?>;">
                <?php echo htmlspecialchars($integrityReport['integrity_status'] ?? 'Verified'); ?>
            </span>
        </div>
        <div class="stats-grid" style="margin-bottom: 0; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
            <div class="stat-card" style="padding: 15px;">
                <div class="label" style="font-size: 0.75rem;">Camera Stream</div>
                <div class="value" style="font-size: 1.2rem;"><?php echo htmlspecialchars((string)($integrityReport['camera_availability_pct'] ?? 100)); ?>%</div>
            </div>
            <div class="stat-card" style="padding: 15px;">
                <div class="label" style="font-size: 0.75rem;">Face Presence</div>
                <div class="value" style="font-size: 1.2rem;"><?php echo htmlspecialchars((string)($integrityReport['face_presence_pct'] ?? 100)); ?>%</div>
            </div>
            <div class="stat-card" style="padding: 15px;">
                <div class="label" style="font-size: 0.75rem;">Gaze Confidence</div>
                <div class="value" style="font-size: 1.2rem;"><?php echo htmlspecialchars((string)($integrityReport['gaze_confidence_pct'] ?? 95)); ?>%</div>
            </div>
            <div class="stat-card" style="padding: 15px;">
                <div class="label" style="font-size: 0.75rem;">Screen Interruptions</div>
                <div class="value" style="font-size: 1.2rem;"><?php echo (int)($integrityReport['screen_interruptions'] ?? 0); ?></div>
            </div>
            <div class="stat-card" style="padding: 15px;">
                <div class="label" style="font-size: 0.75rem;">Multiple Persons</div>
                <div class="value" style="font-size: 1.2rem;"><?php echo (int)($integrityReport['multiple_faces_count'] ?? 0); ?></div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <div class="section">
        <h2 class="section-title"><i class="fas fa-user-graduate"></i> Candidate Information</h2>
        <div class="meta-info">
            <div class="meta-item">
                <span>FullName</span>
                <strong><?php echo htmlspecialchars($assessment['student_name']); ?></strong>
            </div>
            <div class="meta-item">
                <span>USN / ID</span>
                <strong><?php echo htmlspecialchars($assessment['usn']); ?></strong>
            </div>
            <div class="meta-item">
                <span>Branch / Department</span>
                <strong><?php echo htmlspecialchars($assessment['branch'] ?: 'N/A'); ?></strong>
            </div>
            <div class="meta-item">
                <span>Current Semester</span>
                <strong><?php echo htmlspecialchars($assessment['current_sem'] ?: 'N/A'); ?></strong>
            </div>
        </div>
    </div>

    <?php if (!empty($questions)): ?>
    <div class="section">
        <h2 class="section-title"><i class="fas fa-list-check"></i> Question Review</h2>
        <div class="question-list">
            <?php foreach ($questions as $idx => $q): 
                $userAns = $userAnswers[$idx] ?? -1;
                $correctAns = $q['answer'];
                $isCorrect = ($userAns == $correctAns);
            ?>
            <div class="question-item <?php echo $isCorrect ? 'correct' : 'wrong'; ?>">
                <div class="q-header">
                    <span>Question <?php echo $idx + 1; ?></span>
                    <div style="display: flex; gap: 15px; align-items: center;">
                        <span style="color: <?php echo $isCorrect ? 'var(--success)' : 'var(--error)'; ?>; font-weight: 700;">
                            <?php echo $isCorrect ? 'CORRECT' : 'INCORRECT'; ?>
                        </span>
                        <a href="javascript:void(0)" onclick='reportReportQuestion(<?php echo $idx; ?>)' style="color: var(--secondary); text-decoration: none; font-size: 0.85rem; font-weight: 600;"><i class="fas fa-flag"></i> Report</a>
                    </div>
                </div>
                <div class="q-text"><?php echo htmlspecialchars($q['question']); ?></div>
                <div class="options-review">
                    <?php foreach ($q['options'] as $oIdx => $opt): 
                        $class = '';
                        if ($oIdx == $correctAns) $class = 'correct-choice';
                        elseif ($oIdx == $userAns) $class = 'wrong-choice user-choice';
                    ?>
                    <div class="opt <?php echo $class; ?>">
                        <?php echo htmlspecialchars($opt); ?>
                        <?php if ($oIdx == $userAns) echo ' <small>(Your Answer)</small>'; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php if (!empty($q['explanation'])): ?>
                <div class="explanation">
                    <strong>EXPLANATION:</strong><br>
                    <?php echo htmlspecialchars($q['explanation']); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($reportContent)): ?>
    <div class="section" style="background: var(--card-bg); padding: 40px; border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 30px;">
        <h2 class="section-title"><i class="fas fa-file-invoice"></i> Detailed Feedback Report</h2>
        <div class="report-body-content" style="color: #e0e0e0; font-size: 1.05rem;">
            <?php 
                $parsedReport = json_decode($reportContent, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($parsedReport)) {
                    $htmlContent = $parsedReport['content'] ?? '';
                } else {
                    $htmlContent = $reportContent;
                }

                // If it is HTML, clean body tags
                if (preg_match('/<body[^>]*>(.*?)<\/body>/is', $htmlContent, $matches)) {
                    $htmlContent = $matches[1];
                } else {
                    // It is markdown, convert it to HTML
                    $htmlContent = preg_replace('/^# (.*$)/m', '<h1>$1</h1>', $htmlContent);
                    $htmlContent = preg_replace('/^## (.*$)/m', '<h2>$1</h2>', $htmlContent);
                    $htmlContent = preg_replace('/^### (.*$)/m', '<h3>$1</h3>', $htmlContent);
                    $htmlContent = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $htmlContent);
                    $htmlContent = preg_replace('/^- (.*$)/m', '<li>$1</li>', $htmlContent);
                    $htmlContent = preg_replace('/(<li>.*<\/li>)/s', '<ul>$1</ul>', $htmlContent);
                    $htmlContent = str_replace('</ul><ul>', '', $htmlContent);
                    $htmlContent = preg_replace('/Score: (\d+\/10)/', 'Score: <span style="background: var(--secondary); color: var(--dark); padding: 2px 8px; border-radius: 4px; font-weight: 700; font-size: 0.9rem;">$1</span>', $htmlContent);
                }

                // Inject stylesheet styling for the elements
                echo "<style>
                    .report-body-content h1, .report-body-content h2, .report-body-content h3 { color: var(--secondary); margin: 25px 0 15px 0; }
                    .report-body-content h1 { font-size: 1.8rem; }
                    .report-body-content h2 { font-size: 1.4rem; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 8px; }
                    .report-body-content h3 { font-size: 1.2rem; }
                    .report-body-content p { margin-bottom: 15px; }
                    .report-body-content ul, .report-body-content ol { margin-bottom: 15px; padding-left: 20px; }
                    .report-body-content li { margin-bottom: 8px; }
                    .report-body-content strong { color: var(--white); font-weight: 700; }
                </style>";
                echo $htmlContent;
            ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="btn-group">
        <a href="company_ai_prep" class="btn btn-outline">Back to Prep Portal</a>
        <a href="dashboard" class="btn btn-primary">Go to Dashboard</a>
        <button onclick="window.print()" class="btn btn-outline"><i class="fas fa-print"></i> Print Report</button>
    </div>
</div>

<script>
    const questions = <?php echo json_encode($questions, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    const userAnswers = <?php echo json_encode($userAnswers, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    const testId = <?php echo json_encode($id, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    const testType = <?php echo json_encode($assessment['assessment_type'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

    window.reportReportQuestion = function(idx) {
        const q = questions[idx];
        const userAns = userAnswers[idx];
        
        // Map unified assessment_type to reported_questions test_type
        let testTypeKey = 'mock_ai';
        if (testType === 'Skill Verification') {
            testTypeKey = 'skill_quiz';
        } else if (testType === 'TCS NQT Practice' || testType === 'NQT') {
            testTypeKey = 'nqt';
        } else if (testType === 'Campus Recruitment' || testType === 'Campus Drive') {
            testTypeKey = 'campus_drive';
        }

        window.openQuestionReportModal({
            test_type: testTypeKey,
            test_id: testId,
            question_text: q.question,
            options: q.options,
            correct_answer: q.answer,
            user_answer: userAns
        });
    };
</script>
</body>
</html>
