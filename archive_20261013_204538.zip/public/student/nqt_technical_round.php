<?php
/**
 * NQT Technical Round Interface
 * Premium dual-panel workspace for NQT coding challenges
 */

require_once __DIR__ . '/../../config/bootstrap.php';
requireLogin();

use App\Helpers\SessionFilterHelper;

requireLogin();

$fullName = getFullName();

// Handle POST from assigned_task.php or dashboard
if (isPost() && (isset($_POST['company']) || isset($_POST['task_id']))) {
    SessionFilterHelper::setFilters('nqt_technical', [
        'company' => $_POST['company'] ?? 'TCS NQT Practice',
        'task_id' => $_POST['task_id'] ?? 0
    ]);
    header("Location: nqt_technical_round.php");
    exit;
}

$filters = SessionFilterHelper::getFilters('nqt_technical');
$companyName = $filters['company'] ?? 'TCS NQT Practice';
$taskId = (int)($filters['task_id'] ?? 0); // comes from raw POST and is echoed into JS
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NQT Coding Workspace - Lakshya</title>
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- In-page dialogs (replaces native alert/confirm popups) -->
    <script src="../js/lakshya_dialogs.js?v=<?php echo APP_VERSION; ?>"></script>

    <!-- Code Mirror -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/dracula.min.css">
    
    <!-- KaTeX for equation rendering -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js"></script>
    
    <!-- html2pdf -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

    <style>
        :root {
            --primary: #800000; /* Maroon */
            --secondary: #e9c66f; /* Gold */
            --dark: #0a0a0a;
            --panel: #161616;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
            --text: #e0e0e0;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Outfit', sans-serif; }
        body { background: var(--dark); color: var(--text); height: 100vh; overflow: hidden; display: flex; flex-direction: column; }

        header {
            padding: 12px 30px;
            background: #000;
            border-bottom: 2px solid var(--primary);
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
        }

        .main-workspace { flex: 1; display: flex; overflow: hidden; }

        /* Left Panel */
        .interaction-panel {
            width: 38%;
            background: var(--panel);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .problem-container {
            padding: 24px;
            background: linear-gradient(180deg, rgba(128,0,0,0.05) 0%, transparent 100%);
            border-bottom: 1px solid var(--border);
            max-height: 45%;
            overflow-y: auto;
        }

        .chat-history { flex: 1; overflow-y: auto; padding: 20px; scroll-behavior: smooth; }

        .bubble { 
            max-width: 85%; margin-bottom: 16px; padding: 14px 18px; border-radius: 12px; 
            font-size: 0.95rem; line-height: 1.6;
        }
        .bubble.ai { 
            background: var(--glass); border: 1px solid var(--border); border-bottom-left-radius: 2px;
            color: #ccc;
        }
        .bubble.user { 
            background: var(--primary); color: white; margin-left: auto; border-bottom-right-radius: 2px;
        }

        .input-bar {
            padding: 20px;
            background: #000;
            border-top: 1px solid var(--border);
            display: flex;
            gap: 12px;
        }

        /* Right Panel */
        .editor-panel {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #1e1e1e;
        }

        .editor-header {
            padding: 8px 20px;
            background: #181818;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
        }

        .CodeMirror { height: 100% !important; font-family: 'JetBrains Mono', monospace; font-size: 14px; }

        .btn {
            padding: 8px 18px;
            border-radius: 6px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }
        .btn-gold { background: var(--secondary); color: #000; }
        .btn-gold:hover { transform: translateY(-1px); background: #d4b45d; }
        .btn-outline { background: transparent; border: 1px solid var(--border); color: #888; }
        .btn-outline:hover { color: #fff; border-color: #fff; }

        /* Overlays */
        .overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            z-index: 1000; text-align: center;
        }
        .start-overlay { background: radial-gradient(circle, #1a0000 0%, #050505 100%); }
        .security-overlay { background: rgba(0,0,0,0.98); display: none; }

        .glass-card {
            background: rgba(20, 20, 20, 0.8);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 24px;
            border: 1px solid var(--secondary);
            max-width: 500px;
            box-shadow: 0 0 40px rgba(128,0,0,0.3);
        }

        .loader-overlay {
            position: fixed; top:0; left:0; width:100%; height:100%;
            background: rgba(0,0,0,0.85); z-index: 5000;
            display: none; flex-direction: column; align-items: center; justify-content: center;
        }

        .spinner {
            width: 40px; height: 40px; border: 3px solid var(--glass);
            border-top-color: var(--secondary); border-radius: 50%;
            animation: spin 1s infinite linear;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        input[type="text"] {
            flex: 1; background: #222; border: 1px solid var(--border);
            padding: 12px 18px; border-radius: 8px; color: #fff; outline: none;
        }
    </style>
</head>
<body>

    <header>
    <link rel='icon' type='image/png' href='<?php echo APP_URL; ?>/assets/img/favicon.png'>
        <div style="display: flex; align-items: center; gap: 15px;">
            <i class="fas fa-microchip" style="color: var(--secondary); font-size: 1.8rem;"></i>
            <div>
                <h2 style="font-size: 1.1rem; letter-spacing: 1px;">NQT TECHNICAL ROUND</h2>
                <div style="font-size: 0.75rem; color: #666; text-transform: uppercase;"><?php echo htmlspecialchars($fullName); ?></div>
            </div>
        </div>
        <div style="display: flex; gap: 12px; align-items: center;">
            <div id="timerDisplay" style="font-size: 1.1rem; color: var(--secondary); font-weight: 600; font-family: 'JetBrains Mono', monospace; margin-right: 15px;"><i class="fas fa-clock"></i> 60:00</div>
            <button onclick="endSession()" class="btn btn-outline">FINISH ASSESSMENT</button>
        </div>
    </header>

    <div class="main-workspace">
        <div class="interaction-panel">
            <div class="problem-container" id="problemDisplay">
                <h3 style="color: var(--secondary); margin-bottom: 12px; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px;">Active Challenge</h3>
                <div id="pText" style="font-size: 0.95rem; line-height: 1.6; color: #bbb;">
                    Initializing assessment environment...
                </div>
            </div>
            
            <div class="chat-history" id="chatHistory">
                <!-- Messages -->
            </div>

            <div class="input-bar">
                <input type="text" id="userInput" placeholder="Ask AI regarding the challenge..." onkeypress="if(event.key=='Enter')sendMessage()">
                <button class="btn btn-gold" onclick="sendMessage()"><i class="fas fa-paper-plane"></i></button>
            </div>
        </div>

        <div class="editor-panel">
            <div class="editor-header">
                <div style="display: flex; gap: 15px; align-items: center;">
                    <i class="fas fa-code" style="color: #666;"></i>
                    <select id="langSelect" style="background:#222; color:#fff; border:none; padding:4px 8px; border-radius:4px; font-size: 0.8rem;">
                        <option value="python">Python 3</option>
                        <option value="javascript">JavaScript</option>
                        <option value="cpp">C++ 17</option>
                        <option value="java">Java 11</option>
                    </select>
                </div>
                <button class="btn btn-gold" onclick="submitCode()">
                    <i class="fas fa-play"></i> RUN & SUBMIT
                </button>
            </div>
            <textarea id="codeEditor"></textarea>
        </div>
    </div>

    <!-- Start Overlay -->
    <div id="startOverlay" class="overlay start-overlay">
        <div class="glass-card">
            <i class="fas fa-user-shield" style="font-size: 3.5rem; color: var(--secondary); margin-bottom: 20px;"></i>
            <h2 style="margin-bottom: 15px;">NQT Technical Simulation</h2>
            <p style="opacity: 0.7; font-size: 0.95rem; margin-bottom: 30px;">
                This assessment uses AI-proctoring. Ensure you are in a quiet environment. 
                Exiting fullscreen or switching tabs will result in a security violation.
            </p>
            <button id="btnBegin" onclick="beginSession()" class="btn btn-gold" style="width:100%; padding: 15px; justify-content: center; font-size: 1.1rem;">
                ENTER WORKSPACE
            </button>
        </div>
    </div>

    <!-- Security Overlay -->
    <div id="securityOverlay" class="overlay security-overlay">
        <div class="glass-card" style="border-color: var(--primary);">
            <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: var(--primary); margin-bottom: 20px;"></i>
            <h2 id="securityTitle" style="color: #fff;">Protocol Violation</h2>
            <p id="securityText" style="opacity: 0.8; margin-top: 15px; margin-bottom: 30px;">
                Assessment paused. You have exited the secure fullscreen environment.
                Please return to proceed. Continued violations will be logged.
            </p>
            <button id="securityBtn" onclick="resumeFullscreen()" class="btn btn-gold" style="width:100%; justify-content: center;">RESUME ROUND</button>
        </div>
    </div>

    <!-- Time Up Overlay -->
    <div id="timeUpOverlay" class="overlay security-overlay" style="z-index: 4000;">
        <div class="glass-card" style="border-color: var(--primary);">
            <i class="fas fa-clock" style="font-size: 4rem; color: var(--primary); margin-bottom: 20px;"></i>
            <h2 style="color: #fff;">Time is over please exit</h2>
            <button onclick="endSession(true)" class="btn btn-gold" style="width:100%; justify-content: center; margin-top:20px;">EXIT ASSESSMENT</button>
        </div>
    </div>

    <div id="loader" class="loader-overlay">
        <div class="spinner"></div>
        <p id="loaderText" style="margin-top: 20px; font-weight: 500; letter-spacing: 1px;">EVALUATING SOLUTION...</p>
    </div>

    <!-- Code Mirror Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/python/python.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>

    <script>
        let editor, sessionId, currentProblem = "";
        let isAssessmentActive = false;
        let timeRemaining = 3600;
        let timerInterval;
        let isQuestionLoading = false;
        let isSubmittingCode = false;
        let isEndingSession = false;

        function escapeHtml(text) {
            return String(text ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }

        function renderMath(element) {
            if (typeof renderMathInElement === 'function') {
                renderMathInElement(element, {
                    delimiters: [
                        {left: "$$", right: "$$", display: true},
                        {left: "$", right: "$", display: false},
                        {left: "\\(", right: "\\)", display: false},
                        {left: "\\[", right: "\\]", display: true}
                    ],
                    throwOnError: false
                });
            } else {
                setTimeout(() => renderMath(element), 100);
            }
        }

        function startTimer() {
            if (timerInterval) clearInterval(timerInterval);
            timerInterval = setInterval(() => {
                timeRemaining--;
                let m = Math.floor(timeRemaining / 60).toString().padStart(2, '0');
                let s = (timeRemaining % 60).toString().padStart(2, '0');
                document.getElementById('timerDisplay').innerHTML = `<i class="fas fa-clock"></i> ${m}:${s}`;
                
                if (timeRemaining <= 0) {
                    clearInterval(timerInterval);
                    handleTimeUp();
                }
            }, 1000);
        }

        function handleTimeUp() {
            document.getElementById('timeUpOverlay').style.display = 'flex';
        }

        // Init Editor
        window.onload = () => {
            editor = CodeMirror.fromTextArea(document.getElementById("codeEditor"), {
                mode: "python",
                theme: "dracula",
                lineNumbers: true,
                autoCloseBrackets: true,
                indentUnit: 4
            });
            editor.setValue("# Write your solution logic here...\n\n");
        };

        async function beginSession() {
            const beginBtn = document.getElementById('btnBegin');
            if (beginBtn) beginBtn.disabled = true;
            document.getElementById('startOverlay').style.display = 'none';
            try {
                await requestFullscreen();
            } catch(e) { console.error(e); }
            startAPISession();
        }

        async function startAPISession() {
            showLoader("PREPARING WORKSPACE...");
            const res = await apiCall({ action: 'start_session', task_id: "<?php echo (int)$taskId; ?>" });
            hideLoader();
            if (res.success) {
                sessionId = res.session_id;
                isAssessmentActive = true;
                startTimer();
                // Fullscreen can be refused (e.g. Safari); ask for a click instead of running without it
                setTimeout(() => {
                    if (isAssessmentActive && !getFullscreenElement()) showSecurityOverlay(true);
                }, 700);
                addMessage('ai', "Welcome. I have prepared your first technical challenge. Focus on efficiency and edge cases.");
                loadQuestion();
            } else {
                // Previously a failed start left an empty workspace with no feedback
                document.getElementById('startOverlay').style.display = 'flex';
                const beginBtn = document.getElementById('btnBegin');
                if (beginBtn) beginBtn.disabled = false;
                LakshyaDialog.alert("Could not start the technical round: " + (res.message || "Unknown error") + "\nPlease try again.", { type: 'error', title: 'Could Not Start' });
            }
        }

        async function loadQuestion(userMsg = '') {
            if (isQuestionLoading) return;
            isQuestionLoading = true;
            let res;
            try {
                res = await apiCall({ action: 'get_question', session_id: sessionId, message: userMsg });
            } finally {
                isQuestionLoading = false;
            }
            if (res.success && res.data) {
                const q = res.data;
                currentProblem = q.problem_statement;

                // AI text is escaped: code like vector<int> was parsed as HTML (and could inject markup)
                document.getElementById('pText').innerHTML = `
                    <div style="font-weight: 600; color: #fff; margin-bottom: 10px;">${escapeHtml(q.title || 'Coding Challenge')}</div>
                    ${escapeHtml(q.problem_statement).replace(/\n/g, '<br>')}<br><br>
                    <strong>Input:</strong> <code style="color: var(--secondary);">${escapeHtml(q.example_input || 'N/A')}</code><br>
                    <strong>Output:</strong> <code style="color: var(--secondary);">${escapeHtml(q.example_output || 'N/A')}</code>
                `;
                renderMath(document.getElementById('pText'));

                addMessage('ai', q.question || "Implement the logic described in the panel above.");
            } else {
                addMessage('ai', "⚠️ " + (res.message || "Could not load the challenge.") + " Please send a message to try again.");
            }
        }

        async function sendMessage() {
            const input = document.getElementById('userInput');
            const msg = input.value.trim();
            if(!msg) return;
            if (isQuestionLoading) {
                LakshyaDialog.alert("The AI is still responding. Please wait a moment, then send your message.", { type: 'info', title: 'Please Wait' });
                return;
            }
            addMessage('user', msg);
            input.value = "";
            loadQuestion(msg);
        }

        async function submitCode() {
            if (!sessionId) {
                LakshyaDialog.alert("The session has not started yet.", { type: 'info', title: 'Not Started' });
                return;
            }
            if (isSubmittingCode) return;
            isSubmittingCode = true;
            showLoader("VALIDATING LOGIC...");
            const code = editor.getValue();
            const lang = document.getElementById('langSelect').value;

            const res = await apiCall({
                action: 'submit_code',
                session_id: sessionId,
                code: code,
                language: lang,
                problem_statement: currentProblem
            });

            hideLoader();
            isSubmittingCode = false;
            if (res.success && res.result) {
                // 'eval' is a reserved name in strict mode; renamed
                const evaluation = res.result;
                const score = Number(evaluation.score) || 0;
                addMessage('ai', `<strong>Evaluation Result:</strong> ${score}/10<br>${escapeHtml(evaluation.feedback || '').replace(/\n/g, '<br>')}`, true);
                if (score >= 8) {
                    addMessage('ai', "Great work. Preparing your next challenge...");
                    setTimeout(() => {
                        editor.setValue("");
                        loadQuestion("Proceed to next.");
                    }, 2500);
                }
            } else {
                addMessage('ai', "⚠️ Evaluation failed: " + (res.message || "Unknown error") + ". Please try RUN & SUBMIT again.");
            }
        }

        async function endSession(skipConfirm = false) {
            if (isEndingSession) return;
            if (!skipConfirm) {
                const ok = await LakshyaDialog.confirm("Are you sure? This will finalize your results and generate the report.", {
                    title: 'Finish Assessment?', type: 'warning', okText: 'Finish & Generate Report', cancelText: 'Keep Working'
                });
                if (!ok || isEndingSession) return;
            }
            isEndingSession = true;

            isAssessmentActive = false;
            if (timerInterval) clearInterval(timerInterval);
            document.getElementById('securityOverlay').style.display = 'none';
            document.getElementById('timeUpOverlay').style.display = 'none';
            if (document.exitFullscreen && document.fullscreenElement) document.exitFullscreen().catch(()=>{});
            else if (document.webkitExitFullscreen && document.webkitFullscreenElement) document.webkitExitFullscreen();

            showLoader("GENERATING PERFORMANCE REPORT...");
            const res = await apiCall({ action: 'generate_report_data', session_id: sessionId });

            if (res.success) {
                // ... (rest of the logic remains same, just replacing the fail block below)
                const element = document.createElement('div');
                element.innerHTML = res.report_html;
                
                const opt = {
                    margin: 0.5,
                    filename: res.filename,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2 },
                    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
                };

                html2pdf().set(opt).from(element).outputPdf('blob').then(async (blob) => {
                    const formData = new FormData();
                    formData.append('action', 'save_pdf_report');
                    formData.append('session_id', sessionId);
                    formData.append('pdf', blob, res.filename);

                    const upload = await fetch('nqt_technical_handler', { method: 'POST', body: formData });
                    const uploadRes = await upload.json();

                    hideLoader();
                    if (uploadRes.success) {
                        html2pdf().set(opt).from(element).save();
                        // Redirect only after the student has read the message
                        await LakshyaDialog.alert("Assessment Completed. Your report has been saved.", { type: 'success', title: 'Assessment Completed', okText: 'Go to Dashboard' });
                        window.location.href = 'dashboard';
                    } else {
                        isEndingSession = false;
                        LakshyaDialog.alert("Failed to save report to server: " + (uploadRes.message || "Unknown error"), { type: 'error', title: 'Report Not Saved' });
                    }
                }).catch((err) => {
                    // PDF render / upload / JSON failure used to leave the loader spinning forever
                    console.error(err);
                    hideLoader();
                    isEndingSession = false;
                    LakshyaDialog.alert("Could not generate or upload the report. Please click FINISH ASSESSMENT to try again.", { type: 'error', title: 'Report Failed' });
                });
            } else {
                hideLoader();
                isEndingSession = false;
                LakshyaDialog.alert("Critical Failure: " + (res.message || "Report generation failed. Please try again or contact support."), { type: 'error', title: 'Report Generation Failed' });
            }
        }

        // --- Helpers & Security ---
        async function apiCall(data) {
            try {
                const formData = new FormData();
                for (const k in data) formData.append(k, data[k]);
                const response = await fetch('nqt_technical_handler', { 
                    method: 'POST', 
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                return await response.json();
            } catch (e) {
                console.error(e);
                return { success: false, message: e.message };
            }
        }

        // isHtml = true only for markup built by this page (with AI/user parts already escaped)
        function addMessage(role, text, isHtml = false) {
            const div = document.createElement('div');
            div.className = `bubble ${role}`;
            div.innerHTML = isHtml ? String(text) : escapeHtml(text).replace(/\n/g, '<br>');
            document.getElementById('chatHistory').appendChild(div);
            renderMath(div);
            document.getElementById('chatHistory').scrollTop = document.getElementById('chatHistory').scrollHeight;
        }

        function showLoader(text) {
            document.getElementById('loaderText').innerText = text;
            document.getElementById('loader').style.display = 'flex';
        }
        function hideLoader() { document.getElementById('loader').style.display = 'none'; }

        function getFullscreenElement() {
            return document.fullscreenElement || document.webkitFullscreenElement || null;
        }

        function requestFullscreen() {
            const el = document.documentElement;
            if (el.requestFullscreen) return el.requestFullscreen();
            // Old Safari: webkitRequestFullscreen returns undefined, not a promise
            if (el.webkitRequestFullscreen) { el.webkitRequestFullscreen(); return Promise.resolve(); }
            if (el.msRequestFullscreen) { el.msRequestFullscreen(); return Promise.resolve(); }
            return Promise.reject(new Error('Fullscreen API not supported'));
        }

        // isPrompt = true: plain "enter full screen" request (browser refused it at start), not a violation
        function showSecurityOverlay(isPrompt) {
            document.getElementById('securityTitle').textContent = isPrompt ? 'Full Screen Required' : 'Protocol Violation';
            document.getElementById('securityText').textContent = isPrompt
                ? 'Click the button below to enter full screen and begin. This is not counted as a violation.'
                : 'Assessment paused. You have exited the secure fullscreen environment. Please return to proceed. Continued violations will be logged.';
            document.getElementById('securityBtn').textContent = isPrompt ? 'ENTER FULL SCREEN' : 'RESUME ROUND';
            document.getElementById('securityOverlay').style.display = 'flex';
        }

        function resumeFullscreen() {
            requestFullscreen().then(() => {
                document.getElementById('securityOverlay').style.display = 'none';
            }).catch(() => {
                // Previously an unhandled rejection; explain inline instead of a native popup
                const textEl = document.getElementById('securityText');
                if (textEl && !textEl.querySelector('.fs-blocked-hint')) {
                    textEl.insertAdjacentHTML('beforeend', '<br><br><span class="fs-blocked-hint" style="color:#f59e0b;">Your browser blocked full screen. Please click the button again, and allow full screen if your browser asks.</span>');
                }
            });
        }

        function onFullscreenChange() {
            if (!getFullscreenElement() && isAssessmentActive) {
                showSecurityOverlay(false);
            } else {
                document.getElementById('securityOverlay').style.display = 'none';
            }
        }
        document.addEventListener('fullscreenchange', onFullscreenChange);
        document.addEventListener('webkitfullscreenchange', onFullscreenChange);

        // Anti-Cheat
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('copy', e => e.preventDefault());
        document.addEventListener('cut', e => e.preventDefault());
        document.addEventListener('paste', e => e.preventDefault());
        document.addEventListener('keydown', e => {
            // metaKey = Cmd on macOS. Other editor shortcuts (Cmd+Z/A/S, arrows) keep working.
            if ((e.ctrlKey || e.metaKey) && ['c','v','x','u'].includes((e.key || '').toLowerCase())) e.preventDefault();
            if (e.key === 'F12') e.preventDefault();
        });

    </script>
</body>
</html>

