<?php
/**
 * Seeder to add new, high-quality, scenario-based DSA coding problems to the database.
 */

require_once __DIR__ . '/../../config/bootstrap.php';

// Only allow execution via CLI or with a secret key to prevent unauthorized running
if (php_sapi_name() !== 'cli' && (!isset($_GET['run']) || $_GET['run'] !== 'secret123')) {
    die("Access Denied.");
}

header('Content-Type: text/plain');
echo "Seeding New Scenario-Based Problems...\n";

$db = getDB();

$newProblems = [
    [
        'title' => 'Weather Station Sensor Analyzer',
        'category' => 'Stacks',
        'difficulty' => 'Medium',
        'problem_statement' => "Scenario: You are designing the telemetry analyzer for an IoT weather station. The station reports daily temperature readings in Celsius. To optimize the greenhouse heating grid, you need to calculate for each day how many days you must wait until a warmer day occurs. If no warmer day is possible, return 0.\n\nTask: Write a function `dailyTemperatures(temperatures)` that takes an array of temperatures and returns an array where the i-th element is the number of days you have to wait for a warmer temperature.",
        'constraints' => "1 <= temperatures.length <= 10^5\n30 <= temperatures[i] <= 100",
        'example_input' => "temperatures = [30, 40, 35, 36, 42]",
        'example_output' => "[1, 3, 1, 1, 0]",
        'concept_explanation' => "This problem uses a Monotonic Stack to keep track of indices of temperatures that haven't found a warmer day yet. Iterating through the array, we pop elements from the stack as long as the current temperature is higher than the temperature at the index stored at the top of the stack.",
        'dry_run_steps' => json_encode([
            "Initialize an empty result array and stack.",
            "Process index 0 (30): Stack is empty. Push 0 to stack. Stack = [0]",
            "Process index 1 (40): 40 > temperatures[0] (30). Pop 0. result[0] = 1 - 0 = 1. Push 1. Stack = [1]",
            "Process index 2 (35): 35 <= temperatures[1] (40). Push 2. Stack = [1, 2]",
            "Process index 3 (36): 36 > temperatures[2] (35). Pop 2. result[2] = 3 - 2 = 1. Push 3. Stack = [1, 3]",
            "Process index 4 (42): 42 > temperatures[3] (36) and temperatures[1] (40). Pop 3 (result[3]=1), pop 1 (result[1]=3). Push 4. Stack = [4]"
        ]),
        'solution_beginner' => json_encode([
            'why_function' => 'A function encapsulates the sensor parsing logic for modular integration.',
            'plan' => [
                'Step 1: Initialize an array of zeros with the same length as temperatures.',
                'Step 2: Loop through each day and check all future days to find the first warmer temperature.'
            ],
            'variables' => [
                'result: array storing wait days.',
                'i: outer loop index for current day.',
                'j: inner loop index for future days.'
            ],
            'code' => [
                'javascript' => "function dailyTemperatures(temperatures) {\n    let n = temperatures.length;\n    let result = new Array(n).fill(0);\n    for (let i = 0; i < n; i++) {\n        for (let j = i + 1; j < n; j++) {\n            if (temperatures[j] > temperatures[i]) {\n                result[i] = j - i;\n                break;\n            }\n        }\n    }\n    return result;\n}",
                'python' => "def dailyTemperatures(temperatures):\n    n = len(temperatures)\n    result = [0] * n\n    for i in range(n):\n        for j in range(i + 1, n):\n            if temperatures[j] > temperatures[i]:\n                result[i] = j - i\n                break\n    return result"
            ],
            'why_logic' => 'The nested loop compares each day to every subsequent day to find the first warmer day.'
        ]),
        'solution_optimized' => json_encode([
            'goal' => 'Improve performance to O(n) using a monotonic stack to store indices.',
            'technique' => 'Iterate through temperatures and push indices onto the stack, resolving earlier days when a warmer temperature is encountered.',
            'tradeoff' => 'Uses O(n) space for the stack, but reduces runtime from O(n^2) to O(n).',
            'code' => [
                'javascript' => "function dailyTemperatures(temperatures) {\n    let n = temperatures.length;\n    let result = new Array(n).fill(0);\n    let stack = [];\n    for (let i = 0; i < n; i++) {\n        while (stack.length > 0 && temperatures[i] > temperatures[stack[stack.length - 1]]) {\n            let idx = stack.pop();\n            result[idx] = i - idx;\n        }\n        stack.push(i);\n    }\n    return result;\n}",
                'python' => "def dailyTemperatures(temperatures):\n    n = len(temperatures)\n    result = [0] * n\n    stack = []\n    for i in range(n):\n        while stack and temperatures[i] > temperatures[stack[-1]]:\n            idx = stack.pop()\n            result[idx] = i - idx\n        stack.append(i)\n    return result"
            ]
        ]),
        'time_complexity' => 'O(n)',
        'space_complexity' => 'O(n)'
    ],
    [
        'title' => 'API Rate Limiter Log Analyzer',
        'category' => 'Sliding Window',
        'difficulty' => 'Medium',
        'problem_statement' => "Scenario: You are building an API rate limiter monitor. Given a sequence of incoming request tokens (represented as a string of single characters), you need to find the maximum length of a window of requests that contain only unique, non-repeating request tokens.\n\nTask: Write a function `longestUniqueSubstrings(s)` that takes a string and returns the length of the longest substring without repeating characters.",
        'constraints' => "0 <= s.length <= 5 * 10^4\ns consists of English letters, digits, symbols and spaces.",
        'example_input' => "s = \"abcabcbb\"",
        'example_output' => "3",
        'concept_explanation' => "Uses a Sliding Window with a hash map/set. We expand the window to the right and contract it from the left whenever a duplicate character is encountered, keeping track of the max length found.",
        'dry_run_steps' => json_encode([
            "Window 'a', length 1",
            "Window 'ab', length 2",
            "Window 'abc', length 3",
            "Meet duplicate 'a': shrink window to 'bca', length 3",
            "Meet duplicate 'b': shrink window to 'cab', length 3",
            "Meet duplicate 'c': shrink window to 'abc', length 3",
            "Meet duplicate 'b': shrink window to 'cb', length 2",
            "Meet duplicate 'b': shrink window to 'b', length 1."
        ]),
        'solution_beginner' => json_encode([
            'why_function' => 'Modular string parser suitable for log analytics middleware.',
            'plan' => [
                'Step 1: Check all possible substrings.',
                'Step 2: Verify if each substring has unique characters and record the maximum length.'
            ],
            'variables' => [
                'maxLen: maximum unique substring length.',
                'i, j: substring boundary loops.'
            ],
            'code' => [
                'javascript' => "function longestUniqueSubstrings(s) {\n    let maxLen = 0;\n    for (let i = 0; i < s.length; i++) {\n        let set = new Set();\n        for (let j = i; j < s.length; j++) {\n            if (set.has(s[j])) break;\n            set.add(s[j]);\n            maxLen = Math.max(maxLen, j - i + 1);\n        }\n    }\n    return maxLen;\n}",
                'python' => "def longestUniqueSubstrings(s):\n    maxLen = 0\n    for i in range(len(s)):\n        char_set = set()\n        for j in range(i, len(s)):\n            if s[j] in char_set:\n                break\n            char_set.add(s[j])\n            maxLen = max(maxLen, j - i + 1)\n    return maxLen"
            ],
            'why_logic' => 'The double loop exhaustively checks every substring starting at index i.'
        ]),
        'solution_optimized' => json_encode([
            'goal' => 'Optimize string parsing to O(n) using a sliding window technique.',
            'technique' => 'Maintain left and right pointers. Store characters and their index in a map to jump the left pointer quickly.',
            'tradeoff' => 'Uses O(k) space where k is character set size, but reduces time to O(n).',
            'code' => [
                'javascript' => "function longestUniqueSubstrings(s) {\n    let maxLen = 0;\n    let map = new Map();\n    let left = 0;\n    for (let right = 0; right < s.length; right++) {\n        if (map.has(s[right])) {\n            left = Math.max(left, map.get(s[right]) + 1);\n        }\n        map.set(s[right], right);\n        maxLen = Math.max(maxLen, right - left + 1);\n    }\n    return maxLen;\n}",
                'python' => "def longestUniqueSubstrings(s):\n    max_len = 0\n    char_map = {}\n    left = 0\n    for right, char in enumerate(s):\n        if char in char_map:\n            left = max(left, char_map[char] + 1)\n        char_map[char] = right\n        max_len = max(max_len, right - left + 1)\n    return max_len"
            ]
        ]),
        'time_complexity' => 'O(n)',
        'space_complexity' => 'O(min(m, n))'
    ],
    [
        'title' => 'Server Rack Heat Sink Optimizer',
        'category' => 'Two Pointers',
        'difficulty' => 'Medium',
        'problem_statement' => "Scenario: You are designing cooling systems for server racks. You have an array representing the heights of vertical heat sink fins. You want to choose two fins such that when hot air is blown through, they form a chamber that traps the maximum cross-sectional area of air (Height of shorter fin multiplied by the distance between them).\n\nTask: Write a function `maxTrappedArea(height)` that takes an array of integer heights and returns the maximum trapped area.",
        'constraints' => "2 <= height.length <= 10^5\n0 <= height[i] <= 10^4",
        'example_input' => "height = [1, 8, 6, 2, 5, 4, 8, 3, 7]",
        'example_output' => "49",
        'concept_explanation' => "Uses the Two Pointers approach. Start with pointers at both ends of the array. Compute the area, and move the pointer pointing to the shorter fin inwards since that is the only way to potentially find a larger area.",
        'dry_run_steps' => json_encode([
            "L=0 (1), R=8 (7): Area = min(1, 7) * 8 = 8. Move L forward.",
            "L=1 (8), R=8 (7): Area = min(8, 7) * 7 = 49. Move R backward.",
            "L=1 (8), R=7 (3): Area = min(8, 3) * 6 = 18. Move R backward.",
            "Keep moving the pointer with shorter height until they meet."
        ]),
        'solution_beginner' => json_encode([
            'why_function' => 'Modular geometry and area optimizer for server thermal management.',
            'plan' => [
                'Step 1: Check every possible pair of fins.',
                'Step 2: Compute their cross-sectional area and return the maximum.'
            ],
            'variables' => [
                'maxArea: stores maximum area.',
                'i, j: loop variables representing fin choices.'
            ],
            'code' => [
                'javascript' => "function maxTrappedArea(height) {\n    let maxArea = 0;\n    for (let i = 0; i < height.length; i++) {\n        for (let j = i + 1; j < height.length; j++) {\n            let area = Math.min(height[i], height[j]) * (j - i);\n            maxArea = Math.max(maxArea, area);\n        }\n    }\n    return maxArea;\n}",
                'python' => "def maxTrappedArea(height):\n    maxArea = 0\n    n = len(height)\n    for i in range(n):\n        for j in range(i + 1, n):\n            area = min(height[i], height[j]) * (j - i)\n            maxArea = max(maxArea, area)\n    return maxArea"
            ],
            'why_logic' => 'The nested loop compares all pairs to find the absolute maximum area.'
        ]),
        'solution_optimized' => json_encode([
            'goal' => 'Improve performance from O(n^2) to O(n) using two pointers.',
            'technique' => 'Initialize pointers at indices 0 and length-1. At each step, calculate area, then move the pointer pointing to the smaller height.',
            'tradeoff' => 'O(1) auxiliary space and O(n) time complexity.',
            'code' => [
                'javascript' => "function maxTrappedArea(height) {\n    let maxArea = 0;\n    let left = 0;\n    let right = height.length - 1;\n    while (left < right) {\n        let area = Math.min(height[left], height[right]) * (right - left);\n        maxArea = Math.max(maxArea, area);\n        if (height[left] < height[right]) {\n            left++;\n        } else {\n            right--;\n        }\n    }\n    return maxArea;\n}",
                'python' => "def maxTrappedArea(height):\n    maxArea = 0\n    left = 0\n    right = len(height) - 1\n    while left < right:\n        area = min(height[left], height[right]) * (right - left)\n        maxArea = max(maxArea, area)\n        if height[left] < height[right]:\n            left += 1\n        else:\n            right -= 1\n    return maxArea"
            ]
        ]),
        'time_complexity' => 'O(n)',
        'space_complexity' => 'O(1)'
    ],
    [
        'title' => 'Microservice Broadcast Latency',
        'category' => 'Graphs',
        'difficulty' => 'Medium',
        'problem_statement' => "Scenario: You are designing a message broadcasting service for a distributed microservice mesh. The network has `n` microservices (numbered 1 to n). You are given a list of latency links represented as `times[i] = [u_i, v_i, w_i]`, where `u_i` is the source microservice, `v_i` is the target, and `w_i` is the transmission latency in milliseconds. When a service broadcasts a signal from a given starting service `k`, you need to calculate the minimum time it takes for all `n` microservices to receive the signal. If it is impossible for all services to receive it, return -1.\n\nTask: Write a function `networkDelayTime(times, n, k)` that returns the minimum delay time.",
        'constraints' => "1 <= k <= n <= 100\n1 <= times.length <= 6000\n0 <= w_i <= 100",
        'example_input' => "times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2",
        'example_output' => "2",
        'concept_explanation' => "Uses Dijkstra's Algorithm to find the shortest path from starting node `k` to all other nodes. The delay time is the maximum of these shortest paths.",
        'dry_run_steps' => json_encode([
            "Initialize distances array with infinity, except distances[k] = 0.",
            "Initialize a priority queue (or min-heap) and push [0, k] (distance, node).",
            "While queue is not empty, pop the node with min distance. For each neighbor, check if distance can be minimized.",
            "If so, update distance and push neighbor to queue.",
            "Finally, check if any distance is infinity. If so, return -1. Else, return the max value in the distances array."
        ]),
        'solution_beginner' => json_encode([
            'why_function' => 'Modular pathfinder suitable for service mesh telemetry.',
            'plan' => [
                'Step 1: Build adjacency list and initialize distance map.',
                'Step 2: Traverse using a queue or min-heap to perform standard shortest path search.'
            ],
            'variables' => [
                'dist: map storing shortest distance from starting node.',
                'queue: tracking node processing queue.'
            ],
            'code' => [
                'javascript' => "function networkDelayTime(times, n, k) {\n    let dist = {};\n    for (let i = 1; i <= n; i++) dist[i] = Infinity;\n    dist[k] = 0;\n    for (let i = 0; i < n - 1; i++) {\n        for (let [u, v, w] of times) {\n            if (dist[u] + w < dist[v]) dist[v] = dist[u] + w;\n        }\n    }\n    let max = Math.max(...Object.values(dist));\n    return max === Infinity ? -1 : max;\n}",
                'python' => "def networkDelayTime(times, n, k):\n    dist = {i: float('inf') for i in range(1, n + 1)}\n    dist[k] = 0\n    for _ in range(n - 1):\n        for u, v, w in times:\n            if dist[u] + w < dist[v]:\n                dist[v] = dist[u] + w\n    res = max(dist.values())\n    return res if res != float('inf') else -1"
            ],
            'why_logic' => 'Standard Bellman-Ford/Dijkstra iteration relaxes all edges repeatedly to find shortest paths.'
        ]),
        'solution_optimized' => json_encode([
            'goal' => 'Optimize using priority-queue driven Dijkstra algorithm.',
            'technique' => 'Use a min-heap to extract the next shortest path node, avoiding redundant checks.',
            'tradeoff' => 'O(V + E log V) time complexity, uses memory for adjacency list and heap.',
            'code' => [
                'javascript' => "function networkDelayTime(times, n, k) {\n    let adj = Array.from({length: n + 1}, () => []);\n    for (let [u, v, w] of times) adj[u].push([v, w]);\n    let dist = Array(n + 1).fill(Infinity);\n    dist[k] = 0;\n    let pq = [[0, k]];\n    while (pq.length > 0) {\n        pq.sort((a, b) => a[0] - b[0]);\n        let [d, u] = pq.shift();\n        if (d > dist[u]) continue;\n        for (let [v, w] of adj[u]) {\n            if (dist[u] + w < dist[v]) {\n                dist[v] = dist[u] + w;\n                pq.push([dist[v], v]);\n            }\n        }\n    }\n    let max = 0;\n    for (let i = 1; i <= n; i++) {\n        if (dist[i] === Infinity) return -1;\n        max = Math.max(max, dist[i]);\n    }\n    return max;\n}",
                'python' => "import heapq\ndef networkDelayTime(times, n, k):\n    adj = {i: [] for i in range(1, n + 1)}\n    for u, v, w in times:\n        adj[u].append((v, w))\n    pq = [(0, k)]\n    dist = {i: float('inf') for i in range(1, n + 1)}\n    dist[k] = 0\n    while pq:\n        d, u = heapq.heappop(pq)\n        if d > dist[u]: continue\n        for v, w in adj[u]:\n            if dist[u] + w < dist[v]:\n                dist[v] = dist[u] + w\n                heapq.heappush(pq, (dist[v], v))\n    res = max(dist.values())\n    return res if res != float('inf') else -1"
            ]
        ]),
        'time_complexity' => 'O(E log V)',
        'space_complexity' => 'O(V + E)'
    ],
    [
        'title' => 'Security Grid Keyword Detector',
        'category' => 'Backtracking',
        'difficulty' => 'Medium',
        'problem_statement' => "Scenario: You are developing an intrusion detection system (IDS) that scans a 2D grid of network traffic packets (represented as characters). To identify active malicious activities, you need to determine if a specific signature keyword can be constructed from sequentially adjacent grid packets. Packets can be traversed horizontally or vertically, but the same packet position cannot be used more than once in a single signature match.\n\nTask: Write a function `exist(board, word)` that returns true if the keyword exists in the grid, and false otherwise.",
        'constraints' => "board is a 2D grid of letters.\n1 <= board.length, board[i].length <= 6\n1 <= word.length <= 15",
        'example_input' => "board = [[\"A\",\"B\",\"C\",\"E\"],[\"S\",\"F\",\"C\",\"S\"],[\"A\",\"D\",\"E\",\"E\"]], word = \"ABCCED\"",
        'example_output' => "true",
        'concept_explanation' => "Uses Backtracking (DFS) on the 2D grid. We search in four directions starting from each cell matching the first letter of the word, marking visited cells temporarily.",
        'dry_run_steps' => json_encode([
            "Iterate through every cell (r, c) on the board.",
            "If board[r][c] matches the first character of the word, invoke recursive DFS helper.",
            "In DFS: if index matches word length, return true.",
            "Check boundary and character matches. If out of bounds or character doesn't match, return false.",
            "Mark current cell as visited (e.g. swap with '#').",
            "Recursively call DFS in all four adjacent directions (up, down, left, right).",
            "Unmark cell (backtrack) to restore board state.",
            "If any DFS path returns true, return true; else return false."
        ]),
        'solution_beginner' => json_encode([
            'why_function' => 'Modular backtracker suitable for network matrix log signature parsing.',
            'plan' => [
                'Step 1: Check every cell as a starting point.',
                'Step 2: Perform DFS search in 4 directions.'
            ],
            'variables' => [
                'board: 2D array of characters.',
                'word: signature string to search.'
            ],
            'code' => [
                'javascript' => "function exist(board, word) {\n    let R = board.length, C = board[0].length;\n    function dfs(r, c, idx) {\n        if (idx === word.length) return true;\n        if (r < 0 || r >= R || c < 0 || c >= C || board[r][c] !== word[idx]) return false;\n        let temp = board[r][c];\n        board[r][c] = '#';\n        let res = dfs(r+1, c, idx+1) || dfs(r-1, c, idx+1) || dfs(r, c+1, idx+1) || dfs(r, c-1, idx+1);\n        board[r][c] = temp;\n        return res;\n    }\n    for (let r = 0; r < R; r++) {\n        for (let c = 0; c < C; c++) {\n            if (dfs(r, c, 0)) return true;\n        }\n    }\n    return false;\n}",
                'python' => "def exist(board, word):\n    R, C = len(board), len(board[0])\n    def dfs(r, c, idx):\n        if idx == len(word): return True\n        if r < 0 or r >= R or c < 0 or c >= C or board[r][c] != word[idx]: return False\n        temp = board[r][c]\n        board[r][c] = '#'\n        res = dfs(r+1, c, idx+1) or dfs(r-1, c, idx+1) or dfs(r, c+1, idx+1) or dfs(r, c-1, idx+1)\n        board[r][c] = temp\n        return res\n    for r in range(R):\n        for c in range(C):\n            if dfs(r, c, 0): return True\n    return False"
            ],
            'why_logic' => 'Dfs checks path connectivity dynamically, reverting cell marks during backtracking.'
        ]),
        'solution_optimized' => json_encode([
            'goal' => 'Perform space-efficient backtracking directly on the grid.',
            'technique' => 'In-place replacement using bitwise XOR operations or character masks to avoid visited set overhead.',
            'tradeoff' => 'Saves heap overhead at the cost of deep call-stack recursion.',
            'code' => [
                'javascript' => "function exist(board, word) {\n    let R = board.length, C = board[0].length;\n    function dfs(r, c, idx) {\n        if (idx === word.length) return true;\n        if (r < 0 || r >= R || c < 0 || c >= C || board[r][c] !== word[idx]) return false;\n        board[r][c] = '*';\n        let res = dfs(r+1, c, idx+1) || dfs(r-1, c, idx+1) || dfs(r, c+1, idx+1) || dfs(r, c-1, idx+1);\n        board[r][c] = word[idx];\n        return res;\n    }\n    for (let r = 0; r < R; r++) {\n        for (let c = 0; c < C; c++) {\n            if (dfs(r, c, 0)) return true;\n        }\n    }\n    return false;\n}",
                'python' => "def exist(board, word):\n    R, C = len(board), len(board[0])\n    def dfs(r, c, idx):\n        if idx == len(word): return True\n        if r < 0 or r >= R or c < 0 or c >= C or board[r][c] != word[idx]: return False\n        board[r][c] = '*'\n        res = dfs(r+1, c, idx+1) or dfs(r-1, c, idx+1) or dfs(r, c+1, idx+1) or dfs(r, c-1, idx+1)\n        board[r][c] = word[idx]\n        return res\n    for r in range(R):\n        for c in range(C):\n            if dfs(r, c, 0): return True\n    return False"
            ]
        ]),
        'time_complexity' => 'O(N * 4^L)',
        'space_complexity' => 'O(L)'
    ]
];

foreach ($newProblems as $p) {
    // Check if problem already exists by title
    $check = $db->prepare("SELECT id FROM coding_problems WHERE title = ?");
    $check->execute([$p['title']]);
    if ($check->fetch()) {
        echo "Problem '{$p['title']}' already exists. Skipping.\n";
        continue;
    }

    $stmt = $db->prepare("INSERT INTO coding_problems 
        (title, category, difficulty, problem_statement, constraints, example_input, example_output, concept_explanation, dry_run_steps, solution_beginner, solution_optimized, time_complexity, space_complexity) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->execute([
        $p['title'],
        $p['category'],
        $p['difficulty'],
        $p['problem_statement'],
        $p['constraints'],
        $p['example_input'],
        $p['example_output'],
        $p['concept_explanation'],
        $p['dry_run_steps'],
        $p['solution_beginner'],
        $p['solution_optimized'],
        $p['time_complexity'],
        $p['space_complexity']
    ]);

    echo "✅ Seeded Problem: '{$p['title']}'\n";
}

echo "Seeding completed successfully!\n";
