<?php
require_once __DIR__ . '/../config/bootstrap.php';

$db = getDB('gmu');
// Get a student from GMU
$gmuUser = $db->query("SELECT u.USER_NAME, u.NAME, ad.discipline FROM gmu.users u JOIN gmu.ad_student_approved ad ON u.USER_NAME = ad.usn LIMIT 1")->fetch(PDO::FETCH_ASSOC);

if (!$gmuUser) {
    // Fallback to get a user
    $gmuUser = $db->query("SELECT USER_NAME, NAME FROM gmu.users LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    $gmuUser['discipline'] = 'CSE';
}

if ($gmuUser) {
    Session::setUser(1, $gmuUser['USER_NAME'], 'student', $gmuUser['NAME'] ?? $gmuUser['USER_NAME'], 'GMU', $gmuUser['discipline'] ?? 'CSE', null);
    echo "Logged in successfully as Student: " . htmlspecialchars($gmuUser['NAME']) . " (" . htmlspecialchars($gmuUser['USER_NAME']) . ").<br>";
    echo "<a href='student/dashboard.php'>Go to Dashboard</a>";
} else {
    echo "No student found.";
}
