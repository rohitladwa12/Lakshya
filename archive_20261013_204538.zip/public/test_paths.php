<?php
// Simple test file to verify paths
echo "<h1>Path Test</h1>";
echo "<p><strong>Current File:</strong> " . __FILE__ . "</p>";
echo "<p><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p><strong>Request URI:</strong> " . $_SERVER['REQUEST_URI'] . "</p>";
echo "<p><strong>Script Name:</strong> " . $_SERVER['SCRIPT_NAME'] . "</p>";
echo "<hr>";
echo "<h2>Test Links:</h2>";
echo "<p><a href='login.php'>Student Login (login.php)</a></p>";
echo "<p><a href='officer_login.php'>Officer Login (officer_login.php)</a></p>";
echo "<p><a href='/placement_final/public/officer_login.php'>Officer Login (absolute path)</a></p>";
?>
