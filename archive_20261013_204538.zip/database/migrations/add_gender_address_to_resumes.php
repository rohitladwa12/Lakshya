<?php
require_once 'c:/htdocs/Lakshya/config/bootstrap.php';
$db = getDB();

try {
    $db->exec("ALTER TABLE student_resumes ADD COLUMN gender VARCHAR(20) DEFAULT NULL");
    echo "Added gender column.\n";
} catch (Exception $e) {
    echo "Gender column might already exist: " . $e->getMessage() . "\n";
}

try {
    $db->exec("ALTER TABLE student_resumes ADD COLUMN address TEXT DEFAULT NULL");
    echo "Added address column.\n";
} catch (Exception $e) {
    echo "Address column might already exist: " . $e->getMessage() . "\n";
}
