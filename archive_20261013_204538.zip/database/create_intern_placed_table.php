<?php
require_once __DIR__ . '/../config/bootstrap.php';
$db = getDB();

$sql = "CREATE TABLE IF NOT EXISTS internship_placed_students (
    sl_no INT AUTO_INCREMENT PRIMARY KEY,
    academic_year VARCHAR(50),
    name VARCHAR(255) NOT NULL,
    usn VARCHAR(50) NOT NULL,
    branch VARCHAR(100),
    college VARCHAR(255),
    sem VARCHAR(20),
    whatsapp_no VARCHAR(20),
    email VARCHAR(255),
    company_name VARCHAR(255),
    internship_type VARCHAR(100),
    internship_status VARCHAR(100),
    start_date DATE,
    end_date DATE,
    duration_months INT,
    offer_letter VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

try {
    $db->exec($sql);
    echo "Table 'internship_placed_students' created successfully.\n";
} catch (Exception $e) {
    echo "Error creating table: " . $e->getMessage() . "\n";
}
