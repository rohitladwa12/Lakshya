<?php
/**
 * Run Migration Script
 */
require_once __DIR__ . '/../config/bootstrap.php';

try {
    $db = getDB();
    $sqlFile = __DIR__ . '/migrations/create_active_skill_quizzes_and_reported_questions.sql';
    if (!file_exists($sqlFile)) {
        die("Migration SQL file not found.\n");
    }
    
    $sql = file_get_contents($sqlFile);
    
    // Split statements by semicolon and execute
    $statements = array_filter(array_map('trim', explode(';', $sql)));
    
    foreach ($statements as $stmt) {
        if (empty($stmt)) continue;
        $db->exec($stmt);
    }
    
    echo "Migration completed successfully!\n";
} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
}
